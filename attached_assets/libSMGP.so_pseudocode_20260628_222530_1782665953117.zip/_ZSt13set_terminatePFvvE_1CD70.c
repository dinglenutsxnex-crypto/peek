uint64_t _ZSt13set_terminatePFvvE(void)

{
  char cVar1;
  bool bVar2;
  uint64_t *pxVar3;
  uint64_t param1;
  uint64_t ret;
  
  pxVar3 = pxRam00000000000bf9f8;
  do {
    ret = *pxVar3;
    cVar1 = '\x01';
    bVar2 = (bool)ExclusiveMonitorPass(pxVar3,0x10);
    if (bVar2) {
      *pxVar3 = param1;
      cVar1 = ExclusiveMonitorsStatus();
    }
  } while (cVar1 != '\0');
  return ret;
}