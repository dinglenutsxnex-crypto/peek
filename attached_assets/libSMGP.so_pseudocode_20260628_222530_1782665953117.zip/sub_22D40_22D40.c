int8_t * sub_22D40(void)

{
  jclass cls;
  int8_t *param1;
  int8_t val;
  uint8_t *puVar3;
  jobject obj;
  uint8_t *puVar5;
  int8_t *env;
  uint8_t axStack_8 [8];
  
  sub_3989C(axStack_8,(int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xd0);
  val = sub_2B34C(axStack_8);
  sub_3A188(axStack_8);
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
  puVar3 = (uint8_t *)env[2];
  if ((uint8_t *)env[3] <= puVar3) goto L_00022dec;
  do {
    obj = (uint8_t)*puVar3;
    while( true ) {
      if ((*(uint8_t *)(*(int8_t *)(val + 0x30) + (obj & 0xff)) >> 3 & 1) == 0) {
        return param1;
      }
      puVar5 = (uint8_t *)env[3];
      if ((uint8_t *)env[2] < puVar5) {
        puVar3 = (uint8_t *)env[2] + 1;
        env[2] = (int8_t)puVar3;
      }
      else {
        cls = (*env)->GetSuperclass(env);
        if (cls == -1) goto L_00022e04;
        puVar3 = (uint8_t *)env[2];
        puVar5 = (uint8_t *)env[3];
      }
      if (puVar3 < puVar5) break;
L_00022dec:
      obj = (*env)->ToReflectedMethod(env);
      if ((int32_t)obj == -1) {
L_00022e04:
        sub_1ED34();
        return param1;
      }
    }
  } while( true );
}