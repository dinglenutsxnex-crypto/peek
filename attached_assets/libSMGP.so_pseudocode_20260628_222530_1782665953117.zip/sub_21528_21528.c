int8_t * sub_21528(void)

{
  int8_t *param1;
  int8_t *piVar1;
  void *extraout_x0;
  void *param1;
  int8_t val1;

  uint32_t val2;
  uint32_t *param2;
  uint8_t axVar4 [16];
  char cStack_10;
  uint32_t uStack_c;
  int8_t iStack_8;

  sub_21204();
  if (cStack_10 != '\0') {
    uStack_c = 0;
    val1 = (int8_t)param1 + *(int8_t *)(*param1 + -0x18);
    piVar1 = *(int8_t **)(val1 + 0x100);
    if (piVar1 == (int8_t *)0x0) {
      axVar4 = sub_61E30();
      param1 = axVar4._0_8_;
      if (axVar4._8_8_ == 1) {
        __cxa_begin_catch(param1);
        param1 = (int8_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18));
        *(uint32_t *)(param1 + 4) = *(uint32_t *)(param1 + 4) | 1;
        if ((*(uint32_t *)((int8_t)param1 + 0x1c) & 1) == 0) {
          __cxa_rethrow();
          goto L_00021684;
        }
        __cxa_rethrow();
        param1 = extraout_x0;
      }
      __cxa_begin_catch(param1);
      val1 = *(int8_t *)(*param1 + -0x18);
      *(uint32_t *)((int8_t)param1 + val1 + 0x20) = *(uint32_t *)((int8_t)param1 + val1 + 0x20) | 1;
      if ((*(uint32_t *)((int8_t)param1 + val1 + 0x1c) & 1) != 0) {
L_00021684:
        __cxa_rethrow();
        __cxa_end_catch();
        sub_81F98(extraout_x0_00);
      }
      __cxa_end_catch();
    }
    else {
      (**(code **)(*piVar1 + 0x18))
                (piVar1,*(uint64_t *)(val1 + 0xe8),0xffffffff,0,0xffffffff,val1,&uStack_c,
                 &iStack_8);
      val2 = 0x80000000;
      if ((-0x80000001 < iStack_8) && (val2 = 0x7fffffff, iStack_8 < 0x80000000)) {
        *param2 = (int32_t)iStack_8;
        if (uStack_c == 0) {
          return param1;
        }
        goto L_000215dc;
      }
      *param2 = val2;
      uStack_c = uStack_c | 4;
    }
    if (uStack_c != 0) {
L_000215dc:
      sub_1ED34();
      return param1;
    }
  }
  return param1;
}