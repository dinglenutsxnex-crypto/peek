uint8_t _Z8valuesGGRKSsS0_S0_(void)

{
  char cVar1;
  bool bVar2;

  int8_t *param1;
  int8_t val1;
  uint8_t val2;
  uint8_t val3;
  int32_t *piVar7;
  int32_t val4;
  uint8_t unaff_x23;
  int8_t iStack_80;
  int8_t iStack_78;
  int8_t iStack_70;
  int8_t iStack_68;
  uint8_t axStack_60 [8];




  sub_63720(&iStack_68,0x8479e,&iStack_70);
  sub_63720(&iStack_70,0x8479e,&iStack_78);
  val1 = sub_649DC();
  sub_632EC(&iStack_78);
  if (val1 == -1) {
L_00016380:
    _Z14executeCommandRKSsS0_S0_S0_S0_(&iStack_78,&iStack_68,&iStack_70);
    val2 = unk_bff48;
    if (iStack_78 - 0x18U != unk_bff48) {
      piVar7 = (int32_t *)(iStack_78 + -8);
      if (pthread_create == 0) {
        val4 = *piVar7;
        *piVar7 = val4 + -1;
      }
      else {
        do {
          val4 = *piVar7;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
          if (bVar2) {
            *piVar7 = val4 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val4 < 1) {
        sub_66F0C(iStack_78 - 0x18U,&iStack_80);
      }
    }
    if (iStack_70 - 0x18U != val2) {
      piVar7 = (int32_t *)(iStack_70 + -8);
      if (pthread_create == 0) {
        val4 = *piVar7;
        *piVar7 = val4 + -1;
      }
      else {
        do {
          val4 = *piVar7;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
          if (bVar2) {
            *piVar7 = val4 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val4 < 1) {
        sub_66F0C(iStack_70 - 0x18U,&iStack_78);
      }
    }
    val3 = iStack_68 - 0x18;
    if (val3 != val2) {
      piVar7 = (int32_t *)(iStack_68 + -8);
      if (pthread_create == 0) {
        val4 = *piVar7;
        *piVar7 = val4 + -1;
      }
      else {
        do {
          val4 = *piVar7;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
          if (bVar2) {
            *piVar7 = val4 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val4 < 1) {
        val3 = sub_66F0C(val3,&iStack_70);
      }
    }



    __stack_chk_fail();
  }
  else {
    unaff_x23 = val1 + 1;
    val1 = sub_649DC();
    if (val1 == -1) {
      if (unaff_x23 <= *(uint8_t *)(*param1 + -0x18)) {
        sub_632EC(&iStack_80);
        sub_6473C(&iStack_68,&iStack_80);
        val2 = iStack_80 - 0x18;
        if (val2 != unk_bff48) {
          piVar7 = (int32_t *)(iStack_80 + -8);
          if (pthread_create == 0) {
L_00016510:
            val4 = *piVar7;
            *piVar7 = val4 + -1;
          }
          else {
            do {
              val4 = *piVar7;
              cVar1 = '\x01';
              bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
              if (bVar2) {
                *piVar7 = val4 + -1;
                cVar1 = ExclusiveMonitorsStatus();
              }
            } while (cVar1 != '\0');
          }
L_0001651c:
          if (val4 < 1) {
            sub_66F0C(val2,axStack_60);
          }
        }
        goto L_00016380;
      }
    }
    else if (unaff_x23 <= *(uint8_t *)(*param1 + -0x18)) {
      sub_632EC(&iStack_80);
      sub_6473C(&iStack_68,&iStack_80);
      unaff_x23 = unk_bff48;
      if (iStack_80 - 0x18U != unk_bff48) {
        piVar7 = (int32_t *)(iStack_80 + -8);
        if (pthread_create == 0) {
          val4 = *piVar7;
          *piVar7 = val4 + -1;
        }
        else {
          do {
            val4 = *piVar7;
            cVar1 = '\x01';
            bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
            if (bVar2) {
              *piVar7 = val4 + -1;
              cVar1 = ExclusiveMonitorsStatus();
            }
          } while (cVar1 != '\0');
        }
        if (val4 < 1) {
          sub_66F0C(iStack_80 - 0x18U,axStack_60);
        }
      }
      if (*(uint8_t *)(*param1 + -0x18) < val1 + 1U) goto L_0001656c;
      sub_632EC(&iStack_80);
      sub_6473C(&iStack_70,&iStack_80);
      val2 = iStack_80 - 0x18;
      if (val2 != unaff_x23) {
        piVar7 = (int32_t *)(iStack_80 + -8);
        if (pthread_create == 0) goto L_00016510;
        do {
          val4 = *piVar7;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
          if (bVar2) {
            *piVar7 = val4 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
        goto L_0001651c;
      }
      goto L_00016380;
    }
  }
  sub_6221C("%s: __pos (which is %zu) > this->size() (which is %zu)","basic_string::substr",unaff_x23);
L_0001656c:
  sub_6221C("%s: __pos (which is %zu) > this->size() (which is %zu)","basic_string::substr");
}