int8_t * sub_28034(void)

{
  jobject obj;
  int8_t *param1;
  int32_t *piVar2;
  uint8_t val1;
  int32_t val2;
  int32_t *param2;
  int8_t param3;
  int8_t val3;
  int8_t val4;
  int32_t param4;
  int32_t *piVar7;
  int8_t val5;
  uint8_t val6;
  int8_t *env;
  char cStack_8;
  
  param1[1] = 0;
  sub_24104();
  if (cStack_8 == '\0') {
L_000281c0:
    val3 = param1[1];
    val2 = 0;
L_000281c8:
    if (0 < param3) {
      *param2 = 0;
    }
    if ((val3 != 0) && (val2 == 0)) {
      return param1;
    }
    sub_1F6E0();
    return param1;
  }
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
  if ((int32_t *)env[2] < (int32_t *)env[3]) {
    obj = *(int32_t *)env[2];
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
  }
L_00028098:
  do {
    val3 = param1[1];
L_0002809c:
    val5 = val3 + 1;
    if (param4 == obj || obj == -1) {
L_0002815c:
      if (obj == -1) {
        val2 = 2;
        goto L_000281c8;
      }
      val2 = 4;
      if (param4 != obj) goto L_000281c8;
      val1 = env[2];
      val6 = env[3];
      param1[1] = val5;
      if (val6 <= val1) {
        (*env)->GetSuperclass(env);
        goto L_000281c0;
      }
      env[2] = val1 + 4;
      val2 = 0;
      val3 = val5;
      goto L_000281c8;
    }
    while( true ) {
      if (param3 <= val5) goto L_0002815c;
      piVar7 = (int32_t *)env[3];
      piVar2 = (int32_t *)env[2];
      val4 = (param3 - val3) + -1;
      val3 = (int8_t)piVar7 - (int8_t)piVar2 >> 2;
      if (val3 < val4) {
        val4 = val3;
      }
      if (val4 < 2) break;
      val3 = wmemchr(piVar2,param4,val4);
      if (val3 != 0) {
        val4 = val3 - env[2] >> 2;
      }
      wmemcpy(param2,env[2],val4);
      val5 = env[2];
      val3 = param1[1];
      param2 = param2 + val4;
      val6 = env[3];
      val1 = val5 + val4 * 4;
      env[2] = val1;
      val3 = val4 + val3;
      param1[1] = val3;
      if (val6 <= val1) {
        obj = (*env)->ToReflectedMethod(env);
        goto L_00028098;
      }
      obj = *(int32_t *)(val5 + val4 * 4);
      val5 = val3 + 1;
      if (param4 == obj || obj == -1) goto L_0002815c;
    }
    *param2 = obj;
    param1[1] = val5;
    param2 = param2 + 1;
    if (piVar2 < piVar7) {
      obj = *piVar2;
      env[2] = (int8_t)(piVar2 + 1);
    }
    else {
      obj = (*env)->GetSuperclass(env);
    }
    if (obj == -1) {
      val3 = param1[1];
      obj = -1;
      goto L_0002809c;
    }
    if ((int32_t *)env[2] < (int32_t *)env[3]) {
      obj = *(int32_t *)env[2];
      val3 = param1[1];
      goto L_0002809c;
    }
    obj = (*env)->ToReflectedMethod(env);
  } while( true );
}