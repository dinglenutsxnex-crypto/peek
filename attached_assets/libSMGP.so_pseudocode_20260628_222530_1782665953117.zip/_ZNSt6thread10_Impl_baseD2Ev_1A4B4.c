int8_t * _ZNSt6thread10_Impl_baseD2Ev(void)

{
  int8_t *piVar1;
  int32_t val1;
  char cVar3;
  bool bVar4;
  int8_t val2;
  int8_t *param1;
  uint64_t val3;
  int8_t *piVar7;
  int32_t *piVar8;
  
  piVar7 = (int8_t *)param1[2];
  *param1 = _ZTVNSt6thread10_Impl_baseE + 0x10;
  val2 = pthread_create;
  if (piVar7 != (int8_t *)0x0) {
    piVar1 = piVar7 + 1;
    if (pthread_create == 0) {
      val1 = (int32_t)*piVar1;
      *(int32_t *)piVar1 = val1 + -1;
    }
    else {
      do {
        val1 = (int32_t)*piVar1;
        cVar3 = '\x01';
        bVar4 = (bool)ExclusiveMonitorPass(piVar1,0x10);
        if (bVar4) {
          *(int32_t *)piVar1 = val1 + -1;
          cVar3 = ExclusiveMonitorsStatus();
        }
      } while (cVar3 != '\0');
    }
    if (val1 == 1) {
      piVar8 = (int32_t *)((int8_t)piVar7 + 0xc);
      param1 = (int8_t *)(**(code **)(*piVar7 + 0x10))(piVar7);
      if (val2 == 0) {
        val1 = *piVar8;
        *piVar8 = val1 + -1;
      }
      else {
        do {
          val1 = *piVar8;
          cVar3 = '\x01';
          bVar4 = (bool)ExclusiveMonitorPass(piVar8,0x10);
          if (bVar4) {
            *piVar8 = val1 + -1;
            cVar3 = ExclusiveMonitorsStatus();
          }
        } while (cVar3 != '\0');
      }
      if (val1 == 1) {
        val3 = (**(code **)(*piVar7 + 0x18))(piVar7);
        return (int8_t *)val3;
      }
    }
  }
  return param1;
}