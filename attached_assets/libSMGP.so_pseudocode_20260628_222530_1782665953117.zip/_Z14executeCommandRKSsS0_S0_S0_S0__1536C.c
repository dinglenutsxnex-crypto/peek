char * _Z14executeCommandRKSsS0_S0_S0_S0_(void)

{
  char cVar1;
  bool bVar2;

  char *pcVar4;

  int8_t *piVar5;
  char *pcVar6;
  int32_t *piVar7;
  int32_t val;
  char *pcStack_c8;
  int8_t iStack_c0;
  int8_t iStack_b8;
  int8_t iStack_b0;
  int8_t iStack_a8;
  int8_t iStack_a0;
  int8_t iStack_98;
  int8_t iStack_90;
  int8_t iStack_88;
  int8_t iStack_80;
  int8_t iStack_78;
  int8_t iStack_70;
  char *pcStack_68;
  uint8_t axStack_60 [8];

  sub_63720(&pcStack_68,"chmod 777 /data/data/com.soham.cheat/files/values",&iStack_70);
  system(pcStack_68);
  pcVar4 = pcRam00000000000bff48;
  pcVar6 = pcRam00000000000bff48 + 0x18;
  pcStack_c8 = pcVar6;
  sub_63BF0(&pcStack_c8,*(int8_t *)(*param1 + -0x18) + 0x2f);
  sub_6433C(&pcStack_c8,"su -c \"/data/data/com.soham.cheat/files/values ",0x2f);
  sub_6417C(&pcStack_c8);
  piVar5 = (int8_t *)sub_6433C(&pcStack_c8," ",1);
  iStack_c0 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6417C(&iStack_c0);
  iStack_b8 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6433C(&iStack_b8," ",1);
  iStack_b0 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6417C(&iStack_b0,packageName);
  iStack_a8 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6433C(&iStack_a8," ",1);
  iStack_a0 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6417C(&iStack_a0);
  iStack_98 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6433C(&iStack_98," ",1);
  iStack_90 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6417C(&iStack_90);
  iStack_88 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6433C(&iStack_88," ",1);
  iStack_80 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6417C(&iStack_80);
  iStack_78 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  piVar5 = (int8_t *)sub_6433C(&iStack_78,"\"",1);
  iStack_70 = *piVar5;
  *piVar5 = (int8_t)pcVar6;
  sub_6473C(&pcStack_68,&iStack_70);
  if ((char *)(iStack_70 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_70 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_70 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_78 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_78 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_78 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_80 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_80 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_80 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_88 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_88 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_88 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_90 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_90 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_90 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_98 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_98 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_98 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_a0 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_a0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_a0 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_a8 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_a8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_a8 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_b0 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_b0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_b0 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_b8 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_b8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_b8 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_c0 + -0x18) != pcVar4) {
    piVar7 = (int32_t *)(iStack_c0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C((char *)(iStack_c0 + -0x18),axStack_60);
    }
  }
  if (pcStack_c8 + -0x18 != pcVar4) {
    piVar7 = (int32_t *)(pcStack_c8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C(pcStack_c8 + -0x18,axStack_60);
    }
  }
  system(pcStack_68);
  pcVar6 = pcStack_68 + -0x18;
  if (pcVar6 != pcVar4) {
    piVar7 = (int32_t *)(pcStack_68 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      pcVar6 = (char *)sub_66F0C(pcVar6,&iStack_70);
    }
  }

  return pcVar6;
}