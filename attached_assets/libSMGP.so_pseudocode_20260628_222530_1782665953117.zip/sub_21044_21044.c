int8_t * sub_21044(void)

{
  int8_t *param1;
  code *param2;
  
  (*param2)((int8_t)param1 + *(int8_t *)(*param1 + -0x18));
  return param1;
}