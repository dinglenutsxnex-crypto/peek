int8_t * sub_25BA4(void)

{
  char cVar1;
  jobject obj;
  int8_t *param1;
  int8_t *piVar3;
  int32_t *piVar4;
  int8_t *env;
  uint8_t axStack_8 [8];
  
  sub_3989C(axStack_8,(int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xd0);
  piVar3 = (int8_t *)sub_4C214(axStack_8);
  sub_3A188(axStack_8);
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
  piVar4 = (int32_t *)env[2];
  if ((int32_t *)env[3] <= piVar4) goto L_00025c74;
  while (*piVar4 != -1) {
    while( true ) {
      cVar1 = (**(code **)(*piVar3 + 0x10))(piVar3,8);
      if (cVar1 == '\0') {
        return param1;
      }
      piVar4 = (int32_t *)env[2];
      if (piVar4 < (int32_t *)env[3]) {
        obj = *piVar4;
        env[2] = (int8_t)(piVar4 + 1);
      }
      else {
        obj = (*env)->GetSuperclass(env);
      }
      if (obj == -1) goto L_00025c90;
      piVar4 = (int32_t *)env[2];
      if (piVar4 < (int32_t *)env[3]) break;
L_00025c74:
      obj = (*env)->ToReflectedMethod(env);
      if (obj == -1) goto L_00025c90;
    }
  }
L_00025c90:
  sub_1F6E0();
  return param1;
}