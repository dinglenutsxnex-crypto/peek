uint64_t sub_25784(void)

{
  int8_t *param1;

  int8_t *env;
  char cStack_8;

  sub_24104();
  if ((cStack_8 == '\0') || ((*(uint32_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x20) & 5) != 0))
  {
    param1 = 0xffffffffffffffff;
  }
  else {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    param1 = (*env)->GetVersion(env,0,1,8);
  }

}