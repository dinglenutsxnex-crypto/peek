uint8_t sub_22158(void)

{
  jobject obj;
  int8_t *param1;
  int8_t *env;
  uint8_t ret;
  char cStack_8;
  
  param1[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') {
    ret = JNI_ERR;
  }
  else {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    if ((uint8_t *)env[2] < (uint8_t *)env[3]) {
      ret = (uint8_t)*(uint8_t *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod();
      ret = (uint8_t)obj;
      if (obj == JNI_ERR) {
        sub_1ED34();
        return JNI_ERR;
      }
    }
  }
  return ret;
}