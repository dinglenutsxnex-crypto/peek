int8_t * sub_27294(void)

{
  uint8_t param3;
  uint8_t val1;
  uint8_t val2;
  bool bVar3;
  uint32_t val3;
  jobject obj;
  int8_t *param1;
  void *pvVar6;
  uint64_t val4;
  int8_t param2;
  uint32_t param3;
  int8_t *env;
  uint8_t *puVar9;
  uint8_t *puVar10;
  int8_t val5;
  char cStack_8;
  
  if (param3 == JNI_ERR) {
    val4 = sub_6C9EC();
    return (int8_t *)val4;
  }
  param1[1] = 0;
  sub_21204();
  if ((param2 < 1) || (cStack_8 == '\0')) {
    return param1;
  }
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
  if ((uint8_t *)env[2] < (uint8_t *)env[3]) {
    obj = (uint32_t)*(uint8_t *)env[2];
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
  }
  val5 = param1[1];
  bVar3 = false;
L_00027320:
  do {
    val3 = obj;
    if (param3 == obj || obj == JNI_ERR) {
L_000273b0:
      if (bVar3) {
        param1[1] = 0x7fffffffffffffff;
      }
      if (obj == JNI_ERR) {
        sub_1ED34();
        return param1;
      }
      if (param3 != obj) {
        return param1;
      }
      if (param1[1] != 0x7fffffffffffffff) {
        param1[1] = param1[1] + 1;
      }
      if ((uint8_t)env[2] < (uint8_t)env[3]) {
        env[2] = env[2] + 1;
        return param1;
      }
      (*env)->GetSuperclass(env);
      return param1;
    }
    while (obj = val3, val5 < param2) {
      puVar10 = (uint8_t *)env[3];
      puVar9 = (uint8_t *)env[2];
      param3 = param2 - val5;
      if ((int8_t)puVar10 - (int8_t)puVar9 < param2 - val5) {
        param3 = (int8_t)puVar10 - (int8_t)puVar9;
      }
      if ((int8_t)param3 < 2) {
        param1[1] = val5 + 1;
        if (puVar9 < puVar10) {
          puVar9 = puVar9 + 1;
          env[2] = (int8_t)puVar9;
L_00027420:
          if (puVar10 <= puVar9) goto L_00027434;
          obj = (uint32_t)*puVar9;
          val5 = param1[1];
        }
        else {
          obj = (*env)->GetSuperclass(env);
          if (obj != JNI_ERR) {
            puVar9 = (uint8_t *)env[2];
            puVar10 = (uint8_t *)env[3];
            goto L_00027420;
          }
L_00027444:
          val5 = param1[1];
        }
        goto L_00027320;
      }
      pvVar6 = memchr(puVar9,param3 & 0xff,param3);
      val1 = (int8_t)pvVar6 - (int8_t)puVar9;
      if (pvVar6 == (void *)0x0) {
        val1 = param3;
      }
      env[2] = (int8_t)(puVar9 + val1);
      val5 = val5 + val1;
      param1[1] = val5;
      if (puVar10 <= puVar9 + val1) {
L_00027434:
        obj = (*env)->ToReflectedMethod(env);
        goto L_00027444;
      }
      val2 = puVar9[val1];
      obj = (uint32_t)val2;
      val3 = (uint32_t)val2;
      if (param3 == val2 || val2 == JNI_ERR) goto L_000273b0;
    }
    if (param2 != 0x7fffffffffffffff) goto L_000273b0;
    param1[1] = -0x8000000000000000;
    val5 = -0x8000000000000000;
    bVar3 = true;
  } while( true );
}