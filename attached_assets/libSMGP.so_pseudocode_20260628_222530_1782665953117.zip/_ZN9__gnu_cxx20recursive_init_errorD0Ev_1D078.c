uint64_t _ZN9__gnu_cxx20recursive_init_errorD0Ev(void)

{
  void *param1;
  uint64_t extraout_x0;
  
  _ZN9__gnu_cxx20recursive_init_errorD1Ev();
  _ZdlPv(param1);
  return extraout_x0;
}