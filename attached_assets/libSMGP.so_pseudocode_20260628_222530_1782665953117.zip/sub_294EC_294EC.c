uint8_t sub_294EC(void)

{
  uint8_t *param1;
  char *pcVar1;
  bool bVar2;
  uint32_t val1;
  uint8_t *puVar4;
  uint8_t val2;
  char *param2;
  char *param3;
  char *param4;
  char *param5;
  uint8_t unaff_x19;
  uint8_t ret;
  uint8_t *param1_00;
  uint8_t *unaff_x23;
  uint8_t *param1_01;
  uint8_t val3;
  uint8_t axStack_8 [8];
  
  if (param2 == param3) {
    param1_00 = puRam00000000000bff48 + 3;
    goto L_00029580;
  }
  if ((param2 == (char *)0x0) && (param3 != (char *)0x0)) {
    sub_61E98("basic_string::_S_construct null not valid");
  }
  unaff_x19 = (int8_t)param3 - (int8_t)param2;
  unaff_x23 = (uint8_t *)sub_65788(unaff_x19,0,axStack_8);
  param1_00 = unaff_x23 + 3;
  if (unaff_x19 == 1) goto L_0002959c;
  memcpy(param1_00,param2,unaff_x19);
  while( true ) {
    if (unaff_x23 != puRam00000000000bff48) {
      *(uint32_t *)(unaff_x23 + 2) = 0;
      *unaff_x23 = unaff_x19;
      *(char *)((int8_t)unaff_x23 + unaff_x19 + 0x18) = '\0';
    }
L_00029580:
    if (param4 == param5) {
      param1_01 = puRam00000000000bff48 + 3;
      goto L_000295e0;
    }
    if ((param4 != (char *)0x0) || (param5 == (char *)0x0)) break;
    sub_61E98("basic_string::_S_construct null not valid");
L_0002959c:
    *(char *)(unaff_x23 + 3) = *param2;
  }
  ret = (int8_t)param5 - (int8_t)param4;
  puVar4 = (uint8_t *)sub_65788(ret,0,axStack_8);
  param1_01 = puVar4 + 3;
  if (ret == 1) {
    *(char *)(puVar4 + 3) = *param4;
  }
  else {
    memcpy(param1_01,param4,ret);
  }
  if (puVar4 != puRam00000000000bff48) {
    *(uint32_t *)(puVar4 + 2) = 0;
    *puVar4 = ret;
    *(char *)((int8_t)puVar4 + ret + 0x18) = '\0';
  }
L_000295e0:
  val3 = param1_00[-3];
  ret = param1_01[-3];
  val1 = sub_6FFA4();
  puVar4 = param1_00;
  param1 = param1_01;
  while (val1 == 0) {
    val2 = strlen((char *)puVar4);
    pcVar1 = (char *)((int8_t)puVar4 + val2);
    val2 = strlen((char *)param1);
    bVar2 = pcVar1 == (char *)((int8_t)param1_00 + val3);
    if ((char *)((int8_t)param1 + val2) == (char *)((int8_t)param1_01 + ret)) {
      ret = (uint8_t)!bVar2;
L_00029640:
      if (param1_01 + -3 != puRam00000000000bff48) goto L_000296b0;
      goto L_00029650;
    }
    if (bVar2) {
      ret = 0xffffffff;
      goto L_00029640;
    }
    puVar4 = (uint8_t *)(pcVar1 + 1);
    param1 = (uint8_t *)((char *)((int8_t)param1 + val2) + 1);
    val1 = sub_6FFA4();
  }
  ret = (uint8_t)val1;
  if (param1_01 + -3 == puRam00000000000bff48) {
L_00029650:
    if (param1_00 + -3 != puRam00000000000bff48) goto L_000296cc;
  }
  else {
L_000296b0:
    sub_29454(param1_01 + -3,axStack_8);
    if (param1_00 + -3 != puRam00000000000bff48) {
L_000296cc:
      sub_29454(param1_00 + -3,axStack_8);
      return ret;
    }
  }
  return ret;
}