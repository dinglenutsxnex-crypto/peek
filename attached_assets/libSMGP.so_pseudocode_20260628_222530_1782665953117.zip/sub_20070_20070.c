uint64_t * sub_20070(void)

{
  uint64_t val1;
  int32_t val2;
  uint32_t val3;
  int8_t param1;
  uint64_t *pxVar4;
  uint64_t *pxVar5;
  void *param1;
  int32_t param2;
  uint64_t *pxVar6;
  char param3;
  uint64_t *pxVar8;
  int8_t val4;
  int32_t val5;
  uint8_t axVar11 [16];
  uint64_t *pxVar7;
  
  if (param2 < 8) {
    val5 = 8;
    pxVar4 = (uint64_t *)(param1 + 0x40);
L_00020128:
    *(uint64_t **)(param1 + 200) = pxVar4;
    *(int32_t *)(param1 + 0xc0) = val5;
    return pxVar4 + (int8_t)param2 * 2;
  }
  if (param2 != 0x7fffffff) {
    val5 = param2 + 1;
    val4 = (int8_t)val5;
    pxVar4 = _Znam(val4 << 4);
    pxVar5 = pxVar4;
    do {
      *pxVar5 = 0;
      val4 = val4 + -1;
      pxVar5[1] = 0;
      pxVar5 = pxVar5 + 2;
    } while (val4 != 0);
    val2 = *(int32_t *)(param1 + 0xc0);
    if (val2 < 1) {
      pxVar5 = *(uint64_t **)(param1 + 200);
    }
    else {
      pxVar5 = *(uint64_t **)(param1 + 200);
      pxVar6 = pxVar5;
      pxVar8 = pxVar4;
      do {
        pxVar7 = pxVar6 + 2;
        val1 = pxVar6[1];
        *pxVar8 = *pxVar6;
        pxVar8[1] = val1;
        pxVar6 = pxVar7;
        pxVar8 = pxVar8 + 2;
      } while (pxVar7 != pxVar5 + ((uint8_t)(val2 - 1) + 1) * 2);
    }
    if ((pxVar5 != (uint64_t *)0x0) && ((uint64_t *)(param1 + 0x40) != pxVar5)) {
      _ZdaPv(pxVar5);
    }
    goto L_00020128;
  }
  val3 = *(uint32_t *)(param1 + 0x20) | 1;
  *(uint32_t *)(param1 + 0x20) = val3;
  if ((val3 & *(uint32_t *)(param1 + 0x1c)) == 0) {
    if (param3 == '\0') {
      *(uint64_t *)(param1 + 0x30) = 0;
    }
    else {
      *(uint64_t *)(param1 + 0x38) = 0;
    }
    return (uint64_t *)(param1 + 0x30);
  }
  axVar11 = sub_62640("ios_base::_M_grow_words is not valid");
  param1 = axVar11._0_8_;
  if (axVar11._8_8_ != 1) {
    param1 = (void *)sub_81F98();
  }
  __cxa_begin_catch(param1);
  val3 = *(uint32_t *)(param1 + 0x20) | 1;
  *(uint32_t *)(param1 + 0x20) = val3;
  if ((val3 & *(uint32_t *)(param1 + 0x1c)) == 0) {
    if (param3 != '\0') {
      *(uint64_t *)(param1 + 0x38) = 0;
      goto L_000201d8;
    }
  }
  else {
    sub_62640("ios_base::_M_grow_words allocation failed");
  }
  *(uint64_t *)(param1 + 0x30) = 0;
L_000201d8:
  __cxa_end_catch();
  return (uint64_t *)(param1 + 0x30);
}