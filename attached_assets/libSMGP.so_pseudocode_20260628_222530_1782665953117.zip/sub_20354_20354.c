uint64_t sub_20354(void)

{
  uint64_t *param1;
  uint64_t *param1;
  uint64_t extraout_x0;
  
  *param1 = 0xba600;
  sub_20210();
  sub_20278();
  param1 = (uint64_t *)param1[0x19];
  if (param1 != param1 + 8) {
    if (param1 != (uint64_t *)0x0) {
      _ZdaPv(param1);
    }
    param1[0x19] = 0;
  }
  sub_3A188(param1 + 0x1a);
  _ZdlPv(param1);
  return extraout_x0;
}