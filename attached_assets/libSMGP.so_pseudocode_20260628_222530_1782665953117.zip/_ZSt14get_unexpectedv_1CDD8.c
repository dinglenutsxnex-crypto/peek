uint64_t _ZSt14get_unexpectedv(void)

{
  return *pxRam00000000000bfd10;
}