uint8_t sub_20B38(void)

{
  int8_t val1;
  uint8_t val2;
  uint8_t *puVar3;
  uint8_t param1;

  uint8_t axStack_8 [8];

  puVar3 = puRam00000000000bff60;
  val2 = *puRam00000000000bff60;
  if (val2 <= param1) {
    return (uint8_t)(uint32_t)val2;
  }
  sub_203B4();
  *puVar3 = param1;
  val1 = unk_bfc70 + 0x10;
  param1 = piRam00000000000bfc60 + 7;
  *piRam00000000000bfc60 = val1;
  sub_3A188(piVar4);
  param1 = piRam00000000000bf9e0 + 7;
  *piRam00000000000bf9e0 = val1;
  sub_3A188(piVar4);
  param1 = piRam00000000000bfeb8 + 7;
  *piRam00000000000bfeb8 = val1;
  sub_3A188(piVar4);
  val1 = unk_bfd08 + 0x10;
  param1 = piRam00000000000bfb50 + 7;
  *piRam00000000000bfb50 = val1;
  sub_3A188(piVar4);
  param1 = piRam00000000000bfbd8 + 7;
  *piRam00000000000bfbd8 = val1;
  sub_3A188(piVar4);
  param1 = piRam00000000000bfbb0 + 7;
  *piRam00000000000bfbb0 = val1;
  sub_3A188(piVar4);
  sub_703AC(unk_bfa40,__sF + 0x98,0x10,0x400);
  sub_703AC(unk_bfc10,__sF,8,0x400);
  sub_703AC(unk_bfb20,__sF + 0x130,0x10,0x400);
  sub_1EF9C();
  sub_1EF9C();
  sub_1EF9C();
  sub_1EF9C();
  sub_70600(unk_bfbf8,__sF + 0x98,0x10,0x400);
  sub_70600(unk_bfd90,__sF,8,0x400);
  sub_70600(unk_bffa8,__sF + 0x130,0x10,0x400);
  sub_1F948();
  sub_1F948();
  sub_1F948();
  sub_1F948();
  sub_20A8C(axStack_8);
  return (uint8_t)(uint32_t)val2;
}