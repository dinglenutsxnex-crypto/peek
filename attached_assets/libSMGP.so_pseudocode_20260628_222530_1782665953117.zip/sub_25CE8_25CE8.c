int8_t * sub_25CE8(void)

{
  jclass cls;
  int8_t *param1;
  int8_t *env;
  int32_t *param2;
  int32_t *piVar3;
  char cStack_8;
  
  sub_24104();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    piVar3 = (int32_t *)env[2];
    if (piVar3 < (int32_t *)env[3]) {
      cls = *piVar3;
      env[2] = (int8_t)(piVar3 + 1);
    }
    else {
      cls = (*env)->GetSuperclass();
    }
    if (cls == -1) {
      sub_1F6E0();
      return param1;
    }
    *param2 = cls;
  }
  return param1;
}