uint64_t sub_28F04(void)

{
  uint64_t *param1;
  uint64_t extraout_x0;
  
  *param1 = 0xba940;
  sub_3CB0C();
  _ZdlPv(param1);
  return extraout_x0;
}