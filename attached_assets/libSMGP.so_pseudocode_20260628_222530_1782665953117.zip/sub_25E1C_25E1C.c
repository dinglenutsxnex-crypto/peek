int8_t * sub_25E1C(void)

{
  char cVar1;
  jobject obj;
  int8_t *param1;
  int8_t *piVar3;
  int32_t *piVar4;
  int32_t *param2;
  int32_t *piVar5;
  int8_t *env;
  int8_t val1;
  int32_t *piVar8;
  int8_t val2;
  char cStack_10;
  uint8_t axStack_8 [8];
  
  sub_24104();
  if (cStack_10 != '\0') {
    val2 = *(int8_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10);
    if (val2 < 1) {
      val2 = 0x7fffffffffffffff;
    }
    sub_3989C(axStack_8,(int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xd0);
    piVar3 = (int8_t *)sub_4C214(axStack_8);
    sub_3A188(axStack_8);
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    if ((int32_t *)env[2] < (int32_t *)env[3]) {
      obj = *(int32_t *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod(env);
    }
    val1 = 0;
L_00025ec0:
    piVar8 = param2;
    if (val1 < val2 + -1) {
      while( true ) {
        param2 = piVar8;
        if (obj == -1) goto L_00025fbc;
        cVar1 = (**(code **)(*piVar3 + 0x10))(piVar3,8,obj);
        if (cVar1 != '\0') goto L_00025ef0;
        piVar5 = (int32_t *)env[2];
        val1 = val1 + 1;
        piVar4 = (int32_t *)env[3];
        param2 = piVar8 + 1;
        *piVar8 = obj;
        if (piVar5 < piVar4) {
          obj = *piVar5;
          env[2] = (int8_t)(piVar5 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj == -1) goto L_00025ec0;
        if ((int32_t *)env[3] <= (int32_t *)env[2]) break;
        obj = *(int32_t *)env[2];
        piVar8 = param2;
        if (val2 + -1 <= val1) goto L_00025fbc;
      }
      obj = (*env)->ToReflectedMethod(env);
      goto L_00025ec0;
    }
L_00025fbc:
    if (obj == -1) {
      val2 = *param1;
      *param2 = 0;
      *(uint64_t *)((int8_t)param1 + *(int8_t *)(val2 + -0x18) + 0x10) = 0;
    }
    else {
L_00025ef0:
      val2 = *param1;
      *param2 = 0;
      *(uint64_t *)((int8_t)param1 + *(int8_t *)(val2 + -0x18) + 0x10) = 0;
      if (val1 != 0) {
        return param1;
      }
    }
  }
  sub_1F6E0();
  return param1;
}