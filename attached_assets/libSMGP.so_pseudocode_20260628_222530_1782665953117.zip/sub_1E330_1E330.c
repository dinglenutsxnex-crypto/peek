void * sub_1E330(void)

{
  int8_t val;
  int8_t *param1;
  void *pvVar2;
  int8_t param3;
  uint8_t param4;
  int8_t param5;
  
  *(uint32_t *)(param1 + 1) = (uint32_t)(param5 != 0);
  val = unk_bff40;
  param1[4] = 0;
  *(uint8_t *)(param1 + 3) = param4 & param3 != 0;
  *param1 = val + 0x10;
  param1[5] = 0;
  if (param3 == 0) {
    param3 = *piRam00000000000bfec0 + 1;
  }
  param1[6] = param3;
  memset((void *)((int8_t)param1 + 0x39),0,0x100);
  *(uint8_t *)(param1 + 7) = 0;
  pvVar2 = memset((void *)((int8_t)param1 + 0x139),0,0x100);
  *(uint8_t *)((int8_t)param1 + 0x239) = 0;
  return pvVar2;
}