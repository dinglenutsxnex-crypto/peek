int8_t * sub_28358(void)

{
  uint8_t val1;
  bool bVar2;
  jobject obj;
  int8_t *param1;
  int32_t *piVar4;
  uint64_t val2;
  int8_t param2;
  int8_t val3;
  int32_t param3;
  int8_t val4;
  int32_t *piVar8;
  uint8_t val5;
  int8_t val6;
  int8_t *env;
  char cStack_8;
  
  if (param3 == -1) {
    val2 = sub_6CC58();
    return (int8_t *)val2;
  }
  param1[1] = 0;
  sub_24104();
  if ((param2 < 1) || (cStack_8 == '\0')) {
    return param1;
  }
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
  if ((int32_t *)env[2] < (int32_t *)env[3]) {
    obj = *(int32_t *)env[2];
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
  }
  val3 = param1[1];
  bVar2 = false;
L_000283dc:
  do {
    if (param3 == obj || obj == -1) {
L_00028478:
      if (bVar2) {
        param1[1] = 0x7fffffffffffffff;
      }
      if (obj == -1) {
        sub_1F6E0();
        return param1;
      }
      if (param3 != obj) {
        return param1;
      }
      if (param1[1] != 0x7fffffffffffffff) {
        param1[1] = param1[1] + 1;
      }
      if ((uint8_t)env[2] < (uint8_t)env[3]) {
        env[2] = env[2] + 4;
        return param1;
      }
      (*env)->GetSuperclass(env);
      return param1;
    }
    while (val3 < param2) {
      piVar8 = (int32_t *)env[3];
      piVar4 = (int32_t *)env[2];
      val4 = (int8_t)piVar8 - (int8_t)piVar4 >> 2;
      val6 = param2 - val3;
      if (val4 < param2 - val3) {
        val6 = val4;
      }
      if (val6 < 2) {
        param1[1] = val3 + 1;
        if (piVar4 < piVar8) {
          obj = *piVar4;
          env[2] = (int8_t)(piVar4 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj == -1) {
          val3 = param1[1];
          obj = -1;
        }
        else if ((int32_t *)env[2] < (int32_t *)env[3]) {
          obj = *(int32_t *)env[2];
          val3 = param1[1];
        }
        else {
L_00028504:
          obj = (*env)->ToReflectedMethod(env);
          val3 = param1[1];
        }
        goto L_000283dc;
      }
      val3 = wmemchr(piVar4,param3,val6);
      val4 = env[2];
      if (val3 != 0) {
        val6 = val3 - val4 >> 2;
      }
      val3 = param1[1];
      val1 = val4 + val6 * 4;
      val5 = env[3];
      env[2] = val1;
      val3 = val6 + val3;
      param1[1] = val3;
      if (val5 <= val1) goto L_00028504;
      obj = *(int32_t *)(val4 + val6 * 4);
      if (param3 == obj || obj == -1) goto L_00028478;
    }
    if (param2 != 0x7fffffffffffffff) goto L_00028478;
    param1[1] = -0x8000000000000000;
    val3 = -0x8000000000000000;
    bVar2 = true;
  } while( true );
}