int8_t _ZNSt6vectorISsSaISsEE19_M_emplace_back_auxIJRKSsEEEvDpOT_(void)

{
  uint8_t val1;
  uint8_t val2;
  int8_t *piVar3;
  char cVar4;
  bool bVar5;

  int8_t val3;
  int8_t val4;
  int8_t val5;
  int8_t *param1;
  int8_t *piVar10;
  int8_t val6;
  int8_t extraout_x0;
  uint8_t val7;
  int32_t *piVar13;
  int32_t val8;
  int8_t *piVar15;
  int8_t *piVar16;
  int8_t *piVar17;
  int8_t *param1;
  uint8_t axStack_70 [8];




  val7 = param1[1] - *param1 >> 3;
  val2 = val7;
  if (param1[1] - *param1 == 0) {
    val2 = 1;
  }
  val1 = 0x1fffffffffffffff;
  if (!((unsigned long long)(val2) + (unsigned long long)(val7) < (unsigned long long)(val2)) && val2 + val7 >> 0x3d == 0) {
    val1 = val2 + val7;
  }
  if (val1 == 0) {
    piVar10 = (int8_t *)0x0;
  }
  else {
    if (val1 >> 0x3d != 0) goto L_0001a480;
    piVar10 = _Znwm(val1 << 3);
    val7 = param1[1] - *param1 >> 3;
  }
  val6 = sub_67090(piVar10 + val7);
  val5 = unk_bff48;
  param1 = (int8_t *)*param1;
  piVar3 = (int8_t *)param1[1];
  if (param1 == piVar3) {
    piVar3 = piVar10 + 1;
  }
  else {
    val6 = unk_bff48 + 0x18;
    piVar15 = piVar10;
    piVar16 = param1;
    do {
      *piVar15 = *piVar16;
      piVar17 = piVar16 + 1;
      *piVar16 = val6;
      val4 = pthread_create;
      piVar15 = piVar15 + 1;
      piVar16 = piVar17;
    } while (piVar3 != piVar17);
    val3 = -8 - (int8_t)param1;
    do {
      val6 = *param1 + -0x18;
      if (val6 != val5) {
        piVar13 = (int32_t *)(*param1 + -8);
        if (val4 == 0) {
          val8 = *piVar13;
          *piVar13 = val8 + -1;
        }
        else {
          do {
            val8 = *piVar13;
            cVar4 = '\x01';
            bVar5 = (bool)ExclusiveMonitorPass(piVar13,0x10);
            if (bVar5) {
              *piVar13 = val8 + -1;
              cVar4 = ExclusiveMonitorsStatus();
            }
          } while (cVar4 != '\0');
        }
        if (val8 < 1) {
          val6 = sub_66F0C(val6,axStack_70);
        }
      }
      param1 = param1 + 1;
    } while (param1 != piVar3);
    param1 = (int8_t *)*param1;
    piVar3 = (int8_t *)((int8_t)piVar10 + ((int8_t)piVar3 + val3 & 0xfffffffffffffff8U) + 0x10);
  }
  if (param1 != (int8_t *)0x0) {
    _ZdlPv(param1);
    val6 = extraout_x0;
  }
  *param1 = (int8_t)piVar10;
  param1[1] = (int8_t)piVar3;
  param1[2] = (int8_t)(piVar10 + val1);



  __stack_chk_fail();
L_0001a480:
  sub_61DFC();
}