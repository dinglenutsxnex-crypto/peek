uint64_t sub_29078(void)

{
  uint64_t *param1;
  uint64_t extraout_x0;
  
  *param1 = 0xbaa10;
  sub_397CC();
  _ZdlPv(param1);
  return extraout_x0;
}