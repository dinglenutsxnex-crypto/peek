int8_t * sub_278EC(void)

{
  uint8_t *puVar1;
  uint8_t val1;
  uint8_t val2;
  uint32_t val3;
  jclass cls;
  int8_t *param1;
  int8_t val4;
  jobject obj;
  uint8_t *puVar8;
  int8_t *param2;
  int8_t val5;
  int8_t val6;
  uint8_t *puVar11;
  int8_t val7;
  uint8_t *puVar13;
  int8_t *env;
  uint8_t *puVar15;
  char cStack_10;
  uint8_t axStack_8 [8];
  
  sub_21204();
  if (cStack_10 != '\0') {
    sub_65820();
    puVar15 = *(uint8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10);
    if ((int8_t)puVar15 < 1) {
      puVar15 = (uint8_t *)0x3ffffffffffffff9;
    }
    sub_3989C(axStack_8,(int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xd0);
    val4 = sub_2B34C(axStack_8);
    sub_3A188(axStack_8);
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    if ((uint8_t *)env[2] < (uint8_t *)env[3]) {
      obj = (uint8_t)*(uint8_t *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod(env);
      if ((int32_t)obj == -1) {
L_00027ba8:
        *(uint64_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10) = 0;
        goto L_00027930;
      }
    }
    val7 = *(int8_t *)(val4 + 0x30);
    puVar13 = (uint8_t *)0x0;
    val2 = *(uint8_t *)(val7 + (obj & 0xff));
    while ((val2 >> 3 & 1) == 0) {
      val5 = env[2];
      val6 = (int8_t)puVar15 - (int8_t)puVar13;
      if (env[3] - val5 < (int8_t)puVar15 - (int8_t)puVar13) {
        val6 = env[3] - val5;
      }
      if (val6 < 2) {
        val6 = *param2;
        val7 = *(int8_t *)(val6 + -0x18);
        val1 = val7 + 1;
        if ((*(uint8_t *)(val6 + -0x10) < val1) || (0 < *(int32_t *)(val6 + -8))) {
          sub_63BF0();
          val6 = *param2;
          val7 = *(int8_t *)(val6 + -0x18);
        }
        *(char *)(val6 + val7) = (char)obj;
        val7 = *param2;
        if (val7 + -0x18 != unk_bff48) {
          *(uint32_t *)(val7 + -8) = 0;
          *(uint8_t *)(val7 + -0x18) = val1;
          *(uint8_t *)(val7 + val1) = 0;
        }
        puVar13 = puVar13 + 1;
        puVar11 = (uint8_t *)env[3];
        if ((uint8_t *)env[2] < puVar11) {
          puVar8 = (uint8_t *)env[2] + 1;
          env[2] = (int8_t)puVar8;
        }
        else {
          cls = (*env)->GetSuperclass(env);
          if (cls == -1) goto L_00027ba8;
          puVar8 = (uint8_t *)env[2];
          puVar11 = (uint8_t *)env[3];
        }
        if (puVar8 < puVar11) {
          val2 = *puVar8;
          goto L_00027a68;
        }
L_00027b88:
        obj = (*env)->ToReflectedMethod(env);
        val3 = (uint32_t)obj;
        if (puVar15 <= puVar13) {
L_00027ab8:
          if (val3 != JNI_ERR) {
            *(uint64_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10) = 0;
            return param1;
          }
          *(uint64_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10) = 0;
          goto L_00027930;
        }
        if (val3 == JNI_ERR) goto L_00027ba8;
      }
      else {
        puVar11 = (uint8_t *)(val5 + 1);
        puVar8 = (uint8_t *)(val5 + val6);
        if (puVar11 < puVar8) {
          val2 = *(uint8_t *)(val7 + (uint8_t)*(uint8_t *)(val5 + 1));
          while (((val2 >> 3 & 1) == 0 &&
                 (puVar1 = puVar11 + 1, puVar11 = puVar8, puVar1 != puVar8))) {
            val2 = *(uint8_t *)(val7 + (uint8_t)*puVar1);
            puVar11 = puVar1;
          }
        }
        sub_6433C();
        val7 = env[2];
        puVar13 = puVar11 + ((int8_t)puVar13 - val5);
        env[2] = (int8_t)(puVar11 + (val7 - val5));
        if ((uint8_t *)env[3] <= puVar11 + (val7 - val5)) goto L_00027b88;
        val2 = puVar11[val7 - val5];
L_00027a68:
        obj = (uint8_t)val2;
        val3 = (uint32_t)val2;
        if (puVar15 <= puVar13) goto L_00027ab8;
      }
      val7 = *(int8_t *)(val4 + 0x30);
      val2 = *(uint8_t *)(val7 + (obj & 0xff));
    }
    *(uint64_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10) = 0;
    if (puVar13 != (uint8_t *)0x0) {
      return param1;
    }
  }
L_00027930:
  sub_1ED34();
  return param1;
}