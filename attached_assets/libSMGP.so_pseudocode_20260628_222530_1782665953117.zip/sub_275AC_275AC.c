int8_t * sub_275AC(void)

{
  uint8_t *puVar1;
  uint8_t val1;
  uint32_t val2;
  jclass cls;
  int8_t *param1;
  int8_t val3;
  jobject obj;
  uint8_t *puVar7;
  uint8_t *param2;
  void *param2;
  uint8_t *puVar8;
  int8_t val4;
  int8_t val5;
  uint8_t param3;
  int8_t *env;
  uint8_t *param1;
  int8_t val6;
  int8_t val7;
  char cStack_10;
  uint8_t axStack_8 [8];
  
  sub_21204();
  if (cStack_10 != '\0') {
    val7 = *(int8_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10);
    if (val7 < 1) {
      val7 = 0x7fffffffffffffff;
    }
    sub_3989C(axStack_8,(int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xd0);
    val3 = sub_2B34C(axStack_8);
    sub_3A188(axStack_8);
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    if ((uint8_t *)env[2] < (uint8_t *)env[3]) {
      obj = (uint8_t)*(uint8_t *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod(env);
    }
    val6 = 0;
L_00027650:
    val2 = (uint32_t)obj;
    param1 = param2;
    if (val6 < val7 + -1) {
      while( true ) {
        val2 = (uint32_t)obj;
        param2 = param1;
        if (val2 == JNI_ERR) goto L_0002777c;
        val5 = *(int8_t *)(val3 + 0x30);
        if ((*(uint8_t *)(val5 + (obj & 0xff)) >> 3 & 1) != 0) goto L_00027674;
        param2 = (void *)env[2];
        val4 = (val7 - val6) + -1;
        if (env[3] - (int8_t)param2 < val4) {
          val4 = env[3] - (int8_t)param2;
        }
        if (val4 < 2) {
          *param1 = (char)obj;
          param2 = param1 + 1;
          val6 = val6 + 1;
          puVar8 = (uint8_t *)env[3];
          if ((uint8_t *)env[2] < puVar8) {
            puVar7 = (uint8_t *)env[2] + 1;
            env[2] = (int8_t)puVar7;
          }
          else {
            cls = (*env)->GetSuperclass(env);
            obj = JNI_ERR;
            if (cls == -1) goto L_00027650;
            puVar7 = (uint8_t *)env[2];
            puVar8 = (uint8_t *)env[3];
          }
          if (puVar7 < puVar8) {
            obj = (uint8_t)*puVar7;
          }
          else {
            obj = (*env)->ToReflectedMethod(env);
          }
          goto L_00027650;
        }
        puVar8 = (uint8_t *)((int8_t)param2 + 1);
        puVar7 = (uint8_t *)((int8_t)param2 + val4);
        if (puVar8 < puVar7) {
          val1 = *(uint8_t *)(val5 + (uint8_t)*(uint8_t *)((int8_t)param2 + 1));
          while (((val1 >> 3 & 1) == 0 && (puVar1 = puVar8 + 1, puVar8 = puVar7, puVar1 != puVar7))
                ) {
            val1 = *(uint8_t *)(val5 + (uint8_t)*puVar1);
            puVar8 = puVar1;
          }
        }
        param3 = (int8_t)puVar8 - (int8_t)param2;
        param2 = param1 + param3;
        val6 = val6 + param3;
        memcpy(param1,param2,param3);
        val5 = env[2];
        obj = val5 + param3;
        env[2] = obj;
        if ((uint8_t)env[3] <= obj) break;
        val1 = *(uint8_t *)(val5 + param3);
        obj = (uint8_t)val1;
        val2 = (uint32_t)val1;
        param1 = param2;
        if (val7 + -1 <= val6) goto L_0002777c;
      }
      obj = (*env)->ToReflectedMethod(env);
      goto L_00027650;
    }
L_0002777c:
    if (val2 == JNI_ERR) {
      *param2 = 0;
      *(uint64_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10) = 0;
    }
    else {
L_00027674:
      *param2 = 0;
      *(uint64_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0x10) = 0;
      if (val6 != 0) {
        return param1;
      }
    }
  }
  sub_1ED34();
  return param1;
}