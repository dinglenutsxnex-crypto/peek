int8_t _Z9valuesGG3RKSsS0_S0_(void)

{
  char cVar1;
  bool bVar2;

  int8_t val1;
  int8_t *param1;
  int8_t val2;
  int32_t *piVar6;
  int32_t val3;
  int8_t iStack_60;
  int8_t iStack_58;
  uint8_t axStack_50 [8];




  val2 = sub_649DC(param1,0x3b,0);
  if (val2 != -1) {
    sub_632EC(&iStack_58);
    if (*(uint8_t *)(*param1 + -0x18) < val2 + 1U) goto L_00016c64;
    sub_632EC(&iStack_60);
    _Z15executeCommand3RKSsS0_S0_S0_(&iStack_58,&iStack_60);
    val1 = unk_bff48;
    if (iStack_60 + -0x18 != unk_bff48) {
      piVar6 = (int32_t *)(iStack_60 + -8);
      if (pthread_create == 0) {
        val3 = *piVar6;
        *piVar6 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar6;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar6,0x10);
          if (bVar2) {
            *piVar6 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        sub_66F0C(iStack_60 + -0x18,axStack_50);
      }
    }
    val2 = iStack_58 + -0x18;
    if (val2 != val1) {
      piVar6 = (int32_t *)(iStack_58 + -8);
      if (pthread_create == 0) {
        val3 = *piVar6;
        *piVar6 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar6;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar6,0x10);
          if (bVar2) {
            *piVar6 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        val2 = sub_66F0C(val2,&iStack_60);
      }
    }
  }



  __stack_chk_fail();
L_00016c64:
  sub_6221C("%s: __pos (which is %zu) > this->size() (which is %zu)","basic_string::substr");
}