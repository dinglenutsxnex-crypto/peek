uint8_t sub_217D8(void)

{
  int8_t *param1;
  jclass cls;
  uint8_t *puVar2;
  int8_t *env;
  char cStack_8;
  
  param1[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') {
    if (param1[1] == 0) {
L_0002186c:
      sub_1ED34();
      return JNI_ERR;
    }
    cls = JNI_ERR;
  }
  else {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    puVar2 = (uint8_t *)env[2];
    if (puVar2 < (uint8_t *)env[3]) {
      cls = (uint8_t)*puVar2;
      env[2] = (int8_t)(puVar2 + 1);
    }
    else {
      cls = (*env)->GetSuperclass(env);
      if ((int32_t)cls == -1) goto L_0002186c;
    }
    param1[1] = 1;
  }
  jclass cls;
}