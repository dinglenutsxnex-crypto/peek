uint64_t _ZSt13get_terminatev(void)

{
  return *pxRam00000000000bf9f8;
}