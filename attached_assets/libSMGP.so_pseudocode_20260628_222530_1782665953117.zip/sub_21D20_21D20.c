int8_t * sub_21D20(void)

{
  uint8_t val1;
  jclass cls;
  int8_t *param1;
  uint8_t *puVar3;
  uint32_t val2;
  int8_t *param2;
  uint8_t param3;
  uint8_t *puVar5;
  int8_t *env;
  jobject obj;
  uint32_t val3;
  char cStack_8;
  
  param1[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') goto L_00021e64;
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
  val3 = (uint32_t)param3;
  if ((uint8_t *)env[2] < (uint8_t *)env[3]) {
    val1 = *(uint8_t *)env[2];
    obj = (uint32_t)val1;
    val2 = (uint32_t)val1;
    if (val3 == obj) goto L_00021e64;
L_00021d8c:
    do {
      while( true ) {
        if ((uint8_t *)param2[5] < (uint8_t *)param2[6]) {
          *(uint8_t *)param2[5] = (char)val2;
          param2[5] = param2[5] + 1;
        }
        else {
          cls = (*param2)->Throw();
          if (cls == -1) goto L_00021dec;
        }
        puVar3 = (uint8_t *)env[2];
        puVar5 = (uint8_t *)env[3];
        param1[1] = param1[1] + 1;
        if (puVar3 < puVar5) {
          puVar3 = puVar3 + 1;
          env[2] = (int8_t)puVar3;
        }
        else {
          cls = (*env)->GetSuperclass(env);
          if (cls == -1) goto L_00021df4;
          puVar3 = (uint8_t *)env[2];
          puVar5 = (uint8_t *)env[3];
        }
        if (puVar5 <= puVar3) break;
        obj = (uint32_t)*puVar3;
        val2 = obj;
        if (val3 == obj) goto L_00021dec;
      }
      obj = (*env)->ToReflectedMethod(env);
      val2 = obj & 0xff;
    } while (val3 != obj && obj != JNI_ERR);
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
    val2 = obj & 0xff;
    if ((obj != JNI_ERR) && (val3 != obj)) goto L_00021d8c;
  }
L_00021dec:
  if (obj == JNI_ERR) {
L_00021df4:
    sub_1ED34();
    return param1;
  }
L_00021e64:
  if (param1[1] != 0) {
    return param1;
  }
  sub_1ED34();
  return param1;
}