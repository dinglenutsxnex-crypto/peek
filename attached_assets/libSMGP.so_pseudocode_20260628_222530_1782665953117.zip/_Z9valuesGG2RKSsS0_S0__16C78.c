int8_t _Z9valuesGG2RKSsS0_S0_(void)

{
  char cVar1;
  bool bVar2;

  int8_t val1;
  int8_t val2;
  int8_t *piVar6;
  int8_t ret;
  int8_t extraout_x0;
  int32_t *piVar8;
  int32_t val3;
  int8_t *piVar10;
  int8_t iStack_208;
  int8_t iStack_200;
  int8_t iStack_1f8;
  int8_t iStack_1f0;
  int8_t iStack_1e8;
  int8_t iStack_1e0;
  int8_t *piStack_1d8;
  int8_t *piStack_1d0;
  int8_t *piStack_1c8;
  uint8_t axStack_1c0 [8];
  int8_t aiStack_1b8 [10];
  uint8_t axStack_168 [16];
  int8_t iStack_158;
  uint8_t axStack_150 [264];




  piStack_1d8 = (int8_t *)0x0;
  piStack_1d0 = (int8_t *)0x0;
  piStack_1c8 = (int8_t *)0x0;
  sub_45854(aiStack_1b8);
  val2 = unk_bff48;
  iStack_1e0 = unk_bff48 + 0x18;
  piVar6 = (int8_t *)sub_27CE0(aiStack_1b8,&iStack_1e0,0x3b);
  ret = (int8_t)piVar6 + *(int8_t *)(*piVar6 + -0x18);
  piVar6 = (int8_t *)0x0;
  if (ret == 0) {
    piVar10 = (int8_t *)0x0;
  }
  else {
    piVar10 = (int8_t *)0x0;
    if ((*(uint32_t *)(ret + 0x20) & 5) == 0) {
      do {
        _ZNSt6vectorISsSaISsEE19_M_emplace_back_auxIJRKSsEEEvDpOT_(&piStack_1d8,&iStack_1e0);
        while( true ) {
          piVar6 = (int8_t *)sub_27CE0(aiStack_1b8,&iStack_1e0,0x3b);
          ret = (int8_t)piVar6 + *(int8_t *)(*piVar6 + -0x18);
          piVar6 = piStack_1d8;
          piVar10 = piStack_1d0;
          if ((ret == 0) || ((*(uint32_t *)(ret + 0x20) & 5) != 0)) goto L_00016d8c;
          if (piStack_1d0 == piStack_1c8) break;
          sub_67090(piStack_1d0,&iStack_1e0);
          piStack_1d0 = piStack_1d0 + 1;
        }
      } while( true );
    }
  }
L_00016d8c:
  if ((int8_t)piVar10 - (int8_t)piVar6 == 0x28) {
    sub_67090(&iStack_1e8,piVar6);
    sub_67090(&iStack_1f0,piStack_1d8 + 1);
    sub_67090(&iStack_1f8,piStack_1d8 + 2);
    sub_67090(&iStack_200,piStack_1d8 + 3);
    sub_67090(&iStack_208,piStack_1d8 + 4);
    _Z15executeCommand2RKSsS0_S0_S0_S0_S0_S0_
              (&iStack_1e8,&iStack_1f0,&iStack_1f8,&iStack_200,&iStack_208);
    if (iStack_208 + -0x18 != val2) {
      piVar8 = (int32_t *)(iStack_208 + -8);
      if (pthread_create == 0) {
        val3 = *piVar8;
        *piVar8 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar8;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar8,0x10);
          if (bVar2) {
            *piVar8 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        sub_66F0C(iStack_208 + -0x18,axStack_1c0);
      }
    }
    if (iStack_200 + -0x18 != val2) {
      piVar8 = (int32_t *)(iStack_200 + -8);
      if (pthread_create == 0) {
        val3 = *piVar8;
        *piVar8 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar8;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar8,0x10);
          if (bVar2) {
            *piVar8 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        sub_66F0C(iStack_200 + -0x18,&iStack_208);
      }
    }
    if (iStack_1f8 + -0x18 != val2) {
      piVar8 = (int32_t *)(iStack_1f8 + -8);
      if (pthread_create == 0) {
        val3 = *piVar8;
        *piVar8 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar8;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar8,0x10);
          if (bVar2) {
            *piVar8 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        sub_66F0C(iStack_1f8 + -0x18,&iStack_200);
      }
    }
    if (iStack_1f0 + -0x18 != val2) {
      piVar8 = (int32_t *)(iStack_1f0 + -8);
      if (pthread_create == 0) {
        val3 = *piVar8;
        *piVar8 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar8;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar8,0x10);
          if (bVar2) {
            *piVar8 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        sub_66F0C(iStack_1f0 + -0x18,&iStack_1f8);
      }
    }
    if (iStack_1e8 + -0x18 != val2) {
      piVar8 = (int32_t *)(iStack_1e8 + -8);
      if (pthread_create == 0) {
        val3 = *piVar8;
        *piVar8 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar8;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar8,0x10);
          if (bVar2) {
            *piVar8 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        sub_66F0C(iStack_1e8 + -0x18,&iStack_1f0);
      }
    }
  }
  if (iStack_1e0 + -0x18 != val2) {
    piVar8 = (int32_t *)(iStack_1e0 + -8);
    if (pthread_create == 0) {
      val3 = *piVar8;
      *piVar8 = val3 + -1;
    }
    else {
      do {
        val3 = *piVar8;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar8,0x10);
        if (bVar2) {
          *piVar8 = val3 + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val3 < 1) {
      sub_66F0C(iStack_1e0 + -0x18,&iStack_1e8);
    }
  }
  piVar6 = piRam00000000000bfc90;
  aiStack_1b8[0] = *piRam00000000000bfc90;
  ret = piRam00000000000bfc90[9];
  *(int8_t *)((int8_t)aiStack_1b8 + *(int8_t *)(aiStack_1b8[0] + -0x18)) = piRam00000000000bfc90[8];
  aiStack_1b8[3] = unk_bfd48 + 0x10;
  aiStack_1b8[2] = ret;
  if (iStack_158 + -0x18 != val2) {
    piVar8 = (int32_t *)(iStack_158 + -8);
    if (pthread_create == 0) {
      val3 = *piVar8;
      *piVar8 = val3 + -1;
    }
    else {
      do {
        val3 = *piVar8;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar8,0x10);
        if (bVar2) {
          *piVar8 = val3 + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val3 < 1) {
      sub_66F0C(iStack_158 + -0x18,&iStack_1e0);
    }
  }
  aiStack_1b8[3] = unk_bfc70 + 0x10;
  sub_3A188(axStack_168);
  aiStack_1b8[0] = piVar6[2];
  *(int8_t *)((int8_t)aiStack_1b8 + *(int8_t *)(aiStack_1b8[0] + -0x18)) = piVar6[3];
  aiStack_1b8[1] = 0;
  ret = sub_202FC(axStack_150);
  piVar10 = piStack_1d0;
  val1 = pthread_create;
  for (piVar6 = piStack_1d8; piVar6 != piVar10; piVar6 = piVar6 + 1) {
    ret = *piVar6 + -0x18;
    if (ret != val2) {
      piVar8 = (int32_t *)(*piVar6 + -8);
      if (val1 == 0) {
        val3 = *piVar8;
        *piVar8 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar8;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar8,0x10);
          if (bVar2) {
            *piVar8 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        ret = sub_66F0C(ret,aiStack_1b8);
      }
    }
  }
  if (piStack_1d8 != (int8_t *)0x0) {
    _ZdlPv(piStack_1d8);
    ret = extraout_x0;
  }



  return ret;
}