uint64_t sub_24104(void)

{
  char cVar1;
  jobject obj;
  uint8_t *param1;
  int8_t *param2;
  char param3;
  int32_t *piVar3;
  int8_t val;
  int8_t *env;
  int8_t *piVar6;
  
  val = *(int8_t *)(*param2 + -0x18);
  *param1 = 0;
  val = (int8_t)param2 + val;
  if (*(int32_t *)(val + 0x20) != 0) goto L_00024178;
  if (*(int8_t *)(val + 0xd8) == 0) {
    if (param3 != '\0') goto L_0002415c;
L_00024198:
    if ((*(uint32_t *)(val + 0x18) >> 0xc & 1) != 0) {
      env = *(int8_t **)(val + 0xe8);
      if ((int32_t *)env[2] < (int32_t *)env[3]) {
        obj = *(int32_t *)env[2];
      }
      else {
        obj = (*env)->ToReflectedMethod(env);
        val = (int8_t)param2 + *(int8_t *)(*param2 + -0x18);
      }
      piVar6 = *(int8_t **)(val + 0xf0);
      if (piVar6 == (int8_t *)0x0) {
        sub_61E30();
      }
      while (obj != -1) {
        cVar1 = (**(code **)(*piVar6 + 0x10))(piVar6,8);
        if (cVar1 == '\0') {
          val = (int8_t)param2 + *(int8_t *)(*param2 + -0x18);
          goto L_00024154;
        }
        piVar3 = (int32_t *)env[2];
        if (piVar3 < (int32_t *)env[3]) {
          obj = *piVar3;
          env[2] = (int8_t)(piVar3 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj == -1) break;
        if ((int32_t *)env[2] < (int32_t *)env[3]) {
          obj = *(int32_t *)env[2];
        }
        else {
          obj = (*env)->ToReflectedMethod(env);
        }
      }
      goto L_00024178;
    }
  }
  else {
    sub_3FF8C();
    val = (int8_t)param2 + *(int8_t *)(*param2 + -0x18);
    if (param3 == '\0') goto L_00024198;
  }
L_00024154:
  if (*(int32_t *)(val + 0x20) == 0) {
L_0002415c:
    *param1 = 1;
    return 1;
  }
L_00024178:
}