int8_t * sub_249C0(void)

{
  bool bVar1;
  jobject obj;
  int8_t *param1;
  int32_t *piVar3;
  int32_t *param2;
  int32_t *piVar4;
  int8_t param3;
  int32_t param4;
  int8_t val;
  int32_t *piVar6;
  int8_t *env;
  char cStack_8;
  
  param1[1] = 0;
  sub_24104();
  if (cStack_8 == '\0') {
    val = param1[1];
    bVar1 = false;
  }
  else {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    piVar3 = (int32_t *)env[2];
    if ((int32_t *)env[3] <= piVar3) goto L_00024a84;
L_00024a20:
    obj = *piVar3;
    while (val = param1[1], piVar3 = param2, obj != -1 && param4 != obj) {
      while( true ) {
        param2 = piVar3;
        if (param3 <= val + 1) goto L_00024ab4;
        piVar4 = (int32_t *)env[2];
        piVar6 = (int32_t *)env[3];
        param2 = piVar3 + 1;
        *piVar3 = obj;
        param1[1] = val + 1;
        if (piVar4 < piVar6) {
          obj = *piVar4;
          env[2] = (int8_t)(piVar4 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj == -1) break;
        piVar3 = (int32_t *)env[2];
        if (piVar3 < (int32_t *)env[3]) goto L_00024a20;
L_00024a84:
        obj = (*env)->ToReflectedMethod(env);
        val = param1[1];
        piVar3 = param2;
        if (obj == -1 || param4 == obj) goto L_00024ab4;
      }
    }
L_00024ab4:
    bVar1 = obj == -1;
  }
  if (0 < param3) {
    *param2 = 0;
  }
  if ((val != 0) && (!bVar1)) {
    return param1;
  }
  sub_1F6E0();
  return param1;
}