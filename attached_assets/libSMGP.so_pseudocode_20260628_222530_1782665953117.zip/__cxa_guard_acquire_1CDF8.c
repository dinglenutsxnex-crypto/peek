uint64_t __cxa_guard_acquire(void)

{
  int32_t val;
  char cVar2;
  bool bVar3;
  int32_t *param1;
  uint64_t ret;
  int8_t *param1;
  
  if (__google_potentially_blocking_region_begin != 0) {
    __google_potentially_blocking_region_begin();
  }
  if ((char)*param1 == '\0') {
    if (pthread_create != 0) {
L_0001ce54:
      val = *param1;
      if (val == 0) goto L_0001ce60;
      goto L_0001ce68;
    }
    if ((char)*param1 == '\0') {
      if (*(char *)((int8_t)param1 + 1) != '\0') {
        param1 = __cxa_allocate_exception(8);
        *param1 = _ZTVN9__gnu_cxx20recursive_init_errorE + 0x10;
        __cxa_throw(param1,pvRam00000000000bfa28,pvRam00000000000bfef0);
      }
      ret = 1;
      *(uint8_t *)((int8_t)param1 + 1) = 1;
      goto L_0001ce80;
    }
  }
L_0001ce7c:
  ret = 0;
L_0001ce80:
  if (__google_potentially_blocking_region_end != 0) {
    __google_potentially_blocking_region_end();
  }
  return ret;
L_0001ce60:
  cVar2 = '\x01';
  bVar3 = (bool)ExclusiveMonitorPass(param1,0x10);
  if (bVar3) {
    *param1 = 0x100;
    cVar2 = ExclusiveMonitorsStatus();
  }
  if (cVar2 == '\0') {
L_0001ce68:
    if (val == 0) {
      ret = 1;
      goto L_0001ce80;
    }
    if (val != 1) {
      if (val == 0x100) {
        do {
          val = *param1;
          if (val != 0x100) break;
          cVar2 = '\x01';
          bVar3 = (bool)ExclusiveMonitorPass(param1,0x10);
          if (bVar3) {
            *param1 = 0x10100;
            cVar2 = ExclusiveMonitorsStatus();
          }
        } while (cVar2 != '\0');
        if (val != 0x100) {
          if (val == 1) goto L_0001ce7c;
          if (val == 0) goto L_0001ce54;
        }
      }
      syscall(0x62);
      goto L_0001ce54;
    }
    goto L_0001ce7c;
  }
  goto L_0001ce54;
}