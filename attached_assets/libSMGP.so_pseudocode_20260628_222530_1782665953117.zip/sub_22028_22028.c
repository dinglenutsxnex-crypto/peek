int8_t * sub_22028(void)

{
  jclass cls;
  int8_t *param1;
  int8_t *env;
  char cStack_8;
  
  param1[1] = 0;
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    if ((uint8_t)env[2] < (uint8_t)env[3]) {
      env[2] = env[2] + 1;
    }
    else {
      cls = (*env)->GetSuperclass();
      if (cls == -1) {
        sub_1ED34();
        return param1;
      }
    }
    param1[1] = 1;
  }
  return param1;
}