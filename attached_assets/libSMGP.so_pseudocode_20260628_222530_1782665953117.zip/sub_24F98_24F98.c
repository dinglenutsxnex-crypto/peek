uint8_t sub_24F98(void)

{
  jobject obj;
  int8_t *param1;
  int8_t *env;
  uint8_t ret;
  char cStack_8;
  
  ret = JNI_ERR;
  param1[1] = 0;
  sub_24104();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    if ((uint32_t *)env[2] < (uint32_t *)env[3]) {
      obj = *(uint32_t *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod();
    }
    ret = (uint8_t)obj;
    if (obj == JNI_ERR) {
      sub_1F6E0();
      return JNI_ERR;
    }
  }
  return ret;
}