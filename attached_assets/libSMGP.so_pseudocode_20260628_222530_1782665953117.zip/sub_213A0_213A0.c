int8_t * sub_213A0(void)

{
  int8_t *param1;
  int8_t *piVar1;
  void *extraout_x0;
  void *param1;
  int8_t val;

  uint16_t *param2;
  uint8_t axVar3 [16];
  char cStack_10;
  uint32_t uStack_c;
  int8_t iStack_8;

  sub_21204();
  if (cStack_10 != '\0') {
    uStack_c = 0;
    val = (int8_t)param1 + *(int8_t *)(*param1 + -0x18);
    piVar1 = *(int8_t **)(val + 0x100);
    if (piVar1 == (int8_t *)0x0) {
      axVar3 = sub_61E30();
      param1 = axVar3._0_8_;
      if (axVar3._8_8_ == 1) {
        __cxa_begin_catch(param1);
        param1 = (int8_t *)((int8_t)param1 + *(int8_t *)(*param1 + -0x18));
        *(uint32_t *)(param1 + 4) = *(uint32_t *)(param1 + 4) | 1;
        if ((*(uint32_t *)((int8_t)param1 + 0x1c) & 1) == 0) {
          __cxa_rethrow();
          goto L_00021514;
        }
        __cxa_rethrow();
        param1 = extraout_x0;
      }
      __cxa_begin_catch(param1);
      val = *(int8_t *)(*param1 + -0x18);
      *(uint32_t *)((int8_t)param1 + val + 0x20) = *(uint32_t *)((int8_t)param1 + val + 0x20) | 1;
      if ((*(uint32_t *)((int8_t)param1 + val + 0x1c) & 1) != 0) {
L_00021514:
        __cxa_rethrow();
        __cxa_end_catch();
        sub_81F98(extraout_x0_00);
      }
      __cxa_end_catch();
    }
    else {
      (**(code **)(*piVar1 + 0x18))
                (piVar1,*(uint64_t *)(val + 0xe8),0xffffffff,0,0xffffffff,val,&uStack_c,
                 &iStack_8);
      if (iStack_8 < -0x8000) {
        *param2 = 0x8000;
        uStack_c = uStack_c | 4;
      }
      else {
        if (0x7fff < iStack_8) {
          *param2 = 0x7fff;
          uStack_c = uStack_c | 4;
          if (uStack_c == 0) {
            return param1;
          }
          goto L_0002145c;
        }
        *param2 = (int16_t)iStack_8;
      }
    }
    if (uStack_c != 0) {
L_0002145c:
      sub_1ED34();
      return param1;
    }
  }
  return param1;
}