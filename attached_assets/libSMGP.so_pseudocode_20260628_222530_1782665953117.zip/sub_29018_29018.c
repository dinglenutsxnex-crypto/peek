uint64_t sub_29018(void)

{
  uint64_t *param1;
  uint64_t extraout_x0;
  
  *param1 = 0xba830;
  sub_397CC();
  _ZdlPv(param1);
  return extraout_x0;
}