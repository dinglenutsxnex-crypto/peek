uint8_t Java_com_soham_cheat_Ui_nativeSetTargetPackage(void)

{
  uint32_t val1;
  int8_t *param1;
  char *param1;

  param1 = (char *)(*param1)->GetStringUTFChars();
  if (param1 == (char *)0x0) {
    sub_65820(0xc0190,0,*(uint64_t *)(unk_c0190 + -0x18),0);
  }
  else {
    param1 = strlen(param1);
    sub_65CF4(0xc0190,param1,uVar2);
    (*param1)->ReleaseStringUTFChars();
  }
  val1 = __android_log_print(4,(char *)"MainCpp",(char *)"nativeSetTargetPackage -> %s");
  return (uint8_t)val1;
}