uint64_t sub_1E568(void)

{
  uint64_t *param1;
  uint64_t extraout_x0;
  
  *param1 = 0xbcd20;
  sub_1DB10();
  _ZdlPv(param1);
  return extraout_x0;
}