int8_t * sub_2192C(void)

{
  jclass cls;
  int8_t *param1;
  int8_t *env;
  uint8_t *param2;
  uint8_t *puVar3;
  char cStack_8;
  
  param1[1] = 0;
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 + -0x18) + 0xe8);
    puVar3 = (uint8_t *)env[2];
    if (puVar3 < (uint8_t *)env[3]) {
      cls = (uint32_t)*puVar3;
      env[2] = (int8_t)(puVar3 + 1);
    }
    else {
      cls = (*env)->GetSuperclass();
      if (cls == JNI_ERR) goto L_0002199c;
    }
    param1[1] = 1;
    *param2 = (char)cls;
  }
  if (param1[1] != 0) {
    return param1;
  }
L_0002199c:
  sub_1ED34();
  return param1;
}