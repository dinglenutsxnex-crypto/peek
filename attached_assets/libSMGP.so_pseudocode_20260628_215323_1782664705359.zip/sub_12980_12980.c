uint8 sub_12980(void)

{
  int4 val1;
  uint4 val2;
  
  unk_d362c = false;
  if (pthread_create != 0) {
    val1 = pthread_key_create((void *)0xd3628,(void *)0x6da30);
    unk_d362c = val1 == 0;
  }
  val2 = __cxa_atexit((void *)0x6da14,(void *)0xd3628,(void *)0xc0000);
  return (uint8)val2;
}