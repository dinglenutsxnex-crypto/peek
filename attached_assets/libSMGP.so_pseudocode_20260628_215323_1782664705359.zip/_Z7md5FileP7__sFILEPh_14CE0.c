// detected - Rolling XOR cipher (detection may be wrong)
// detected - XOR with constant (detection may be wrong)
// detected - SHA-1 (detection may be wrong)
uint64_t _Z7md5FileP7__sFILEPh(void)

{

  unkuint3 Var2;
  uint4 val1;
  uint4 val2;
  uint4 val3;
  void *in_x0;
  void *param1;
  uint8 val4;

  uint64_t *in_x1;

  uint8 val5;
  int8 val6;
  uint8 val7;
  uint4 val8;
  uint8 val9;
  uint8 val10;
  uint8 val11;
  uint4 val12;
  int8 val13;
  uint8 val14;
  uint4 val15;
  uint4 val16;
  uint4 val17;
  uint4 val18;
  int8 iStack_128;

  uint64_t xStack_110;
  uint64_t xStack_108;
  uint64_t xStack_100;
  uint64_t xStack_f8;
  uint64_t xStack_f0;
  uint64_t xStack_e8;
  uint64_t xStack_e0;
  uint64_t xStack_d8;
  uint64_t xStack_d0;
  uint64_t xStack_c8;

  param1 = malloc(0x400);
  iStack_128 = 0;
  xStack_110 = unk_84030;
  val4 = fread(param1,1,0x400,in_x0);
  if (val4 != 0) {
    val6 = 0;
    val15 = 0x67452301;
    val18 = 0xefcdab89;
    val16 = 0x98badcfe;
    val17 = 0x10325476;
    do {
      val5 = 0;
      val8 = (uint4)val6 & 0x3f;
      do {
        val12 = val8 + 1;
        *(uint8_t *)((int8)&xStack_110 + (uint8)val8) = *(uint8_t *)((int8)param1 + val5);
        val8 = val12;
        if ((val12 & 0x3f) == 0) {
          val7 = 0;
          val9 = 0;
          val11 = 1;
          Var2 = ((int)((char)((uint8)xStack_f0 >> 0x20)) << 16 | (unsigned short)((int2)xStack_f0)) & 0xff00ff;
          val10 = 5;
          xStack_c8 = ((long long)((char)((uint8)xStack_f0 >> 0x38)) << 56 | (unsigned long long)(
                               CONCAT16((char)((uint8)xStack_f0 >> 0x30),
                                        CONCAT15((char)((uint8)xStack_f0 >> 0x28),
                                                 CONCAT14((char)(Var2 >> 0x10),
                                                          CONCAT13((char)((uint8)xStack_f0 >> 0x18),
                                                                   CONCAT12((char)((uint8)xStack;
          xStack_c8 = xStack_e0;
          val8 = val15;
          val12 = val18;
          val2 = val16;
          val3 = val17;
          do {
            val1 = val3;
            val3 = val2;
            val2 = val12;
            val12 = (uint4)(val9 >> 4) & 0xfffffff;
            if (val12 == 2) {
              val12 = val3 ^ val1 ^ val2;
              val14 = val10 & 0xf;
            }
            else if (val12 == 1) {
              val12 = val2 & val1 | val3 & (val1 ^ 0xffffffff);
              val14 = val11 & 0xf;
            }
            else if ((val9 >> 4 & 0xfffffff) == 0) {
              val12 = val1 & (val2 ^ 0xffffffff) | val2 & val3;
              val14 = val9;
            }
            else {
              val12 = (val2 | val1 ^ 0xffffffff) ^ val3;
              val14 = val7 & 0xf;
            }
            val13 = val9 * 4;
            val9 = val9 + 1;
            val8 = val12 + val8 + *(int4 *)(val13 + 0x84d68) +
                     *(int4 *)((int8)&xStack_c0 + (val14 & 0xffffffff) * 4);
            val12 = 0x20U - *(int4 *)(val13 + 0x84e68) & 0x1f;
            val7 = val7 + 7;
            val11 = val11 + 5;
            val12 = (val8 >> val12 | val8 << 0x20 - val12) + val2;
            val10 = val10 + 3;
            val8 = val1;
          } while (val9 != 0x40);
          val8 = 0;
          val15 = val1 + val15;
          val18 = val12 + val18;
          val16 = val2 + val16;
          val17 = val3 + val17;
        }
        val5 = (uint8)((int4)val5 + 1);
      } while (val5 < val4);
      val6 = val6 + val4;
      val4 = fread(param1,1,0x400,in_x0);
    } while (val4 != 0);
    xStack_110 = ((long long)(val18) << 32 | (unsigned int)(val15));
    xStack_110 = ((long long)(val17) << 32 | (unsigned int)(val16));
    iStack_128 = val6;
  }
  _Z11md5FinalizeP10MD5Context(&iStack_128);
  free(param1);
  in_x1[1] = xStack_c8;
  *in_x1 = xStack_d0;

  __stack_chk_fail();
}