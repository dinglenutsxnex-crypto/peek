int8 * sub_21528(void)

{
  int8 *in_x0;
  int8 *piVar1;
  void *extraout_x0;
  void *param1;
  int8 val1;

  uint32_t val2;
  uint32_t *in_x1;
  uint8_t axVar4 [16];
  char cStack_10;
  uint4 uStack_c;
  int8 iStack_8;

  sub_21204();
  if (cStack_10 != '\0') {
    uStack_c = 0;
    val1 = (int8)in_x0 + *(int8 *)(*in_x0 + -0x18);
    piVar1 = *(int8 **)(val1 + 0x100);
    if (piVar1 == (int8 *)0x0) {
      axVar4 = func_0x00061e30();
      param1 = axVar4._0_8_;
      if (axVar4._8_8_ == 1) {
        __cxa_begin_catch(param1);
        in_x0 = (int8 *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18));
        *(uint4 *)(in_x0 + 4) = *(uint4 *)(in_x0 + 4) | 1;
        if ((*(uint4 *)((int8)in_x0 + 0x1c) & 1) == 0) {
          __cxa_rethrow();
          goto code_r0x00021684;
        }
        __cxa_rethrow();
        param1 = extraout_x0;
      }
      __cxa_begin_catch(param1);
      val1 = *(int8 *)(*in_x0 + -0x18);
      *(uint4 *)((int8)in_x0 + val1 + 0x20) = *(uint4 *)((int8)in_x0 + val1 + 0x20) | 1;
      if ((*(uint4 *)((int8)in_x0 + val1 + 0x1c) & 1) != 0) {
code_r0x00021684:
        __cxa_rethrow();
        __cxa_end_catch();
        func_0x00081f98(extraout_x0_00);
      }
      __cxa_end_catch();
    }
    else {
      (**(code **)(*piVar1 + 0x18))
                (piVar1,*(uint64_t *)(val1 + 0xe8),0xffffffff,0,0xffffffff,val1,&uStack_c,
                 &iStack_8);
      val2 = 0x80000000;
      if ((-0x80000001 < iStack_8) && (val2 = 0x7fffffff, iStack_8 < 0x80000000)) {
        *in_x1 = (int4)iStack_8;
        if (uStack_c == 0) {
          return in_x0;
        }
        goto code_r0x000215dc;
      }
      *in_x1 = val2;
      uStack_c = uStack_c | 4;
    }
    if (uStack_c != 0) {
code_r0x000215dc:
      sub_1ED34();
      return in_x0;
    }
  }
  return in_x0;
}