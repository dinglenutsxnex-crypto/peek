int8 sub_1DA28(void)

{
  int4 val1;
  uint64_t *in_x0;
  uint8_t *pxVar2;
  int8 val2;
  int4 iStack_8c;
  uint32_t xStack_88;

  uint8_t axStack_80 [16];
  uint4 uStack_70;
  int8 iStack_50;

  iStack_8c = 0;
  val1 = fileno(*in_x0);
  val1 = ioctl(val1,0x541b,&iStack_8c);
  if ((val1 == 0) && (-1 < iStack_8c)) {
    return (int8)iStack_8c;
  }
  pxVar2 = sub_1D788();
  xStack_88 = (pxVar2 - 0);
  xStack_88 = 1;
  val1 = poll(&xStack_88,1,0);
  if (0 < val1) {
    pxVar2 = sub_1D788();
    val1 = fstat((int4)pxVar2,axStack_80);
    if ((val1 == 0) && ((uStack_70 & 0xf000) == 0x8000)) {
      pxVar2 = sub_1D788();
      val2 = lseek(pxVar2,0,1);
      return iStack_50 - val2;
    }
  }
  return 0;
}