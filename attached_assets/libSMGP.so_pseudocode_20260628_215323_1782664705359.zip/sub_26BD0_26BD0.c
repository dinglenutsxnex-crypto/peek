int8 * sub_26BD0(void)

{
  uint8_t *pxVar1;
  uint64_t in_x0;
  int8 *piVar2;
  int8 val1;
  int8 *env;
  void *extraout_x0;
  void *param1;
  uint64_t extraout_x0_00;
  uint64_t in_x1;
  uint64_t val2;
  int8 *unaff_x19;
  uint64_t unaff_x20;
  uint8_t *unaff_x29;
  uint64_t unaff_x30;
  uint8_t axVar6 [16];
  
  axVar6._8_8_ = in_x1;
  axVar6._0_8_ = in_x0;
  do {
    val2 = axVar6._8_8_;
    piVar2 = axVar6._0_8_;
    pxVar1 = (uint8_t *)((int8)register0x00000008 + -0x40);
    *(uint8_t **)((int8)register0x00000008 + -0x40) = unaff_x29;
    *(uint64_t *)((int8)register0x00000008 + -0x38) = unaff_x30;
    *(int8 **)((int8)register0x00000008 + -0x30) = unaff_x19;
    *(uint64_t *)((int8)register0x00000008 + -0x28) = unaff_x20;
    sub_24104();
    if (*(char *)((int8)register0x00000008 + -8) == '\0') {
      return piVar2;
    }
    val1 = *piVar2;
    *(uint32_t *)((int8)register0x00000008 + -4) = 0;
    val1 = (int8)piVar2 + *(int8 *)(val1 + -0x18);
    env = *(int8 **)(val1 + 0x100);
    if (env != (int8 *)0x0) {
      (*env)->GetSuperclass
                (env,*(uint64_t *)(val1 + 0xe8),JNI_ERR,0,JNI_ERR,val1,
                 (uint8_t *)((int8)register0x00000008 + -4),val2);
      goto code_r0x00026c38;
    }
    axVar6 = func_0x00061e30();
    param1 = axVar6._0_8_;
    if (axVar6._8_8_ == 1) {
      __cxa_begin_catch(param1);
      piVar2 = (int8 *)((int8)piVar2 + *(int8 *)(*piVar2 + -0x18));
      *(uint4 *)(piVar2 + 4) = *(uint4 *)(piVar2 + 4) | 1;
      if ((*(uint4 *)((int8)piVar2 + 0x1c) & 1) != 0) {
        __cxa_rethrow();
        param1 = extraout_x0;
        goto code_r0x00026cb0;
      }
      __cxa_rethrow();
    }
    else {
code_r0x00026cb0:
      __cxa_begin_catch(param1);
      val1 = *(int8 *)(*piVar2 + -0x18);
      *(uint4 *)((int8)piVar2 + val1 + 0x20) = *(uint4 *)((int8)piVar2 + val1 + 0x20) | 1;
      if ((*(uint4 *)((int8)piVar2 + val1 + 0x1c) & 1) == 0) {
        __cxa_end_catch();
code_r0x00026c38:
        if (*(int4 *)((int8)register0x00000008 + -4) == 0) {
          return piVar2;
        }
        sub_1F6E0();
        return piVar2;
      }
    }
    __cxa_rethrow();
    *(uint64_t *)((int8)register0x00000008 + -0x18) = extraout_x0_00;
    __cxa_end_catch();
    unaff_x30 = 0x26d04;
    axVar6 = func_0x00081f98(*(uint64_t *)((int8)register0x00000008 + -0x18));
    register0x00000008 = (BADSPACEBASE *)((int8)register0x00000008 + -0x40);
    unaff_x19 = piVar2;
    unaff_x20 = val2;
    unaff_x29 = pxVar1;
  } while( true );
}