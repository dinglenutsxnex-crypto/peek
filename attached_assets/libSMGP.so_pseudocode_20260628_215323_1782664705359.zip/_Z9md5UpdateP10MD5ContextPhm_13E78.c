int8 * _Z9md5UpdateP10MD5ContextPhm(void)

{
  uint4 val1;

  unkuint3 Var3;

  int8 *in_x0;
  int8 *piVar5;
  int8 in_x1;
  uint8 in_x2;
  uint8 val2;
  uint4 val3;
  int8 val4;
  uint8 val5;
  uint64_t xStack_90;
  int8 iStack_88;

  int8 iStack_78;

  int8 iStack_68;

  int8 iStack_58;

  val4 = *in_x0;
  *in_x0 = val4 + in_x2;
  piVar5 = in_x0;
  if (in_x2 != 0) {
    val3 = (uint4)val4 & 0x3f;
    val2 = 0;
    val5 = 1;
    do {
      val1 = val3 + 1;
      *(uint8_t *)((int8)in_x0 + (uint8)val3 + 0x18) = *(uint8_t *)(in_x1 + val2);
      val3 = val1;
      if ((val1 & 0x3f) == 0) {
        iStack_88 = in_x0[4];
        val4 = in_x0[3];
        Var3 = ((int)((char)((uint8)val4 >> 0x20)) << 16 | (unsigned short)((int2)val4)) & 0xff00ff;
        xStack_90 = ((long long)((char)((uint8)val4 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8)val4 >> 0x30),
                                      CONCAT15((char)((uint8)val4 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8)val4 >> 0x18),
                                                                 CONCAT12((char)((uint8)val4 >>
                       ;
        iStack_78 = in_x0[6];
        val4 = in_x0[5];
        Var3 = ((int)((char)((uint8)val4 >> 0x20)) << 16 | (unsigned short)((int2)val4)) & 0xff00ff;
        xStack_90 = ((long long)((char)((uint8)val4 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8)val4 >> 0x30),
                                      CONCAT15((char)((uint8)val4 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8)val4 >> 0x18),
                                                                 CONCAT12((char)((uint8)val4 >>
                       ;
        iStack_68 = in_x0[8];
        val4 = in_x0[7];
        Var3 = ((int)((char)((uint8)val4 >> 0x20)) << 16 | (unsigned short)((int2)val4)) & 0xff00ff;
        xStack_90 = ((long long)((char)((uint8)val4 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8)val4 >> 0x30),
                                      CONCAT15((char)((uint8)val4 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8)val4 >> 0x18),
                                                                 CONCAT12((char)((uint8)val4 >>
                       ;
        iStack_58 = in_x0[10];
        val4 = in_x0[9];
        Var3 = ((int)((char)((uint8)val4 >> 0x20)) << 16 | (unsigned short)((int2)val4)) & 0xff00ff;
        xStack_90 = ((long long)((char)((uint8)val4 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8)val4 >> 0x30),
                                      CONCAT15((char)((uint8)val4 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8)val4 >> 0x18),
                                                                 CONCAT12((char)((uint8)val4 >>
                       ;
        piVar5 = (int8 *)_Z7md5StepPjS_(in_x0 + 1,&xStack_90);
        val3 = 0;
      }
      xStack_90 = val5 < in_x2;
      val2 = val5;
      val5 = (uint8)((int4)val5 + 1);
    } while (bVar4);
  }

  __stack_chk_fail();
}