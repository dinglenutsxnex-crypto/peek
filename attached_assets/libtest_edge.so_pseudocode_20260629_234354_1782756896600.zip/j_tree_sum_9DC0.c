// thunk -> external import
void j_tree_sum(void) {
    tree_sum();
}
