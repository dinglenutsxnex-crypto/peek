// thunk -> external import
void j_is_odd(void) {
    is_odd();
}
