// thunk -> external import
void j_thunk_target(void) {
    thunk_target();
}
