// thunk -> external import
void j_tree_depth(void) {
    tree_depth();
}
