// thunk -> external import
void j_my_strlen(void) {
    my_strlen();
}
