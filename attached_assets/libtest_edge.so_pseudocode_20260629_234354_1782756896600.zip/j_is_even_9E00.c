// thunk -> external import
void j_is_even(void) {
    is_even();
}
