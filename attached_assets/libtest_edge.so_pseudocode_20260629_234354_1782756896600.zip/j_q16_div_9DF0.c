// thunk -> external import
void j_q16_div(void) {
    q16_div();
}
