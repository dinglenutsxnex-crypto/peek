// thunk -> external import
void j_apply_recurse(void) {
    apply_recurse();
}
