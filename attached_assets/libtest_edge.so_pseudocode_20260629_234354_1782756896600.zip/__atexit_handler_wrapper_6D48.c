// Pseudocode unavailable: decompiler fault on this function.
// The function may contain instructions not supported by the
// decompiler (e.g. ARMv8.1 LSE atomics or unusual encodings).
