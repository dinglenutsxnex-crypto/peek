// thunk -> external import
void j_call_c(void) {
    call_c();
}
