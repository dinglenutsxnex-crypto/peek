// thunk -> external import
void j_my_callback(void) {
    my_callback();
}
