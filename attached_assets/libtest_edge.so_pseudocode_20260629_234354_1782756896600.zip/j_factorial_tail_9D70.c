// thunk -> external import
void j_factorial_tail(void) {
    factorial_tail();
}
