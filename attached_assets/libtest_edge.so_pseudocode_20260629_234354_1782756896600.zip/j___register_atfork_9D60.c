// thunk -> external import
void j___register_atfork(void) {
    __register_atfork();
}
