// thunk -> external import
void j_call_b(void) {
    call_b();
}
