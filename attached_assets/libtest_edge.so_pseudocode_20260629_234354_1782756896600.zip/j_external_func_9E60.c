// thunk -> external import
void j_external_func(void) {
    external_func();
}
