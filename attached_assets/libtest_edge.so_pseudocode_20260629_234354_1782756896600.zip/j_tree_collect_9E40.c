// thunk -> external import
void j_tree_collect(void) {
    tree_collect();
}
