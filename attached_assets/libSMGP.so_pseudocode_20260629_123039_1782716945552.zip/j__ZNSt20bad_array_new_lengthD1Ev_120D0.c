// thunk -> external import
void j__ZNSt20bad_array_new_lengthD1Ev(void) {
    _ZNSt20bad_array_new_lengthD1Ev();
}
