// thunk -> external import
void j__ZNSt10bad_typeidD1Ev(void) {
    _ZNSt10bad_typeidD1Ev();
}
