// thunk -> external import
void j_free(void) {
    free();
}
