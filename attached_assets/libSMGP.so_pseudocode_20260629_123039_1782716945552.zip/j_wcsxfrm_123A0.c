// thunk -> external import
void j_wcsxfrm(void) {
    wcsxfrm();
}
