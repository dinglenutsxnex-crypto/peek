// thunk -> external import
void j_wcsftime(void) {
    wcsftime();
}
