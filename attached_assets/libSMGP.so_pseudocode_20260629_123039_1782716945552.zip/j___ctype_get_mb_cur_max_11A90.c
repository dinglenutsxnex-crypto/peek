// thunk -> external import
void j___ctype_get_mb_cur_max(void) {
    __ctype_get_mb_cur_max();
}
