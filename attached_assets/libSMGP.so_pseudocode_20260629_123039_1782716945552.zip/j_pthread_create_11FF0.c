// thunk -> external import
void j_pthread_create(void) {
    pthread_create();
}
