int8_t sub_1DBCC(void)

{
  void *param2;
  int8_t param3;
  void *param5;
  
  memcpy(param5,param2,param3 - (int8_t)param2);
  return param3;
}