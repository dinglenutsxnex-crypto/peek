uint64_t sub_1E22C(void)

{
  int32_t val1;
  uint64_t *param1;
  uint64_t val2;
  char *param2;
  int8_t param3;
  
  *(uint32_t *)(param1 + 1) = (uint32_t)(param3 != 0);
  *param1 = 0xbcc00;
  val2 = sub_39ED0();
  param1[2] = val2;
  *(uint8_t *)(param1 + 3) = 0;
  sub_1EBCC();
  *param1 = 0xbcc80;
  val1 = strcmp(param2,(char *)"nu.version_r");
  if ((val1 != 0) && (val1 = strcmp(param2,(char *)"POSIX"), val1 != 0)) {
    sub_6F8D4(param1 + 2);
    sub_6F8A0(param1 + 2);
  }
  return 0;
}