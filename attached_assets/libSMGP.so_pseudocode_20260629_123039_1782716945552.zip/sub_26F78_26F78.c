int8_t * sub_26F78(void)

{
  uint8_t val1;
  uint32_t val2;
  jobject obj;
  int8_t *param1;
  void *pvVar4;
  uint8_t *puVar5;
  int32_t val3;
  uint8_t *param2;
  int8_t val4;
  uint8_t val5;
  uint8_t val6;
  int8_t param3;
  int8_t val7;
  uint8_t *puVar11;
  uint8_t param4;
  uint8_t val8;
  int8_t *env;
  uint8_t *param1;
  void *param1_00;
  char cStack_8;
  
  param1[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') {
L_00027100:
    val3 = 0;
L_00027104:
    if (0 < param3) {
      *param2 = 0;
    }
    if ((param1[1] != 0) && (val3 == 0)) {
      return param1;
    }
    sub_1ED34();
    return param1;
  }
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
  if ((uint8_t *)env[2] < (uint8_t *)env[3]) {
    obj = (uint32_t)*(uint8_t *)env[2];
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
  }
L_00026fe0:
  val4 = param1[1];
  do {
    val7 = val4 + 1;
    param1 = param2;
    val2 = obj;
    if (obj == param4 || obj == JNI_ERR) {
L_000270a0:
      if (obj == JNI_ERR) {
        val3 = 2;
        goto L_00027104;
      }
      val3 = 4;
      if (param4 != obj) goto L_00027104;
      val5 = env[2];
      val6 = env[3];
      param1[1] = val7;
      if (val6 <= val5) {
        (*env)->GetSuperclass(env);
        goto L_00027100;
      }
      val3 = 0;
      env[2] = val5 + 1;
      goto L_00027104;
    }
    while( true ) {
      obj = val2;
      param2 = param1;
      if (param3 <= val7) goto L_000270a0;
      param1_00 = (void *)env[2];
      val5 = (param3 - val4) - 1;
      if (env[3] - (int8_t)param1_00 < (int8_t)val5) {
        val5 = env[3] - (int8_t)param1_00;
      }
      if ((int8_t)val5 < 2) break;
      pvVar4 = memchr(param1_00,(uint32_t)param4,val5);
      val6 = (int8_t)pvVar4 - (int8_t)param1_00;
      if (pvVar4 == (void *)0x0) {
        val6 = val5;
      }
      param2 = param1 + val6;
      memcpy(param1,param1_00,val6);
      val7 = env[2];
      val4 = param1[1];
      val8 = env[3];
      val5 = val7 + val6;
      env[2] = val5;
      val4 = val6 + val4;
      param1[1] = val4;
      if (val8 <= val5) {
        obj = (*env)->ToReflectedMethod(env);
        goto L_00026fe0;
      }
      val1 = *(uint8_t *)(val7 + val6);
      obj = (uint32_t)val1;
      val7 = val4 + 1;
      param1 = param2;
      val2 = (uint32_t)val1;
      if ((uint32_t)val1 == (uint32_t)param4 || val1 == JNI_ERR) goto L_000270a0;
    }
    *param1 = (char)obj;
    param2 = param1 + 1;
    puVar5 = (uint8_t *)env[2];
    puVar11 = (uint8_t *)env[3];
    param1[1] = param1[1] + 1;
    if (puVar5 < puVar11) {
      puVar5 = puVar5 + 1;
      env[2] = (int8_t)puVar5;
    }
    else {
      obj = (*env)->GetSuperclass(env);
      if (obj == JNI_ERR) goto L_00026fe0;
      puVar5 = (uint8_t *)env[2];
      puVar11 = (uint8_t *)env[3];
    }
    if (puVar11 <= puVar5) break;
    obj = (uint32_t)*puVar5;
    val4 = param1[1];
  } while( true );
  obj = (*env)->ToReflectedMethod(env);
  goto L_00026fe0;
}