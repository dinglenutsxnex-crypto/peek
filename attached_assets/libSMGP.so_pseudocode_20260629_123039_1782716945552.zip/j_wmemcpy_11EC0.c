// thunk -> external import
void j_wmemcpy(void) {
    wmemcpy();
}
