// thunk -> external import
void j__ZdaPv(void) {
    _ZdaPv();
}
