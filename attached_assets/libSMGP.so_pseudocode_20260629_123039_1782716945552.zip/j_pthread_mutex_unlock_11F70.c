// thunk -> external import
void j_pthread_mutex_unlock(void) {
    pthread_mutex_unlock();
}
