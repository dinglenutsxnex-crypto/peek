// thunk -> external import
void j__ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz(void) {
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
}
