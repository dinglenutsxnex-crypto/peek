uint8_t _Z18checkPidorasSystemPKcPh(void)

{

  int32_t val;
  char *param1;
  void *param1;

  void *param2;
  uint8_t axStack_48 [16];

  param1 = fopen(param1,(char *)"rb");
  if (param1 == (void *)0x0) {
    perror((char *)"fopen");
    param1 = 0;
  }
  else {
    _Z7md5FileP7__sFILEPh(param1,axStack_48);
    fclose(param1);
    val = memcmp(axStack_48,param2,0x10);
    param1 = (uint8_t)(val == 0);
  }

  __stack_chk_fail();
}