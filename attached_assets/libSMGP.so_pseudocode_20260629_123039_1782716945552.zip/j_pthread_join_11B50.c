// thunk -> external import
void j_pthread_join(void) {
    pthread_join();
}
