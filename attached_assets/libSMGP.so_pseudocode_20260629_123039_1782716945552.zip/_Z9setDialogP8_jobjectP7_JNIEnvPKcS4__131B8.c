uint64_t _Z9setDialogP8_jobjectP7_JNIEnvPKcS4_(void)

{
  uint64_t ret;

  (*env)->FindClass();
  (*env)->GetMethodID();
  _ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz();
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  (*env)->GetMethodID();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  (*env)->GetMethodID();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  (*env)->FindClass();
  (*env)->GetMethodID();
  ret = _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}