// thunk -> external import
void j_setvbuf(void) {
    setvbuf();
}
