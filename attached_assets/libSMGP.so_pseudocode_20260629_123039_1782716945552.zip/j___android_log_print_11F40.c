// thunk -> external import
void j___android_log_print(void) {
    __android_log_print();
}
