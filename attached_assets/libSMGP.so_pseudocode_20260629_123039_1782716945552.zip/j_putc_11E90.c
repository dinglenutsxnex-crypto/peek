// thunk -> external import
void j_putc(void) {
    putc();
}
