// thunk -> external import
void j_wmemmove(void) {
    wmemmove();
}
