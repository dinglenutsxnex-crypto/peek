uint64_t sub_28FB8(void)

{
  uint64_t *param1;
  uint64_t ret0;
  
  *param1 = 0xba760;
  sub_3D1D4();
  _ZdlPv(param1);
  return ret0;
}