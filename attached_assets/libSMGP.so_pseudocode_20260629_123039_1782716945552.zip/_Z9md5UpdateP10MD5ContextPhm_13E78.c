int8_t * _Z9md5UpdateP10MD5ContextPhm(void)

{
  uint32_t val1;

  unkuint3 Var3;

  int8_t *param1;

  int8_t param2;
  uint8_t param3;
  uint8_t val2;
  uint32_t val3;
  int8_t val4;
  uint8_t val5;
  uint64_t xStack_90;

  val4 = *param1;
  *param1 = val4 + param3;
  param1 = param1;
  if (param3 != 0) {
    val3 = (uint32_t)val4 & 0x3f;
    val2 = 0;
    val5 = 1;
    do {
      val1 = val3 + 1;
      *(uint8_t *)((int8_t)param1 + (uint8_t)val3 + 0x18) = *(uint8_t *)(param2 + val2);
      val3 = val1;
      if ((val1 & 0x3f) == 0) {
        xStack_90 = param1[4];
        val4 = param1[3];
        Var3 = ((int)((char)((uint8_t)val4 >> 0x20)) << 16 | (unsigned short)((int16_t)val4)) & 0xff00ff;
        xStack_90 = ((long long)((char)((uint8_t)val4 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8_t)val4 >> 0x30),
                                      CONCAT15((char)((uint8_t)val4 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8_t)val4 >> 0x18),
                                                                 CONCAT12((char)((uint8_t)val4 >>
             ;
        xStack_90 = param1[6];
        val4 = param1[5];
        Var3 = ((int)((char)((uint8_t)val4 >> 0x20)) << 16 | (unsigned short)((int16_t)val4)) & 0xff00ff;
        xStack_90 = ((long long)((char)((uint8_t)val4 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8_t)val4 >> 0x30),
                                      CONCAT15((char)((uint8_t)val4 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8_t)val4 >> 0x18),
                                                                 CONCAT12((char)((uint8_t)val4 >>
             ;
        xStack_90 = param1[8];
        val4 = param1[7];
        Var3 = ((int)((char)((uint8_t)val4 >> 0x20)) << 16 | (unsigned short)((int16_t)val4)) & 0xff00ff;
        xStack_90 = ((long long)((char)((uint8_t)val4 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8_t)val4 >> 0x30),
                                      CONCAT15((char)((uint8_t)val4 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8_t)val4 >> 0x18),
                                                                 CONCAT12((char)((uint8_t)val4 >>
             ;
        xStack_90 = param1[10];
        val4 = param1[9];
        Var3 = ((int)((char)((uint8_t)val4 >> 0x20)) << 16 | (unsigned short)((int16_t)val4)) & 0xff00ff;
        xStack_90 = ((long long)((char)((uint8_t)val4 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8_t)val4 >> 0x30),
                                      CONCAT15((char)((uint8_t)val4 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8_t)val4 >> 0x18),
                                                                 CONCAT12((char)((uint8_t)val4 >>
             ;
        param1 = (int8_t *)_Z7md5StepPjS_(param1 + 1,&xStack_90);
        val3 = 0;
      }
      param1 = val5 < param3;
      val2 = val5;
      val5 = (uint8_t)((int32_t)val5 + 1);
    } while (bVar4);
  }

  __stack_chk_fail();
}