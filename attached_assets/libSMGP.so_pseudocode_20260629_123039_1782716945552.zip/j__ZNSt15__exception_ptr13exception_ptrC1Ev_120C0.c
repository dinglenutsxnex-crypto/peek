// thunk -> external import
void j__ZNSt15__exception_ptr13exception_ptrC1Ev(void) {
    _ZNSt15__exception_ptr13exception_ptrC1Ev();
}
