// thunk -> external import
void j__ZSt9terminatev(void) {
    _ZSt9terminatev();
}
