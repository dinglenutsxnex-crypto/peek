// thunk -> external import
void j_ungetc(void) {
    ungetc();
}
