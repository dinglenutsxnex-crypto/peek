int8_t * sub_22548(void)

{
  jboolean val1;
  int8_t *param1;
  int8_t *env;
  char param2;
  uint8_t val2;
  char cStack_8;
  
  param1[1] = 0;
  sub_1ED34();
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
    if (env != (int8_t *)0x0) {
      val2 = env[2];
      if (((uint8_t)env[1] < val2) && (*(char *)(val2 - 1) == param2)) {
        env[2] = val2 - 1;
        return param1;
      }
      val1 = (*env)->IsAssignableFrom(env,param2);
      if (val1 != -1) {
        return param1;
      }
    }
    sub_1ED34();
  }
  return param1;
}