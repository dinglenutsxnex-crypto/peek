int8_t * sub_25394(void)

{
  int8_t *param1;
  int8_t *env;
  jboolean param2;
  uint8_t val;
  char cStack_8;
  
  param1[1] = 0;
  sub_1F6E0();
  sub_24104();
  if (cStack_8 == '\0') {
    return param1;
  }
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
  if (env != (int8_t *)0x0) {
    val = env[2];
    if (((uint8_t)env[1] < val) && (param2 == *(int32_t *)(val - 4))) {
      env[2] = val - 4;
    }
    else {
      param2 = (*env)->IsAssignableFrom(env,param2);
    }
    if (param2 != -1) {
      return param1;
    }
  }
  sub_1F6E0();
  return param1;
}