int8_t * sub_25500(void)

{
  jboolean val1;
  int8_t *param1;
  int8_t *env;
  uint8_t val2;
  char cStack_8;
  
  param1[1] = 0;
  sub_1F6E0();
  sub_24104();
  if (cStack_8 == '\0') {
    return param1;
  }
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
  if (env != (int8_t *)0x0) {
    val2 = env[2];
    if ((uint8_t)env[1] < val2) {
      val1 = *(int32_t *)(val2 - 4);
      env[2] = val2 - 4;
    }
    else {
      val1 = (*env)->IsAssignableFrom(env,JNI_ERR);
    }
    if (val1 != -1) {
      return param1;
    }
  }
  sub_1F6E0();
  return param1;
}