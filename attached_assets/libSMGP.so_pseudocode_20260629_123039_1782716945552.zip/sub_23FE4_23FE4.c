uint8_t * sub_23FE4(void)

{
  int8_t *param1;
  int8_t *env;
  uint8_t *pxVar2;
  int8_t val;
  uint8_t axVar4 [16];
  
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xf0);
  if (env != (int8_t *)0x0) {
    (*env)->GetSuperclass(env,10);
  }
  axVar4 = sub_61E30();
  env = axVar4._0_8_;
  val = *axVar4._8_8_;
  *env = val;
  *(int8_t *)((int8_t)env + *(int8_t *)(val - 0x18)) = axVar4._8_8_[1];
  env[1] = 0;
  pxVar2 = sub_1FAE8();
  return pxVar2;
}