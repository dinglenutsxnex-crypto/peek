void _Z7md5InitP10MD5Context(uint64_t *param_1)

{
  uint64_t val1;
  uint64_t val2;
  
  val2 = unk_84038;
  val1 = unk_84030;
  *param_1 = 0;
  param_1[2] = val2;
  param_1[1] = val1;
  return;
}