uint64_t sub_1FA74(void)

{
  int8_t param1;
  uint64_t ret;

  if (*(int8_t **)(param1 + 0xf0) != (int8_t *)0x0) {
    ret = (**(code **)(**(int8_t **)(param1 + 0xf0) + 0x50))();
    return ret;
  }
  sub_61E30(0,param2);
}