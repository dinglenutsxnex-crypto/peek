int8_t sub_1DBF8(void)

{
  void *param2;
  int8_t param3;
  void *param4;
  
  memcpy(param4,param2,param3 - (int8_t)param2);
  return param3;
}