// thunk -> external import
void j__ZN10__cxxabiv119__foreign_exceptionD1Ev(void) {
    _ZN10__cxxabiv119__foreign_exceptionD1Ev();
}
