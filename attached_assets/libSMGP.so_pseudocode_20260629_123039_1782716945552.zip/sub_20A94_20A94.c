uint8_t sub_20A94(void)

{
  uint32_t val1;
  char cVar2;
  bool bVar3;
  int8_t param1;
  uint64_t ret;
  int8_t param2;
  uint32_t *puVar5;
  
  puVar5 = *(uint32_t **)(param2 + 0x9e8);
  if (*(int8_t *)(param1 + 0xd50) == 0) {
    val1 = *puVar5;
    *puVar5 = val1 - 1;
  }
  else {
    do {
      val1 = *puVar5;
      cVar2 = '\x01';
      bVar3 = (bool)ExclusiveMonitorPass(puVar5,0x10);
      if (bVar3) {
        *puVar5 = val1 - 1;
        cVar2 = ExclusiveMonitorsStatus();
      }
    } while (cVar2 != '\0');
  }
  if (val1 == 2) {
    sub_3D868(unk_bfb28);
    sub_3D868(unk_bfce0);
    sub_3D868(unk_bfdc0);
    sub_3FF8C(unk_bfe48);
    sub_3FF8C(unk_bff18);
    ret = sub_3FF8C(unk_bfd80);
    return ret;
  }
  return (uint8_t)val1;
}