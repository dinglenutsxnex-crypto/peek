uint8_t sub_1EAE4(void)

{
  uint8_t val1;
  uint32_t val2;
  int32_t val3;
  int8_t param1;
  uint8_t param2;
  uint8_t param3;
  uint8_t param4;
  int8_t param5;
  int8_t val4;
  
  if (*(char *)(param1 + 0x18) == '\0') {
    if (param2 < param3) {
      val4 = 0;
      do {
        val3 = wctob(*(uint32_t *)(param2 + val4 * 4));
        val1 = (char)val3;
        if (val3 == -1) {
          val1 = param4;
        }
        *(uint8_t *)(param5 + val4) = val1;
        val4 = val4 + 1;
      } while (val4 != (~param2 + param3 >> 2) + 1);
    }
  }
  else if (param2 < param3) {
    val4 = 0;
    do {
      val2 = *(uint32_t *)(param2 + val4 * 4);
      if (val2 < 0x80) {
        *(uint8_t *)(param5 + val4) = *(uint8_t *)(param1 + (uint8_t)val2 + 0x19);
      }
      else {
        val3 = wctob();
        val1 = (char)val3;
        if (val3 == -1) {
          val1 = param4;
        }
        *(uint8_t *)(param5 + val4) = val1;
      }
      val4 = val4 + 1;
    } while (val4 != (~param2 + param3 >> 2) + 1);
  }
  return param3;
}