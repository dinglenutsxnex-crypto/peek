// thunk -> external import
void j__ZNSt15__exception_ptr13exception_ptr4swapERS0_(void) {
    _ZNSt15__exception_ptr13exception_ptr4swapERS0_();
}
