int8_t _Z9hookFieldRKSsS0_S0_S0_(void)

{
  char cVar1;
  bool bVar2;

  int8_t ret;
  int32_t *piVar5;
  int32_t val;
  int8_t iStack_58;
  uint8_t axStack_50 [8];




  sub_67090(&iStack_58,packageName);
  _Z13executeFieldsRKSsS0_S0_S0_S0_();
  ret = iStack_58 - 0x18;
  if (ret != unk_bff48) {
    piVar5 = (int32_t *)(iStack_58 - 8);
    if (pthread_create == 0) {
      val = *piVar5;
      *piVar5 = val - 1;
    }
    else {
      do {
        val = *piVar5;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar5,0x10);
        if (bVar2) {
          *piVar5 = val - 1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      ret = sub_66F0C(ret,axStack_50);
    }
  }



  return ret;
}