// thunk -> external import
void j_wcslen(void) {
    wcslen();
}
