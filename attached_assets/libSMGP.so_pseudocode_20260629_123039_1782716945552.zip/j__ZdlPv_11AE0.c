// thunk -> external import
void j__ZdlPv(void) {
    _ZdlPv();
}
