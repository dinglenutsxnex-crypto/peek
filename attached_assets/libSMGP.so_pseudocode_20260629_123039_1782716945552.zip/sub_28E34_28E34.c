uint64_t sub_28E34(void)

{
  uint64_t *param1;
  
  *param1 = 0xbab50;
  if (*(char *)(param1 + 0x11) != '\0') {
    if ((void *)param1[2] != (void *)0x0) {
      _ZdaPv((void *)param1[2]);
    }
    if ((void *)param1[5] != (void *)0x0) {
      _ZdaPv((void *)param1[5]);
    }
    if ((void *)param1[7] != (void *)0x0) {
      _ZdaPv((void *)param1[7]);
    }
  }
}