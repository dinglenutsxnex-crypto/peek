// detected - ay::obfuscate (compile-time XOR string obfuscation) (detection may be wrong)
void _ZN2ay14OBFUSCATE_dataILm10ELc46EED2Ev(uint64_t *param_1)

{
  *(uint16_t *)(param_1 + 1) = 0;
  *param_1 = 0;
  return;
}