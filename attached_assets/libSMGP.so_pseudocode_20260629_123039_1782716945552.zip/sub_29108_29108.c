uint64_t sub_29108(void)

{
  uint64_t *param1;
  uint64_t ret0;
  
  *param1 = 0xbaa70;
  sub_397CC();
  _ZdlPv(param1);
  return ret0;
}