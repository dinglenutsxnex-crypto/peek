uint8_t sub_1EA90(void)

{
  uint32_t val1;
  uint32_t val2;
  int8_t param1;
  uint32_t param2;
  uint8_t param3;
  
  if ((param2 < 0x80) && (*(char *)(param1 + 0x18) != '\0')) {
    return (uint8_t)*(uint8_t *)(param1 + (uint8_t)param2 + 0x19);
  }
  val1 = wctob(param2);
  val2 = val1 & 0xff;
  if (val1 == 0xffffffff) {
    val2 = (uint32_t)param3;
  }
  return (uint8_t)val2;
}