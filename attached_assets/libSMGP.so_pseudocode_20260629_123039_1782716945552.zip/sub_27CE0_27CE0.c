int8_t * sub_27CE0(void)

{
  uint8_t val1;
  uint8_t val2;
  uint32_t val3;
  jobject obj;
  jclass cls;
  int8_t *param1;
  void *pvVar6;
  int8_t val4;
  uint8_t *puVar8;
  int8_t *param2;
  int8_t val5;
  uint8_t *puVar10;
  uint8_t param3;
  int8_t *env;
  uint8_t val6;
  void *param1;
  char cStack_8;
  
  sub_21204();
  if (cStack_8 != '\0') {
    sub_65820();
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
    if ((uint8_t *)env[2] < (uint8_t *)env[3]) {
      obj = (uint32_t)*(uint8_t *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod(env);
    }
    val6 = 0;
    do {
      while( true ) {
        val3 = obj;
        if ((obj == JNI_ERR) || (param3 == obj)) goto joined_r0x00027ed0;
        param1 = (void *)env[2];
        val1 = 0x3ffffffffffffff9 - val6;
        if (env[3] - (int8_t)param1 < (int8_t)(0x3ffffffffffffff9 - val6)) {
          val1 = env[3] - (int8_t)param1;
        }
        if ((int8_t)val1 < 2) break;
        pvVar6 = memchr(param1,(uint32_t)param3,val1);
        val2 = (int8_t)pvVar6 - (int8_t)param1;
        if (pvVar6 == (void *)0x0) {
          val2 = val1;
        }
        sub_6433C();
        val4 = env[2];
        val6 = val6 + val2;
        val1 = val4 + val2;
        env[2] = val1;
        if (val1 < (uint8_t)env[3]) {
          obj = (uint32_t)*(uint8_t *)(val4 + val2);
        }
        else {
L_00027f04:
          obj = (*env)->ToReflectedMethod(env);
        }
L_00027df8:
        val3 = obj;
        if (0x3ffffffffffffff8 < val6) goto joined_r0x00027ed0;
      }
      val5 = *param2;
      val4 = *(int8_t *)(val5 - 0x18);
      val1 = val4 + 1;
      if ((*(uint8_t *)(val5 - 0x10) < val1) || (0 < *(int32_t *)(val5 - 8))) {
        sub_63BF0();
        val5 = *param2;
        val4 = *(int8_t *)(val5 - 0x18);
      }
      *(char *)(val5 + val4) = (char)obj;
      val4 = *param2;
      if (val4 - 0x18 != unk_bff48) {
        *(uint32_t *)(val4 - 8) = 0;
        *(uint8_t *)(val4 - 0x18) = val1;
        *(uint8_t *)(val4 + val1) = 0;
      }
      val6 = val6 + 1;
      puVar10 = (uint8_t *)env[3];
      if ((uint8_t *)env[2] < puVar10) {
        puVar8 = (uint8_t *)env[2] + 1;
        env[2] = (int8_t)puVar8;
      }
      else {
        cls = (*env)->GetSuperclass(env);
        obj = JNI_ERR;
        if (cls == -1) goto L_00027df8;
        puVar8 = (uint8_t *)env[2];
        puVar10 = (uint8_t *)env[3];
      }
      if (puVar10 <= puVar8) goto L_00027f04;
      obj = (uint32_t)*puVar8;
      val3 = (uint32_t)*puVar8;
    } while (val6 < 0x3ffffffffffffff9);
joined_r0x00027ed0:
    if ((val3 != JNI_ERR) && (param3 == val3)) {
      if ((uint8_t)env[2] < (uint8_t)env[3]) {
        env[2] = env[2] + 1;
      }
      else {
        (*env)->GetSuperclass(env);
      }
      if (val6 != 0xffffffffffffffff) {
        return param1;
      }
    }
  }
  sub_1ED34();
  return param1;
}