int8_t * sub_1D5F4(void)

{
  int32_t val;
  int8_t *param1;
  int32_t *piVar2;
  void *param1;
  int8_t param2;
  
  if ((param2 != 0) && (*param1 == 0)) {
    piVar2 = (int32_t *)__errno();
    param1 = (void *)0x0;
    *piVar2 = 0;
    while( true ) {
      val = fflush(param1);
      if (val == 0) {
        *param1 = param2;
        *(uint8_t *)(param1 + 1) = 0;
        return param1;
      }
      if (*piVar2 != 4) break;
      param1 = (void *)*param1;
    }
  }
  return (int8_t *)0;
}