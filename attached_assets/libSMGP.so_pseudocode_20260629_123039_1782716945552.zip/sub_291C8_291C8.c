uint64_t sub_291C8(void)

{
  uint64_t *param1;
  
  *param1 = 0xbd2b0;
  sub_6F8D4(param1 + 2);
}