uint64_t sub_29CDC(void)

{

  uint64_t ret_ptr;

  (*env)->DefineClass();
  return ret_ptr;
}