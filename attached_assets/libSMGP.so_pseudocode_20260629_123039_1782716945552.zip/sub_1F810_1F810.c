uint8_t sub_1F810(void)

{
  uint64_t *pxVar1;
  char cVar2;
  uint64_t *param1;
  uint64_t val;
  int8_t param2;
  
  sub_1FF5C();
  param1[0x1b] = 0;
  *param1 = 0xba5e0;
  pxVar1 = param1 + 0x1a;
  *(uint32_t *)(param1 + 0x1c) = 0;
  *(uint8_t *)((int8_t)param1 + 0xe4) = 0;
  param1[0x1d] = 0;
  param1[0x1e] = 0;
  param1[0x1f] = 0;
  param1[0x20] = 0;
  sub_20D7C();
  cVar2 = sub_4E19C(pxVar1);
  if (cVar2 == '\0') {
    param1[0x1e] = 0;
    cVar2 = sub_4E34C(pxVar1);
  }
  else {
    val = sub_4C214(pxVar1);
    param1[0x1e] = val;
    cVar2 = sub_4E34C(pxVar1);
  }
  if (cVar2 == '\0') {
    param1[0x1f] = 0;
    cVar2 = sub_4E3B8(pxVar1);
  }
  else {
    val = sub_4CF28(pxVar1);
    param1[0x1f] = val;
    cVar2 = sub_4E3B8(pxVar1);
  }
  if (cVar2 == '\0') {
    param1[0x20] = 0;
  }
  else {
    val = sub_4CF90(pxVar1);
    param1[0x20] = val;
  }
  param1[0x1d] = param2;
  *(uint32_t *)(param1 + 0x1c) = 0;
  *(uint8_t *)((int8_t)param1 + 0xe4) = 0;
  param1[0x1b] = 0;
  *(uint32_t *)((int8_t)param1 + 0x1c) = 0;
  *(uint32_t *)(param1 + 4) = (uint32_t)(param2 == 0);
  return (uint8_t)(param2 == 0);
}