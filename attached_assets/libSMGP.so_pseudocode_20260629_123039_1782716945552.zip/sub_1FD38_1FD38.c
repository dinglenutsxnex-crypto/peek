int8_t sub_1FD38(void)

{
  int32_t *piVar1;
  uint32_t val1;
  int32_t val2;
  uint32_t val3;
  char cVar5;
  bool bVar6;
  jclass cls;
  int8_t param1;
  void *param1;
  uint64_t *pxVar8;
  uint64_t *pxVar9;
  int8_t *env;
  uint64_t *pxVar12;
  int8_t param2;
  uint64_t *pxVar13;
  uint64_t val4;
  uint64_t val5;
  int8_t val6;
  uint8_t axStack_8 [8];
  uint64_t *pxVar10;
  
  if (param1 == param2) {
    return param1;
  }
  val1 = *(uint32_t *)(param2 + 0xc0);
  if ((int32_t)val1 < 9) {
    pxVar12 = (uint64_t *)(param1 + 0x40);
  }
  else {
    pxVar12 = _Znam(-(uint8_t)(val1 >> 0x1f) & 0xfffffff000000000 | (uint8_t)val1 << 4);
    val2 = *(int32_t *)(param2 + 0xc0);
    val6 = 0;
    pxVar9 = pxVar12;
    if ((int8_t)val2 != 0) {
      do {
        val6 = val6 + 1;
        *pxVar9 = 0;
        pxVar9[1] = 0;
        pxVar9 = pxVar9 + 2;
      } while (val2 != val6);
    }
  }
  val6 = *(int8_t *)(param2 + 0x28);
  if (val6 != 0) {
    if (pthread_create == 0) {
      *(int32_t *)(val6 + 0x14) = *(int32_t *)(val6 + 0x14) + 1;
    }
    else {
      piVar1 = (int32_t *)(val6 + 0x14);
      do {
        cVar5 = '\x01';
        bVar6 = (bool)ExclusiveMonitorPass(piVar1,0x10);
        if (bVar6) {
          *piVar1 = *piVar1 + 1;
          cVar5 = ExclusiveMonitorsStatus();
        }
      } while (cVar5 != '\0');
    }
  }
  sub_20210();
  param1 = *(void **)(param1 + 200);
  if ((void *)(param1 + 0x40) != param1) {
    if (param1 != (void *)0x0) {
      _ZdaPv(param1);
    }
    *(uint64_t *)(param1 + 200) = 0;
  }
  sub_20278();
  val2 = *(int32_t *)(param2 + 0xc0);
  *(int8_t *)(param1 + 0x28) = val6;
  if (0 < val2) {
    pxVar8 = *(uint64_t **)(param2 + 200);
    pxVar9 = pxVar8;
    pxVar13 = pxVar12;
    do {
      pxVar10 = pxVar9 + 2;
      val4 = pxVar9[1];
      *pxVar13 = *pxVar9;
      pxVar13[1] = val4;
      pxVar9 = pxVar10;
      pxVar13 = pxVar13 + 2;
    } while (pxVar10 != pxVar8 + ((uint8_t)(val2 - 1) + 1) * 2);
  }
  cls = *(uint32_t *)(param2 + 0x18);
  *(uint64_t *)(param1 + 0x10) = *(uint64_t *)(param2 + 0x10);
  val4 = *(uint64_t *)(param2 + 0xd8);
  val5 = *(uint64_t *)(param2 + 8);
  cVar5 = *(char *)(param2 + 0xe4);
  *(uint64_t **)(param1 + 200) = pxVar12;
  *(int32_t *)(param1 + 0xc0) = val2;
  *(uint32_t *)(param1 + 0x18) = cls;
  *(uint64_t *)(param1 + 8) = val5;
  *(uint64_t *)(param1 + 0xd8) = val4;
  if (cVar5 == '\0') {
    env = *(int8_t **)(param2 + 0xf0);
    if (env != (int8_t *)0x0) {
      cls = (*env)->GetSuperclass(env,0x20);
      *(uint32_t *)(param2 + 0xe0) = cls;
      *(uint8_t *)(param2 + 0xe4) = 1;
      goto L_0001fe50;
    }
L_0001ff4c:
    sub_61E30();
  }
  else {
    cls = *(uint32_t *)(param2 + 0xe0);
L_0001fe50:
    if (*(char *)(param1 + 0xe4) == '\0') {
      env = *(int8_t **)(param1 + 0xf0);
      if (env == (int8_t *)0x0) goto L_0001ff4c;
      (*env)->GetSuperclass(env,0x20);
      *(uint8_t *)(param1 + 0xe4) = 1;
    }
    *(uint32_t *)(param1 + 0xe0) = cls;
    sub_3989C(axStack_8,param2 + 0xd0);
    sub_3A0E8(param1 + 0xd0,axStack_8);
    sub_3A188(axStack_8);
    sub_1FBBC();
    sub_20210();
    val1 = *(uint32_t *)(param2 + 0x1c);
    *(uint32_t *)(param1 + 0x1c) = val1;
    val3 = *(uint32_t *)(param1 + 0x20);
    if (*(int8_t *)(param1 + 0xe8) == 0) {
      val3 = val3 | 1;
      *(uint32_t *)(param1 + 0x20) = val3;
    }
    if ((val3 & val1) == 0) {
      return param1;
    }
  }
  pxVar12 = (uint64_t *)sub_62640("basic_ios::clear");
  *pxVar12 = 0xba600;
  pxVar12[1] = 0;
  pxVar12[2] = 0;
  *(uint32_t *)(pxVar12 + 3) = 0;
  *(uint32_t *)((int8_t)pxVar12 + 0x1c) = 0;
  *(uint32_t *)(pxVar12 + 4) = 0;
  pxVar12[5] = 0;
  pxVar12[6] = 0;
  pxVar12[7] = 0;
  pxVar12[8] = 0;
  pxVar12[9] = 0;
  pxVar12[10] = 0;
  pxVar12[0xb] = 0;
  pxVar12[0xc] = 0;
  pxVar12[0xd] = 0;
  pxVar12[0xe] = 0;
  pxVar12[0xf] = 0;
  pxVar12[0x10] = 0;
  pxVar12[0x11] = 0;
  pxVar12[0x12] = 0;
  pxVar12[0x13] = 0;
  pxVar12[0x14] = 0;
  pxVar12[0x15] = 0;
  pxVar12[0x16] = 0;
  pxVar12[0x17] = 0;
  *(uint32_t *)(pxVar12 + 0x18) = 8;
  pxVar12[0x19] = pxVar12 + 8;
}