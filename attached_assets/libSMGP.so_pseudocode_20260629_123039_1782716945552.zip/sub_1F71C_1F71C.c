int8_t sub_1F71C(void)

{
  uint32_t val1;
  uint32_t val2;
  int8_t param1;
  uint32_t param2;
  
  val2 = param2 | *(uint32_t *)(param1 + 0x20);
  val1 = val2 | 1;
  if (*(int8_t *)(param1 + 0xe8) != 0) {
    val1 = val2;
  }
  *(uint32_t *)(param1 + 0x20) = val1;
  if ((val1 & *(uint32_t *)(param1 + 0x1c)) == 0) {
    return param1;
  }
  sub_62640("basic_ios::clear");
}