int8_t _Z10parametersRKSsS0_S0_(void)

{
  uint8_t val1;
  char cVar2;
  bool bVar3;

  int8_t val2;
  uint64_t *param2;
  int32_t *piVar6;
  int32_t val3;
  int8_t val4;
  char *pcVar9;
  int8_t val5;
  int8_t iStack_70;
  int8_t iStack_68;
  uint8_t axStack_60 [8];




  sub_67090(&iStack_68,packageName);
  val2 = unk_bff48;
  iStack_70 = unk_bff48 + 0x18;
  pcVar9 = (char *)*param2;
  for (val5 = *(int8_t *)(pcVar9 - 0x18); val5 != 0; val5 = val5 - 1) {
    cVar2 = *pcVar9;
    if (((cVar2 != ' ') && (cVar2 != 'H')) && (cVar2 != 'h')) {
      val4 = *(int8_t *)(iStack_70 - 0x18);
      val1 = val4 + 1;
      if ((*(uint8_t *)(iStack_70 - 0x10) < val1) || (0 < *(int32_t *)(iStack_70 - 8))) {
        sub_63BF0(&iStack_70,val1);
        val4 = *(int8_t *)(iStack_70 - 0x18);
      }
      *(char *)(iStack_70 + val4) = cVar2;
      if (iStack_70 - 0x18 != val2) {
        *(uint32_t *)(iStack_70 - 8) = 0;
        *(uint8_t *)(iStack_70 - 0x18) = val1;
        *(uint8_t *)(iStack_70 + val1) = 0;
      }
    }
    pcVar9 = pcVar9 + 1;
  }
  _Z17executeparametersRKSsS0_S0_S0_();
  if (iStack_70 - 0x18 != val2) {
    piVar6 = (int32_t *)(iStack_70 - 8);
    if (pthread_create == 0) {
      val3 = *piVar6;
      *piVar6 = val3 - 1;
    }
    else {
      do {
        val3 = *piVar6;
        cVar2 = '\x01';
        bVar3 = (bool)ExclusiveMonitorPass(piVar6,0x10);
        if (bVar3) {
          *piVar6 = val3 - 1;
          cVar2 = ExclusiveMonitorsStatus();
        }
      } while (cVar2 != '\0');
    }
    if (val3 < 1) {
      sub_66F0C(iStack_70 - 0x18,axStack_60);
    }
  }
  val5 = iStack_68 - 0x18;
  if (val5 != val2) {
    piVar6 = (int32_t *)(iStack_68 - 8);
    if (pthread_create == 0) {
      val3 = *piVar6;
      *piVar6 = val3 - 1;
    }
    else {
      do {
        val3 = *piVar6;
        cVar2 = '\x01';
        bVar3 = (bool)ExclusiveMonitorPass(piVar6,0x10);
        if (bVar3) {
          *piVar6 = val3 - 1;
          cVar2 = ExclusiveMonitorsStatus();
        }
      } while (cVar2 != '\0');
    }
    if (val3 < 1) {
      val5 = sub_66F0C(val5,&iStack_70);
    }
  }



  __stack_chk_fail();
}