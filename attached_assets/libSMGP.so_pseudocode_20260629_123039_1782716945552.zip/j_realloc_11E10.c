// thunk -> external import
void j_realloc(void) {
    realloc();
}
