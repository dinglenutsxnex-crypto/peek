// thunk -> external import
void j_fseek(void) {
    fseek();
}
