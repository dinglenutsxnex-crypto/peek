// thunk -> external import
void j__ZNSt9exceptionD1Ev(void) {
    _ZNSt9exceptionD1Ev();
}
