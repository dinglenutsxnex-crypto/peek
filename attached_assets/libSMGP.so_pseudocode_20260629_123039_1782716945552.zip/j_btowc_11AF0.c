// thunk -> external import
void j_btowc(void) {
    btowc();
}
