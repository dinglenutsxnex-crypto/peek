// thunk -> external import
void j___cxa_allocate_exception(void) {
    __cxa_allocate_exception();
}
