// thunk -> external import
void j__ZNSt15__exception_ptreqERKNS_13exception_ptrES2_(void) {
    _ZNSt15__exception_ptreqERKNS_13exception_ptrES2_();
}
