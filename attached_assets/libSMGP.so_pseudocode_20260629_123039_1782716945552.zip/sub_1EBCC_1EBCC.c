uint64_t sub_1EBCC(void)

{
  int8_t val1;
  int32_t val2;
  uint32_t val3;
  int8_t param1;
  uint8_t val4;
  uint64_t ret;
  uint8_t val5;
  int8_t val6;
  uint32_t *pxVar8;
  
  val5 = 0;
  do {
    val2 = wctob(val5 & 0xffffffff);
    val6 = param1 + val5;
    val5 = val5 + 1;
    if (val2 == -1) {
      *(uint8_t *)(param1 + 0x18) = 0;
      goto L_0001ec10;
    }
    *(char *)(val6 + 0x19) = (char)val2;
  } while (val5 != 0x80);
  *(uint8_t *)(param1 + 0x18) = 1;
L_0001ec10:
  val5 = 0;
  pxVar8 = (uint32_t *)(param1 + 0x9c);
  do {
    val4 = val5 & 0xffffffff;
    val5 = val5 + 1;
    val3 = btowc(val4);
    *pxVar8 = val3;
    pxVar8 = pxVar8 + 1;
  } while (val5 != 0x100);
  val6 = 0;
  do {
    *(char *)(param1 + val6 + 0x49c) = (char)(1 << (uint8_t)((uint32_t)val6 & 0x1f));
    ret = sub_1E644();
    val1 = val6 * 8;
    val6 = val6 + 1;
    *(uint64_t *)(param1 + val1 + 0x4b0) = ret;
  } while (val6 != 0x10);
  return ret;
}