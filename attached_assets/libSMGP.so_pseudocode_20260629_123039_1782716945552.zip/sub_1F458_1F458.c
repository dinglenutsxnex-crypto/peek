int8_t sub_1F458(void)

{
  int32_t *piVar1;
  uint32_t val1;
  int32_t val2;
  uint32_t val3;
  uint32_t val4;
  char cVar6;
  bool bVar7;
  jclass cls;
  int8_t param1;
  void *param1;
  uint64_t *pxVar9;
  uint64_t *pxVar10;
  uint64_t *pxVar12;
  int8_t param2;
  uint64_t *pxVar13;
  uint64_t val5;
  uint64_t val6;
  int8_t *env;
  int8_t ret;
  uint8_t axStack_8 [8];
  uint64_t *pxVar11;
  
  if (param1 == param2) {
    return param1;
  }
  val1 = *(uint32_t *)(param2 + 0xc0);
  if ((int32_t)val1 < 9) {
    pxVar12 = (uint64_t *)(param1 + 0x40);
  }
  else {
    pxVar12 = _Znam(-(uint8_t)(val1 >> 0x1f) & 0xfffffff000000000 | (uint8_t)val1 << 4);
    val2 = *(int32_t *)(param2 + 0xc0);
    ret = 0;
    pxVar10 = pxVar12;
    if ((int8_t)val2 != 0) {
      do {
        ret = ret + 1;
        *pxVar10 = 0;
        pxVar10[1] = 0;
        pxVar10 = pxVar10 + 2;
      } while (val2 != ret);
    }
  }
  ret = *(int8_t *)(param2 + 0x28);
  if (ret != 0) {
    if (pthread_create == 0) {
      *(int32_t *)(ret + 0x14) = *(int32_t *)(ret + 0x14) + 1;
    }
    else {
      piVar1 = (int32_t *)(ret + 0x14);
      do {
        cVar6 = '\x01';
        bVar7 = (bool)ExclusiveMonitorPass(piVar1,0x10);
        if (bVar7) {
          *piVar1 = *piVar1 + 1;
          cVar6 = ExclusiveMonitorsStatus();
        }
      } while (cVar6 != '\0');
    }
  }
  sub_20210();
  param1 = *(void **)(param1 + 200);
  if (param1 != (void *)(param1 + 0x40)) {
    if (param1 != (void *)0x0) {
      _ZdaPv(param1);
    }
    *(uint64_t *)(param1 + 200) = 0;
  }
  sub_20278();
  val2 = *(int32_t *)(param2 + 0xc0);
  *(int8_t *)(param1 + 0x28) = ret;
  if (0 < val2) {
    pxVar9 = *(uint64_t **)(param2 + 200);
    pxVar10 = pxVar9;
    pxVar13 = pxVar12;
    do {
      pxVar11 = pxVar10 + 2;
      val5 = pxVar10[1];
      *pxVar13 = *pxVar10;
      pxVar13[1] = val5;
      pxVar10 = pxVar11;
      pxVar13 = pxVar13 + 2;
    } while (pxVar11 != pxVar9 + ((uint8_t)(val2 - 1) + 1) * 2);
  }
  val3 = *(uint32_t *)(param2 + 0x18);
  *(uint64_t *)(param1 + 0x10) = *(uint64_t *)(param2 + 0x10);
  val5 = *(uint64_t *)(param2 + 0xd8);
  val6 = *(uint64_t *)(param2 + 8);
  cVar6 = *(char *)(param2 + 0xe1);
  *(uint64_t **)(param1 + 200) = pxVar12;
  *(int32_t *)(param1 + 0xc0) = val2;
  *(uint32_t *)(param1 + 0x18) = val3;
  *(uint64_t *)(param1 + 8) = val6;
  *(uint64_t *)(param1 + 0xd8) = val5;
  if (cVar6 == '\0') {
    env = *(int8_t **)(param2 + 0xf0);
    if (env != (int8_t *)0x0) {
      if ((char)env[7] == '\0') {
        sub_1DFC0();
        cls = (*env)->FindClass(env,"lease)");
      }
      else {
        cls = *(uint8_t *)((int8_t)env + 0x59);
      }
      *(uint8_t *)(param2 + 0xe0) = cls;
      *(uint8_t *)(param2 + 0xe1) = 1;
      goto L_0001f568;
    }
L_0001f6a0:
    sub_61E30();
  }
  else {
    cls = *(uint8_t *)(param2 + 0xe0);
L_0001f568:
    if (*(char *)(param1 + 0xe1) == '\0') {
      env = *(int8_t **)(param1 + 0xf0);
      if (env == (int8_t *)0x0) goto L_0001f6a0;
      if ((char)env[7] == '\0') {
        sub_1DFC0();
        (*env)->FindClass(env,"lease)");
      }
      *(uint8_t *)(param1 + 0xe1) = 1;
    }
    *(uint8_t *)(param1 + 0xe0) = cls;
    sub_3989C(axStack_8,param2 + 0xd0);
    sub_3A0E8(param1 + 0xd0,axStack_8);
    sub_3A188(axStack_8);
    sub_1F2DC();
    sub_20210();
    val1 = *(uint32_t *)(param2 + 0x1c);
    *(uint32_t *)(param1 + 0x1c) = val1;
    val4 = *(uint32_t *)(param1 + 0x20);
    if (*(int8_t *)(param1 + 0xe8) == 0) {
      val4 = val4 | 1;
      *(uint32_t *)(param1 + 0x20) = val4;
    }
    if ((val4 & val1) == 0) {
      return param1;
    }
  }
  ret = sub_62640("basic_ios::clear");
  if ((*(uint32_t *)(ret + 0x20) & 5) != 0) {
    ret = 0;
  }
  return ret;
}