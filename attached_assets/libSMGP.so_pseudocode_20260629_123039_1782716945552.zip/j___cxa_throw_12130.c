// thunk -> external import
void j___cxa_throw(void) {
    __cxa_throw();
}
