int8_t * sub_29778(void)

{
  uint8_t *puVar1;
  void *param1;
  uint8_t val1;
  int8_t val2;
  char *param2;
  int8_t val3;
  char *param3;
  int8_t *ret_ptr;
  uint8_t val4;
  uint8_t val5;
  uint8_t *param1_00;
  uint8_t axStack_8 [8];
  
  param1_00 = unk_bff48 + 3;
  *ret_ptr = (int8_t)param1_00;
  if (param2 == param3) {
    val4 = 0;
  }
  else {
    if ((param2 == (char *)0x0) && (param3 != (char *)0x0)) {
      sub_61E98("basic_string::_S_construct null not valid");
    }
    val4 = (int8_t)param3 - (int8_t)param2;
    puVar1 = (uint8_t *)sub_65788(val4,0,axStack_8);
    param1_00 = puVar1 + 3;
    if (val4 == 1) {
      *(char *)(puVar1 + 3) = *param2;
    }
    else {
      memcpy(param1_00,param2,val4);
    }
    if (puVar1 != unk_bff48) {
      *(uint32_t *)(puVar1 + 2) = 0;
      *puVar1 = val4;
      *(char *)((int8_t)puVar1 + val4 + 0x18) = '\0';
    }
  }
  val4 = val4 << 1;
  val5 = param1_00[-3];
  param1 = _Znam(val4);
  puVar1 = param1_00;
  while( true ) {
    val1 = sub_6FFCC();
    if (val4 <= val1) {
      val4 = val1 + 1;
      _ZdaPv(param1);
      param1 = _Znam(val4);
      sub_6FFCC();
    }
    sub_6433C();
    val1 = strlen((char *)puVar1);
    if ((char *)((int8_t)puVar1 + val1) == (char *)((int8_t)param1_00 + val5)) break;
    val3 = *ret_ptr;
    puVar1 = (uint8_t *)((char *)((int8_t)puVar1 + val1) + 1);
    val2 = *(int8_t *)(val3 - 0x18);
    val1 = val2 + 1;
    if ((*(uint8_t *)(val3 - 0x10) < val1) || (0 < *(int32_t *)(val3 - 8))) {
      sub_63BF0();
      val3 = *ret_ptr;
      val2 = *(int8_t *)(val3 - 0x18);
    }
    *(uint8_t *)(val3 + val2) = 0;
    val2 = *ret_ptr;
    if ((uint8_t *)(val2 - 0x18) != unk_bff48) {
      *(uint32_t *)(val2 - 8) = 0;
      *(uint8_t *)(val2 - 0x18) = val1;
      *(uint8_t *)(val2 + val1) = 0;
    }
  }
  _ZdaPv(param1);
  if (param1_00 - 3 == unk_bff48) {
    return ret_ptr;
  }
  sub_29454(param1_00 - 3,axStack_8);
  return ret_ptr;
}