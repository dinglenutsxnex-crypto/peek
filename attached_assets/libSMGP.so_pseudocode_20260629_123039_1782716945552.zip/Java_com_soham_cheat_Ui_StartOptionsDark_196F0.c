uint64_t Java_com_soham_cheat_Ui_StartOptionsDark(void)

{
  int8_t *param1;
  uint64_t ret;

  __android_log_print(4,(char *)"MainCpp",(char *)"StartOptionsDark called - variant=%d pkg=%s");
  if (unk_c0198 == 1) {
    (*param1)->FindClass();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    ret = *param1;
  }
  else if (unk_c0198 == 2) {
    (*param1)->FindClass();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    ret = *param1;
  }
  else {
    (*param1)->FindClass();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    (*param1)->GetMethodID();
    (*param1)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*param1)->GetObjectClass();
    (*param1)->GetMethodID();
    ret = *param1;
  }
  (**(code **)(iVar2 + 0x538))();
  ret = _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}