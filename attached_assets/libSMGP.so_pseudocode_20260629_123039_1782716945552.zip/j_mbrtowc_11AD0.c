// thunk -> external import
void j_mbrtowc(void) {
    mbrtowc();
}
