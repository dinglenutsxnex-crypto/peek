int8_t sub_25200(void)

{
  int8_t *param1;
  int8_t *env;
  int8_t ret;
  char cStack_8;
  
  param1[1] = 0;
  sub_24104();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
    ret = env[3] - env[2] >> 2;
    if (ret == 0) {
      ret = (*env)->FromReflectedMethod();
    }
    if (0 < ret) {
      env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
      ret = (*env)->FromReflectedField(env);
      param1[1] = ret;
      return ret;
    }
    if (ret == -1) {
      sub_1F6E0();
      return param1[1];
    }
  }
  return param1[1];
}