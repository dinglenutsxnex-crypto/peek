// thunk -> external import
void j__ZSt14__convert_to_vIfEvPKcRT_RSt12_Ios_IostateRKPi(void) {
    _ZSt14__convert_to_vIfEvPKcRT_RSt12_Ios_IostateRKPi();
}
