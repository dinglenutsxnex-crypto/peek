uint8_t _ZNK10__cxxabiv120__si_class_type_info20__do_find_public_srcElPKvPKNS_17__class_type_infoES2_
                (void)

{
  int32_t val1;
  int8_t param1;
  uint8_t val2;
  char *param1;
  int8_t param3;
  int8_t param4;
  int8_t param5;
  
  if (param5 == param3) {
    param1 = *(char **)(param1 + 8);
    if (param1 == *(char **)(param4 + 8)) {
      return 6;
    }
    if ((*param1 != '*') && (val1 = strcmp(param1,*(char **)(param4 + 8)), val1 == 0)) {
      return 6;
    }
  }
  val2 = (**(code **)(**(int8_t **)(param1 + 0x10) + 0x40))(*(int8_t **)(param1 + 0x10));
  return val2 & 0xffffffff;
}