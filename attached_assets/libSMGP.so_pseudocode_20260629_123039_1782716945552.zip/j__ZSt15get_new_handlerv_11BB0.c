// thunk -> external import
void j__ZSt15get_new_handlerv(void) {
    _ZSt15get_new_handlerv();
}
