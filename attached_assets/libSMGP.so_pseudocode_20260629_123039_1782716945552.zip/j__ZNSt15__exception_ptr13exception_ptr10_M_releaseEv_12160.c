// thunk -> external import
void j__ZNSt15__exception_ptr13exception_ptr10_M_releaseEv(void) {
    _ZNSt15__exception_ptr13exception_ptr10_M_releaseEv();
}
