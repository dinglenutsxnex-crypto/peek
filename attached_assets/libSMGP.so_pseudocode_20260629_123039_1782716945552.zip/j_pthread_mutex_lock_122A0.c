// thunk -> external import
void j_pthread_mutex_lock(void) {
    pthread_mutex_lock();
}
