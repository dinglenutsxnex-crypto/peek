// thunk -> external import
void j__Z13executeFieldsRKSsS0_S0_S0_S0_(void) {
    _Z13executeFieldsRKSsS0_S0_S0_S0_();
}
