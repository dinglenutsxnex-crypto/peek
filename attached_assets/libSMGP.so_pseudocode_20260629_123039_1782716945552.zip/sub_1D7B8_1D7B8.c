uint64_t sub_1D7B8(void)

{
  int32_t val;
  int8_t *param1;
  int32_t *piVar2;
  void *param1;
  
  param1 = (void *)*param1;
  if (param1 == (void *)0x0) {
    return 0;
  }
  if ((char)param1[1] != '\0') {
    piVar2 = (int32_t *)__errno();
    *piVar2 = 0;
    while (val = fclose(param1), val != 0) {
      if (*piVar2 != 4) {
        *param1 = 0;
        return 0;
      }
      param1 = (void *)*param1;
    }
  }
  *param1 = 0;
  return param1;
}