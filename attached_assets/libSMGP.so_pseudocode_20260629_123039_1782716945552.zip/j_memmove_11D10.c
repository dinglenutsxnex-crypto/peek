// thunk -> external import
void j_memmove(void) {
    memmove();
}
