// thunk -> external import
void j__ZN7_JNIEnv23CallStaticBooleanMethodEP7_jclassP10_jmethodIDz(void) {
    _ZN7_JNIEnv23CallStaticBooleanMethodEP7_jclassP10_jmethodIDz();
}
