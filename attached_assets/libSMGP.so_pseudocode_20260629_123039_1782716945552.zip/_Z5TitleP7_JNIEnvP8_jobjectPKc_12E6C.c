uint64_t _Z5TitleP7_JNIEnvP8_jobjectPKc(void)

{

  uint64_t ret;

  (*env)->FindClass(env,"android/widget/TextView");
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  ret = _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}