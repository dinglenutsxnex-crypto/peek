uint64_t sub_1D788(void)

{
  uint64_t *param1;
  uint64_t ret;
  
  ret = fileno(*param1);
  return ret;
}