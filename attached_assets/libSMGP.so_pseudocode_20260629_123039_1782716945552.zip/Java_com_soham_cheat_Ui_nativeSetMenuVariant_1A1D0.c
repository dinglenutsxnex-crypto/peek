uint8_t Java_com_soham_cheat_Ui_nativeSetMenuVariant(void)

{
  uint32_t val1;
  uint32_t param3;
  
  unk_c0198 = param3;
  val1 = __android_log_print(4,(char *)"MainCpp",(char *)"nativeSetMenuVariant -> %d");
  return (uint8_t)val1;
}