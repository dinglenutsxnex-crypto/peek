uint8_t sub_1E8A0(void)

{
  int32_t val1;
  int8_t param1;
  uint8_t param2;
  uint64_t val2;
  uint8_t param3;
  int8_t param4;
  uint64_t *pxVar3;
  int8_t val3;
  uint8_t val4;
  uint8_t *puVar6;
  
  if (param2 < param3) {
    val3 = 0;
    do {
      val4 = 0;
      pxVar3 = (uint64_t *)(param1 + 0x4b0);
      puVar6 = (uint8_t *)(param1 + 0x49c);
      do {
        val2 = *pxVar3;
        pxVar3 = pxVar3 + 1;
        val1 = iswctype(*(uint32_t *)(param2 + val3 * 4),val2);
        if (val1 != 0) {
          val4 = *puVar6 | val4;
        }
        puVar6 = puVar6 + 1;
      } while (pxVar3 != (uint64_t *)(param1 + 0x530));
      *(uint8_t *)(param4 + val3) = val4;
      val3 = val3 + 1;
    } while (val3 != (~param2 + param3 >> 2) + 1);
  }
  return param3;
}