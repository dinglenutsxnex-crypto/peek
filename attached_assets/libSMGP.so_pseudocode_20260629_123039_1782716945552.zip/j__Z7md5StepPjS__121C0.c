// thunk -> external import
void j__Z7md5StepPjS_(void) {
    _Z7md5StepPjS_();
}
