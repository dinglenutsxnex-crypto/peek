// thunk -> external import
void j__Z22startActivityPermissonP7_JNIEnvP8_jobject(void) {
    _Z22startActivityPermissonP7_JNIEnvP8_jobject();
}
