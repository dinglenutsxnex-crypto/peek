uint64_t sub_29F70(void)

{

  uint64_t ret_ptr;

  (*env)->FromReflectedMethod();
  return ret_ptr;
}