// thunk -> external import
void j___errno(void) {
    __errno();
}
