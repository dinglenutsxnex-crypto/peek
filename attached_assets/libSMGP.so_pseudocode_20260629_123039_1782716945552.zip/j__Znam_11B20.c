// thunk -> external import
void j__Znam(void) {
    _Znam();
}
