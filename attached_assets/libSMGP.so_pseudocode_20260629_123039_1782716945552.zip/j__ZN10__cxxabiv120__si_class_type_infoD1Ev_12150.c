// thunk -> external import
void j__ZN10__cxxabiv120__si_class_type_infoD1Ev(void) {
    _ZN10__cxxabiv120__si_class_type_infoD1Ev();
}
