uint8_t sub_1F15C(void)

{
  jclass cls;
  int8_t param1;
  uint8_t param2;
  int8_t *env;
  
  env = *(int8_t **)(param1 + 0xf0);
  if (env == (int8_t *)0x0) {
    sub_61E30();
  }
  if ((char)env[7] != '\0') {
    return (uint8_t)*(uint8_t *)((int8_t)env + (int8_t)(int32_t)(uint32_t)param2 + 0x39);
  }
  sub_1DFC0();
  cls = (*env)->FindClass(env,param2);
  return (uint8_t)cls;
}