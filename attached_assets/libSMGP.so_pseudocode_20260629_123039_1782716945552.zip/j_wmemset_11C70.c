// thunk -> external import
void j_wmemset(void) {
    wmemset();
}
