// thunk -> external import
void j__ZNSt15__exception_ptr13exception_ptr9_M_addrefEv(void) {
    _ZNSt15__exception_ptr13exception_ptr9_M_addrefEv();
}
