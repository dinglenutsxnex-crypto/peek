// thunk -> external import
void j_dl_iterate_phdr(void) {
    dl_iterate_phdr();
}
