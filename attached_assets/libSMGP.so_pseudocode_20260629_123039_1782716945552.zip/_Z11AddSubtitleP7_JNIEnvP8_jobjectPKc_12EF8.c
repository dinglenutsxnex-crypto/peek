uint64_t _Z11AddSubtitleP7_JNIEnvP8_jobjectPKc(void)

{

  uint64_t ret;

  (*env)->FindClass(env,"android/widget/LinearLayout");
  (*env)->GetMethodID();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  (*env)->FindClass();
  (*env)->GetMethodID();
  _ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz();
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  (*env)->GetMethodID();
  (*env)->GetMethodID();
  _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz(0x4030000000000000);
  (*env)->GetMethodID();
  _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  (*env)->GetMethodID();
  ret = _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}