// thunk -> external import
void j_strxfrm(void) {
    strxfrm();
}
