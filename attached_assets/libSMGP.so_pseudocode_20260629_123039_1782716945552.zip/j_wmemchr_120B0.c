// thunk -> external import
void j_wmemchr(void) {
    wmemchr();
}
