uint64_t sub_29258(void)

{
  uint64_t *param1;
  
  *param1 = 0xba6e0;
  sub_6F8D4(param1 + 2);
}