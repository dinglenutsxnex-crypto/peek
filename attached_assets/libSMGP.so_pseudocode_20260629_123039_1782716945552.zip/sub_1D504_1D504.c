uint8_t sub_1D504(void)

{
  int32_t param1;
  int8_t val;
  int32_t *piVar2;
  void *param2;
  uint8_t param3;
  uint8_t param3;
  
  param3 = param3;
  do {
    while (val = write(param1,param2,param3), val == -1) {
      piVar2 = (int32_t *)__errno();
      if (*piVar2 != 4) {
        return param3 - param3;
      }
    }
    param3 = param3 - val;
    param2 = (void *)((int8_t)param2 + val);
  } while (param3 != 0);
  return param3;
}