int8_t * sub_226A8(void)

{
  jboolean val;
  int8_t *param1;
  int8_t *env;
  char cStack_8;
  
  param1[1] = 0;
  sub_1ED34();
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
    if (env == (int8_t *)0x0) {
L_00022750:
      sub_1ED34();
      return param1;
    }
    if ((uint8_t)env[1] < (uint8_t)env[2]) {
      env[2] = env[2] - 1;
    }
    else {
      val = (*env)->IsAssignableFrom(env,JNI_ERR);
      if (val == -1) goto L_00022750;
    }
  }
  return param1;
}