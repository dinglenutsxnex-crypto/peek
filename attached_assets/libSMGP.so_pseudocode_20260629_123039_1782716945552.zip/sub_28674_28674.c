int8_t * sub_28674(void)

{
  uint8_t val1;
  jclass cls;
  int8_t *param1;
  int32_t *piVar3;
  int8_t *param2;
  int8_t val2;
  int8_t val3;
  int32_t param3;
  int32_t *piVar6;
  int8_t *env;
  uint8_t val4;
  char cStack_8;
  
  sub_24104();
  if (cStack_8 != '\0') {
    sub_69974();
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
    if ((int32_t *)env[2] < (int32_t *)env[3]) {
      cls = *(int32_t *)env[2];
    }
    else {
      cls = (*env)->ToReflectedMethod(env);
    }
    val4 = 0;
    do {
      while( true ) {
        if ((cls == -1) || (param3 == cls)) goto joined_r0x00028878;
        piVar6 = (int32_t *)env[3];
        piVar3 = (int32_t *)env[2];
        val2 = (int8_t)piVar6 - (int8_t)piVar3 >> 2;
        val3 = 0xffffffffffffffe - val4;
        if (val2 < (int8_t)(0xffffffffffffffe - val4)) {
          val3 = val2;
        }
        if (val3 < 2) break;
        val2 = wmemchr(piVar3,param3,val3);
        if (val2 != 0) {
          val3 = val2 - env[2] >> 2;
        }
        sub_6BA98();
        val2 = env[2];
        val4 = val4 + val3;
        val1 = val2 + val3 * 4;
        env[2] = val1;
        if (val1 < (uint8_t)env[3]) {
          cls = *(int32_t *)(val2 + val3 * 4);
        }
        else {
L_000288ac:
          cls = (*env)->ToReflectedMethod(env);
        }
L_00028788:
        if (0xffffffffffffffd < val4) goto joined_r0x00028878;
      }
      val3 = *param2;
      val2 = *(int8_t *)(val3 - 0x18);
      val1 = val2 + 1;
      if ((*(uint8_t *)(val3 - 0x10) < val1) || (0 < *(int32_t *)(val3 - 8))) {
        sub_6B63C();
        val3 = *param2;
        piVar3 = (int32_t *)env[2];
        piVar6 = (int32_t *)env[3];
        val2 = *(int8_t *)(val3 - 0x18);
      }
      *(int32_t *)(val3 + val2 * 4) = cls;
      if ((uint8_t *)(val3 - 0x18) != unk_bfb98) {
        *(uint32_t *)(val3 - 8) = 0;
        *(uint8_t *)(val3 - 0x18) = val1;
        *(uint32_t *)(val3 + val1 * 4) = 0;
      }
      val4 = val4 + 1;
      if (piVar3 < piVar6) {
        cls = *piVar3;
        env[2] = (int8_t)(piVar3 + 1);
      }
      else {
        cls = (*env)->GetSuperclass(env);
      }
      if (cls == -1) goto L_00028788;
      if ((int32_t *)env[3] <= (int32_t *)env[2]) goto L_000288ac;
      cls = *(int32_t *)env[2];
    } while (val4 < 0xffffffffffffffe);
joined_r0x00028878:
    if ((cls != -1) && (param3 == cls)) {
      if ((uint8_t)env[2] < (uint8_t)env[3]) {
        env[2] = env[2] + 4;
      }
      else {
        (*env)->GetSuperclass(env);
      }
      if (val4 != 0xffffffffffffffff) {
        return param1;
      }
    }
  }
  sub_1F6E0();
  return param1;
}