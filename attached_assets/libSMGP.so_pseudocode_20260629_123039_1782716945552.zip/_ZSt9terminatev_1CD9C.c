void _ZSt9terminatev(void)

{
  _ZSt13get_terminatev();
  _ZN10__cxxabiv111__terminateEPFvvE();
}