uint8_t * sub_1E500(void)

{
  jint result;
  int8_t *env;
  uint8_t *param2;
  uint8_t *param3;
  uint8_t *pxVar2;
  
  if (param2 < param3) {
    do {
      result = (*env)->GetVersion();
      pxVar2 = param2 + 1;
      *param2 = result;
      param2 = pxVar2;
    } while (pxVar2 != param3);
  }
  return param3;
}