int8_t sub_1DA28(void)

{
  int32_t val1;
  uint64_t *param1;
  uint8_t *pxVar2;
  int8_t val2;
  int32_t iStack_8c;
  uint32_t xStack_88;

  uint8_t axStack_80 [16];
  uint32_t uStack_70;
  int8_t iStack_50;

  iStack_8c = 0;
  val1 = fileno(*param1);
  val1 = ioctl(val1,0x541b,&iStack_8c);
  if ((val1 == 0) && (-1 < iStack_8c)) {
    return (int8_t)iStack_8c;
  }
  pxVar2 = sub_1D788();
  xStack_88 = (pxVar2 - 0);
  xStack_88 = 1;
  val1 = poll(&xStack_88,1,0);
  if (0 < val1) {
    pxVar2 = sub_1D788();
    val1 = fstat((int32_t)pxVar2,axStack_80);
    if ((val1 == 0) && ((uStack_70 & 0xf000) == 0x8000)) {
      pxVar2 = sub_1D788();
      val2 = lseek(pxVar2,0,1);
      return iStack_50 - val2;
    }
  }
  return 0;
}