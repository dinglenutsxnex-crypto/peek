uint64_t sub_1FBBC(void)

{
  char cVar1;
  int8_t param1;
  uint64_t ret;
  
  cVar1 = sub_4E19C();
  if (cVar1 == '\0') {
    *(uint64_t *)(param1 + 0xf0) = 0;
    cVar1 = sub_4E34C();
  }
  else {
    ret = sub_4C214();
    *(uint64_t *)(param1 + 0xf0) = ret;
    cVar1 = sub_4E34C();
  }
  if (cVar1 == '\0') {
    *(uint64_t *)(param1 + 0xf8) = 0;
    cVar1 = sub_4E3B8();
  }
  else {
    ret = sub_4CF28();
    *(uint64_t *)(param1 + 0xf8) = ret;
    cVar1 = sub_4E3B8();
  }
  if (cVar1 != '\0') {
    ret = sub_4CF90();
    *(uint64_t *)(param1 + 0x100) = ret;
    return ret;
  }
  *(uint64_t *)(param1 + 0x100) = 0;
  return 0;
}