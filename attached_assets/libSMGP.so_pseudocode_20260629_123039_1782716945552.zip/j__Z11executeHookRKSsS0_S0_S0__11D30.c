// thunk -> external import
void j__Z11executeHookRKSsS0_S0_S0_(void) {
    _Z11executeHookRKSsS0_S0_S0_();
}
