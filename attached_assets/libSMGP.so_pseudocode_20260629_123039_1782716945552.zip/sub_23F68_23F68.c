void sub_23F68(uint64_t param_1,code *param_2)

{
  (*param_2)();
  return;
}