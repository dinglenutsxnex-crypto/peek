// thunk -> external import
void j__ZSt10unexpectedv(void) {
    _ZSt10unexpectedv();
}
