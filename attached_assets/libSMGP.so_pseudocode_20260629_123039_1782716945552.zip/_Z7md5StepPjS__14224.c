// detected - Rolling XOR cipher (detection may be wrong)
// detected - XOR with constant (detection may be wrong)
void _Z7md5StepPjS_(uint32_t *param_1,int8_t param_2)

{
  uint32_t val1;
  uint32_t val2;
  uint32_t val3;
  uint32_t val4;
  uint32_t val5;
  uint32_t val6;
  uint32_t val7;
  int8_t val8;

  uint8_t val9;
  uint8_t val10;
  uint8_t val11;
  uint8_t val12;

  val9 = 0;
  val10 = 0;
  val11 = 5;
  val12 = 1;
  val1 = *param_1;
  val5 = param_1[3];
  val6 = param_1[2];
  val7 = param_1[1];
  do {
    val4 = val7;
    val3 = val6;
    val2 = val5;
    val7 = (uint32_t)(val10 >> 4) & 0xfffffff;
    if (val7 == 2) {
      val7 = val3 ^ val4 ^ val2;
      val8 = val11 & 0xf;
    }
    else if (val7 == 1) {
      val7 = val2 & val4 | val3 & (val2 ^ 0xffffffff);
      val8 = val12 & 0xf;
    }
    else if ((val10 >> 4 & 0xfffffff) == 0) {
      val7 = val2 & (val4 ^ 0xffffffff) | val3 & val4;
      val8 = val10;
    }
    else {
      val7 = (val4 | val2 ^ 0xffffffff) ^ val3;
      val8 = val9 & 0xf;
    }
    val8 = val10 * 4;
    val10 = val10 + 1;
    val7 = val7 + val1 + *(int32_t *)(val8 + 0x84d68) +
            *(int32_t *)(param_2 + (uVar9 & 0xffffffff) * 4);
    val1 = 0x20U - *(int32_t *)(val8 + 0x84e68) & 0x1f;
    val11 = val11 + 3;
    val9 = val9 + 7;
    val7 = (val7 >> val1 | val7 << 0x20 - val1) + val4;
    val12 = val12 + 5;
    val1 = val2;
    val5 = val3;
    val6 = val4;
  } while (val10 != 0x40);
  *param_1 = val2 + *param_1;
  param_1[1] = val7 + param_1[1];
  param_1[2] = val4 + param_1[2];
  param_1[3] = val3 + param_1[3];
  return;
}