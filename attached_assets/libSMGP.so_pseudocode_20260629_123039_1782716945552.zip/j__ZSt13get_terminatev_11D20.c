// thunk -> external import
void j__ZSt13get_terminatev(void) {
    _ZSt13get_terminatev();
}
