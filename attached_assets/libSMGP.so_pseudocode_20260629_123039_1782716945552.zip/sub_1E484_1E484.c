uint8_t * sub_1E484(void)

{
  uint8_t val;
  int8_t *param1;
  uint8_t *param2;
  uint8_t *param3;
  uint8_t *pxVar2;
  
  if (param2 < param3) {
    do {
      val = (**(code **)(*param1 + 0x10))();
      pxVar2 = param2 + 1;
      *param2 = val;
      param2 = pxVar2;
    } while (pxVar2 != param3);
  }
  return param3;
}