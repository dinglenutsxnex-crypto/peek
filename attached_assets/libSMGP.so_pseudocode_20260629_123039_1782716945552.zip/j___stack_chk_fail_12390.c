// thunk -> external import
void j___stack_chk_fail(void) {
    __stack_chk_fail();
}
