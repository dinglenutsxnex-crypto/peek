void sub_29498(int8_t *env)

{
  (*env)->GetSuperclass();
  return;
}