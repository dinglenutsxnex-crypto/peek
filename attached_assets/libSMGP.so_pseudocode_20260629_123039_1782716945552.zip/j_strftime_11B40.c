// thunk -> external import
void j_strftime(void) {
    strftime();
}
