uint64_t _ZSt13get_terminatev(void)

{
  return *_ZN10__cxxabiv119__terminate_handlerE;
}