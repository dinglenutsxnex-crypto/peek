int8_t * sub_21698(void)

{
  int8_t *param1;
  int8_t val;
  int8_t param2;
  char cStack_8;
  char cStack_1;
  
  sub_21204();
  if ((param2 == 0) || (cStack_8 == '\0')) {
    if (param2 != 0) {
      return param1;
    }
  }
  else {
    val = sub_48EC0(*(uint64_t *)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8));
    if ((val != 0) && (cStack_1 == '\0')) {
      return param1;
    }
  }
  sub_1ED34();
  return param1;
}