uint64_t sub_20D7C(void)

{
  int8_t param1;
  uint64_t ret;
  uint8_t axStack_8 [8];
  
  *(uint64_t *)(param1 + 8) = 6;
  *(uint64_t *)(param1 + 0x10) = 0;
  *(uint32_t *)(param1 + 0x18) = 0x1002;
  sub_3BC18(axStack_8);
  sub_3A0E8(param1 + 0xd0,axStack_8);
  ret = sub_3A188(axStack_8);
  return ret;
}