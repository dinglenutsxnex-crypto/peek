void _ZNSt6thread10_Impl_baseD0Ev(void)

{
  code *pcVar1;
  
  pcVar1 = (code *)SoftwareBreakpoint(1,0x1a670);
  (*pcVar1)();
}