uint64_t sub_1E170(void)

{
  uint64_t *param1;
  uint64_t val;
  int8_t param2;
  
  *(uint32_t *)(param1 + 1) = (uint32_t)(param2 != 0);
  *param1 = 0xbcc00;
  val = sub_39ED0();
  param1[2] = val;
  *(uint8_t *)(param1 + 3) = 0;
}