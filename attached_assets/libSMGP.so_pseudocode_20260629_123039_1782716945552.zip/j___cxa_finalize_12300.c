// thunk -> external import
void j___cxa_finalize(void) {
    __cxa_finalize();
}
