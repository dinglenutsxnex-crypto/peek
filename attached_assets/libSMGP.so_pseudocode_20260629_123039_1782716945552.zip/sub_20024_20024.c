uint64_t * sub_20024(void)

{
  int8_t param1;
  uint64_t *pxVar1;
  uint64_t param2;
  uint32_t param3;
  
  pxVar1 = _Znwm(0x18);
  *pxVar1 = *(uint64_t *)(param1 + 0x28);
  pxVar1[1] = param2;
  *(uint32_t *)(pxVar1 + 2) = param3;
  *(uint32_t *)((int8_t)pxVar1 + 0x14) = 0;
  *(uint64_t **)(param1 + 0x28) = pxVar1;
  return pxVar1;
}