uint8_t _Z16hexStringToBytesPKcPh(void)

{
  uint32_t val1;
  char *param1;
  uint8_t val2;
  uint8_t val3;
  uint8_t ret;
  
  val2 = strlen(param1);
  ret = 0;
  if (val2 != 0) {
    val3 = 0;
    do {
      val1 = sscanf(param1 + val3,(char *)"%2hhx");
      ret = (uint8_t)val1;
      val3 = val3 + 2;
    } while (val3 < val2);
  }
  return ret;
}