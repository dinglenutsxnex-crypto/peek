// detected - ay::obfuscate (compile-time XOR string obfuscation) (detection may be wrong)
void _ZN2ay14OBFUSCATE_dataILm2ELc46EED2Ev(uint16_t *param_1)

{
  *param_1 = 0;
  return;
}