// thunk -> external import
void j_sysconf(void) {
    sysconf();
}
