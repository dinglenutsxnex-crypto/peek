uint8_t sub_1EE64(void)

{
  uint64_t *pxVar1;
  char cVar2;
  uint64_t *param1;
  uint64_t val;
  int8_t param2;
  
  sub_1FF5C();
  param1[0x1b] = 0;
  *param1 = 0xba5c0;
  pxVar1 = param1 + 0x1a;
  *(uint8_t *)(param1 + 0x1c) = 0;
  *(uint8_t *)((int8_t)param1 + 0xe1) = 0;
  param1[0x1d] = 0;
  param1[0x1e] = 0;
  param1[0x1f] = 0;
  param1[0x20] = 0;
  sub_20D7C();
  cVar2 = sub_2D0B8(pxVar1);
  if (cVar2 == '\0') {
    param1[0x1e] = 0;
    cVar2 = sub_2D268(pxVar1);
  }
  else {
    val = sub_2B34C(pxVar1);
    param1[0x1e] = val;
    cVar2 = sub_2D268(pxVar1);
  }
  if (cVar2 == '\0') {
    param1[0x1f] = 0;
    cVar2 = sub_2D2D4(pxVar1);
  }
  else {
    val = sub_2C17C(pxVar1);
    param1[0x1f] = val;
    cVar2 = sub_2D2D4(pxVar1);
  }
  if (cVar2 == '\0') {
    param1[0x20] = 0;
  }
  else {
    val = sub_2C1E4(pxVar1);
    param1[0x20] = val;
  }
  *(uint8_t *)(param1 + 0x1c) = 0;
  param1[0x1d] = param2;
  *(uint8_t *)((int8_t)param1 + 0xe1) = 0;
  param1[0x1b] = 0;
  *(uint32_t *)((int8_t)param1 + 0x1c) = 0;
  *(uint32_t *)(param1 + 4) = (uint32_t)(param2 == 0);
  return (uint8_t)(param2 == 0);
}