// thunk -> external import
void j_vsprintf(void) {
    vsprintf();
}
