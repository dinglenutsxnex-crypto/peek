int8_t sub_1F6E0(void)

{
  uint32_t val;
  int8_t param1;
  uint32_t param2;
  
  val = param2 | 1;
  if (*(int8_t *)(param1 + 0xe8) != 0) {
    val = param2;
  }
  *(uint32_t *)(param1 + 0x20) = val;
  if ((val & *(uint32_t *)(param1 + 0x1c)) == 0) {
    return param1;
  }
  sub_62640("basic_ios::clear");
}