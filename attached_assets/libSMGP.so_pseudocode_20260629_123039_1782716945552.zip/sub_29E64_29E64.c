void sub_29E64(uint64_t *param_1,uint64_t param_2,uint64_t param_3,int8_t param_4)

{
  *(uint32_t *)(param_1 + 1) = (uint32_t)(param_4 != 0);
  param_1[2] = 0;
  *param_1 = 0xbd1d0;
  sub_3C7F4();
  return;
}