// thunk -> external import
void j__ZN10__cxxabiv121__vmi_class_type_infoD1Ev(void) {
    _ZN10__cxxabiv121__vmi_class_type_infoD1Ev();
}
