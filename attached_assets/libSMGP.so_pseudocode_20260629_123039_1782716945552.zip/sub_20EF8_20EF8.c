uint64_t sub_20EF8(void)

{
  uint64_t *param1;
  
  *param1 = 0xba698;
  param1[1] = 0;
  param1[2] = unk_bfee8 + 0x10;
  sub_202FC();
}