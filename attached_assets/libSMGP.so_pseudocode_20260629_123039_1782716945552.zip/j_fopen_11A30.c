// thunk -> external import
void j_fopen(void) {
    fopen();
}
