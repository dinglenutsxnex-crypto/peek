int8_t sub_1F7D0(void)

{
  uint32_t val;
  int8_t param1;
  uint32_t param2;
  
  *(uint32_t *)(param1 + 0x1c) = param2;
  val = *(uint32_t *)(param1 + 0x20);
  if (*(int8_t *)(param1 + 0xe8) == 0) {
    val = val | 1;
    *(uint32_t *)(param1 + 0x20) = val;
  }
  if ((val & param2) == 0) {
    return param1;
  }
  sub_62640("basic_ios::clear");
}