uint64_t _Z11startInjectP7_JNIEnvP8_jobject(void)

{

  uint64_t ret;

  (*env)->GetObjectClass();
  (*env)->FindClass();
  (*env)->FindClass();
  (*env)->GetMethodID();
  _ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz();
  (*env)->GetMethodID();
  ret = _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}