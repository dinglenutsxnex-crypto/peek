// thunk -> external import
void j_system(void) {
    system();
}
