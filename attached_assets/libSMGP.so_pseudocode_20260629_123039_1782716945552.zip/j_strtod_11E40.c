// thunk -> external import
void j_strtod(void) {
    strtod();
}
