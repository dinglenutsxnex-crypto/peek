uint64_t sub_1F9E4(void)

{
  uint32_t val1;
  int8_t param1;
  int8_t *env;
  jclass cls;
  uint32_t param2;
  
  if (*(char *)(param1 + 0xe4) != '\0') {
    val1 = *(uint32_t *)(param1 + 0xe0);
    *(uint32_t *)(param1 + 0xe0) = param2;
    return (uint8_t)val1;
  }
  env = *(int8_t **)(param1 + 0xf0);
  if (env != (int8_t *)0x0) {
    cls = (*env)->GetSuperclass(env,0x20);
    *(uint32_t *)(param1 + 0xe0) = param2;
    *(uint8_t *)(param1 + 0xe4) = 1;
    jclass cls;
  }
  sub_61E30();
}