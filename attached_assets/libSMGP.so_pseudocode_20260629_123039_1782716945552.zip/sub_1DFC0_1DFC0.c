uint8_t sub_1DFC0(void)

{
  char cVar1;
  char cVar2;
  uint32_t val1;
  int8_t *env;
  uint64_t *pxVar4;
  uint64_t *pxVar5;
  uint8_t ret;
  int8_t val2;
  int8_t val3;
  uint64_t axStack_100 [32];
  
  pxVar4 = axStack_100;
  val2 = unk_1e0e0;
  val3 = "CC: (GNU) 4.9.x 20150123 (prerelease)";
  do {
    cVar1 = (char)val2;
    cVar2 = (char)val3;
    val2 = val2 + " 20150123 (prerelease)";
    val3 = val3 + " 20150123 (prerelease)";
    pxVar5 = pxVar4 + 2;
    pxVar4[1] = ((long long)(cVar2 + (char)".x 20150123 (prerelease)") << 56 | (unsigned long long)(
                         CONCAT16(cVar1 + (char)".x 20150123 (prerelease)",
                                  CONCAT15(cVar2 + (char)".9.x 20150123 (prerelease)",
                                           CONCAT14(cVar1 + (char)".9.x 20150123 (prerelease)",
                                                    CONCAT13(cVar2 + (char)" 4.9.x 20150123 (prerelease)",
                                                             CONCAT12(cVar1 + (char)
             
    ;
    *pxVar4 = ((long long)(cVar2 + (char)"GNU) 4.9.x 20150123 (prerelease)") << 56 | (unsigned long long)(
                       CONCAT16(cVar1 + (char)"GNU) 4.9.x 20150123 (prerelease)",
                                CONCAT15(cVar2 + (char)" (GNU) 4.9.x 20150123 (prerelease)",
                                         CONCAT14(cVar1 + (char)" (GNU) 4.9.x 20150123 (prerelease)",
                                                  CONCAT13(cVar2 + (char)"C: (GNU) 4.9.x 20150123 (prerelease)",
                                                           CONCAT12(cVar1 + (char)
                       ;
    pxVar4 = pxVar5;
  } while (pxVar5 != (uint64_t *)&stack0x00000000);
  (*env)->FromReflectedMethod();
  *(uint8_t *)(env + 7) = 1;
  val1 = memcmp(axStack_100,(void *)((int8_t)env + 0x39),0x100);
  ret = (uint8_t)val1;
  if (val1 != 0) {
    ret = 2;
    *(uint8_t *)(env + 7) = 2;
  }
  return ret;
}