// thunk -> external import
void j__Z14executeCommandRKSsS0_S0_S0_S0_(void) {
    _Z14executeCommandRKSsS0_S0_S0_S0_();
}
