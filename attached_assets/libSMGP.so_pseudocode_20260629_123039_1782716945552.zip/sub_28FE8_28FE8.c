uint64_t sub_28FE8(void)

{
  uint64_t *param1;
  uint64_t ret0;
  
  *param1 = 0xba7b0;
  sub_397CC();
  _ZdlPv(param1);
  return ret0;
}