int8_t * sub_22FAC(void)

{
  int8_t *param1;
  uint8_t param2;
  int8_t val;
  int8_t *env;
  uint8_t axVar3 [12];
  
  val = *(int8_t *)(*param1 - 0x18);
  if (*(char *)((int8_t)param1 + val + 0xe1) != '\0') {
    *(uint8_t *)((int8_t)param1 + val + 0xe0) = param2;
    return param1;
  }
  env = *(int8_t **)((int8_t)param1 + val + 0xf0);
  if (env != (int8_t *)0x0) {
    if ((char)env[7] == '\0') {
      sub_1DFC0();
      (*env)->FindClass(env,"lease)");
    }
    *(uint8_t *)((int8_t)param1 + val + 0xe0) = param2;
    *(uint8_t *)((int8_t)param1 + val + 0xe1) = 1;
    return param1;
  }
  axVar3 = sub_61E30();
  env = axVar3._0_8_;
  *(uint32_t *)((int8_t)env + *(int8_t *)(*env - 0x18) + 0x18) =
       *(uint32_t *)((int8_t)env + *(int8_t *)(*env - 0x18) + 0x18) | axVar3._8_4_;
  return env;
}