// thunk -> external import
void j_strncmp(void) {
    strncmp();
}
