uint64_t sub_28E8C(void)

{
  void *param1;
  uint64_t ret0;
  
  sub_28D6C();
  _ZdlPv(param1);
  return ret0;
}