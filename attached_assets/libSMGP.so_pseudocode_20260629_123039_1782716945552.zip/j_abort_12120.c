// thunk -> external import
void j_abort(void) {
    abort();
}
