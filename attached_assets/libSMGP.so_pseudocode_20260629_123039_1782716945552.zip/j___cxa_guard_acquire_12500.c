// thunk -> external import
void j___cxa_guard_acquire(void) {
    __cxa_guard_acquire();
}
