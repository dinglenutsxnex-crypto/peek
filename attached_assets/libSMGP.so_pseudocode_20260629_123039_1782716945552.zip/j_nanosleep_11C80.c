// thunk -> external import
void j_nanosleep(void) {
    nanosleep();
}
