uint64_t sub_1D674(void)

{
  int8_t *param1;
  int8_t val;
  int32_t param2;
  uint32_t param3;
  
  val = sub_1D440(param3);
  if ((val != 0) && (*param1 == 0)) {
    val = fdopen(param2,val);
    *param1 = val;
    if (val != 0) {
      *(uint8_t *)(param1 + 1) = 1;
      if (param2 != 0) {
        return param1;
      }
      setvbuf(val,0,2,0);
      return param1;
    }
  }
  return 0;
}