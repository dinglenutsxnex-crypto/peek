// thunk -> external import
void j_strtoul(void) {
    strtoul();
}
