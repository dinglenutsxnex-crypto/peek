uint8_t _ZNK10__cxxabiv120__si_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE
                (void)

{
  char cVar1;
  uint8_t val1;
  int32_t val2;
  int8_t param1;
  uint8_t ret;
  uint32_t val3;
  int8_t param2;
  uint32_t param3;
  int8_t param4;
  int8_t param5;
  int8_t param6;
  int8_t param7;
  int8_t *param8;
  char *param1;
  
  param1 = *(char **)(param1 + 8);
  if (param1 == *(char **)(param4 + 8)) {
L_0001d228:
    *param8 = param5;
    *(uint32_t *)(param8 + 1) = param3;
    if (-1 < param2) {
      val3 = 6;
      if (param7 != param5 + param2) {
        val3 = 1;
      }
      *(uint32_t *)(param8 + 2) = val3;
      return 0;
    }
    ret = 0;
    if (param2 == -2) {
      *(uint32_t *)(param8 + 2) = 1;
    }
  }
  else {
    cVar1 = *param1;
    if (cVar1 != '*') {
      val2 = strcmp(param1,*(char **)(param4 + 8));
      if (val2 == 0) goto L_0001d228;
    }
    if (param5 == param7) {
      if (param1 == *(char **)(param6 + 8)) {
L_0001d2c4:
        *(uint32_t *)((int8_t)param8 + 0xc) = param3;
        return 0;
      }
      if (cVar1 != '*') {
        val2 = strcmp(param1,*(char **)(param6 + 8));
        if (val2 == 0) goto L_0001d2c4;
      }
    }
    val1 = (**(code **)(**(int8_t **)(param1 + 0x10) + 0x38))(*(int8_t **)(param1 + 0x10));
    ret = (uint8_t)val1;
  }
  return ret;
}