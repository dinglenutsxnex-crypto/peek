int8_t * sub_22284(void)

{
  int8_t *param1;
  int8_t val;
  int8_t param3;
  int8_t *env;
  char cStack_8;
  
  param1[1] = 0;
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
    val = (*env)->FromReflectedField(env);
    param1[1] = val;
    if (param3 != val) {
      sub_1ED34();
      return param1;
    }
  }
  return param1;
}