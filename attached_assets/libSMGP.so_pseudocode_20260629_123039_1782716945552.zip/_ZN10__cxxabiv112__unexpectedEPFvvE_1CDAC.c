void _ZN10__cxxabiv112__unexpectedEPFvvE(code *param_1)

{
  (*param_1)();
  _ZSt9terminatev();
}