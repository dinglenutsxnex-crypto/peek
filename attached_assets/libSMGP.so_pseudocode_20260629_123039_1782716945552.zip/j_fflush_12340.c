// thunk -> external import
void j_fflush(void) {
    fflush();
}
