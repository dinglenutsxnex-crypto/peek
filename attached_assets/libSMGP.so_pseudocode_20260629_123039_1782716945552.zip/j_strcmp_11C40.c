// thunk -> external import
void j_strcmp(void) {
    strcmp();
}
