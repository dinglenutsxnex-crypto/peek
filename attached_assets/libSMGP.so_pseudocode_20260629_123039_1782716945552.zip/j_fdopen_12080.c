// thunk -> external import
void j_fdopen(void) {
    fdopen();
}
