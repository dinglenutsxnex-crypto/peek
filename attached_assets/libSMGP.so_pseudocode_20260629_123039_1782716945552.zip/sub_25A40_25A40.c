int8_t * sub_25A40(void)

{
  int8_t *param1;
  jint result;
  int8_t *env;
  char cStack_8;
  
  sub_1F6E0();
  sub_24104();
  if (((cStack_8 != '\0') && ((*(uint32_t *)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0x20) & 5) == 0)
      ) && (env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8),
           result = (*env)->GetVersion(env), result == -1)) {
    sub_1F6E0();
    return param1;
  }
  return param1;
}