// thunk -> external import
void j_fstat(void) {
    fstat();
}
