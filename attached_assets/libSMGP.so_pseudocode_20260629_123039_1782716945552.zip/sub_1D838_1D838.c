int8_t sub_1D838(void)

{
  int32_t param1;
  uint64_t *param1;
  int8_t ret;
  int32_t *piVar2;
  void *param2;
  uint8_t param3;
  
  do {
    param1 = fileno(*param1);
    ret = read(param1,param2,param3);
    if (ret != -1) {
      return ret;
    }
    piVar2 = (int32_t *)__errno();
  } while (*piVar2 == 4);
  return 0xffffffffffffffff;
}