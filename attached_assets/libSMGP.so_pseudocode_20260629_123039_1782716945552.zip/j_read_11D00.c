// thunk -> external import
void j_read(void) {
    read();
}
