uint64_t sub_29F18(void)

{

  uint64_t ret_ptr;

  (*env)->DefineClass();
  return ret_ptr;
}