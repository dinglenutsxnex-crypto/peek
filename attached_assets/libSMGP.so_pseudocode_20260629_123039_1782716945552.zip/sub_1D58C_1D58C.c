uint64_t * sub_1D58C(void)

{
  uint32_t val;
  uint64_t *param1;
  int32_t *piVar2;
  uint64_t *pxVar3;
  void *param1;
  
  param1 = (void *)*param1;
  pxVar3 = param1;
  if ((param1 != (void *)0x0) && (*(char *)(param1 + 1) != '\0')) {
    piVar2 = (int32_t *)__errno();
    *piVar2 = 0;
    val = fclose(param1);
    while ((pxVar3 = (uint64_t *)(uint8_t)val, val != 0 && (*piVar2 == 4))) {
      val = fclose((void *)*param1);
    }
  }
  return pxVar3;
}