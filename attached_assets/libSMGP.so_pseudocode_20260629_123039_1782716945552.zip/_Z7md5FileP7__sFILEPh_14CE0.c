// detected - Rolling XOR cipher (detection may be wrong)
// detected - XOR with constant (detection may be wrong)
// detected - SHA-1 (detection may be wrong)
uint64_t _Z7md5FileP7__sFILEPh(void)

{

  unkuint3 Var2;
  uint32_t val1;
  uint32_t val2;
  uint32_t val3;
  void *param1;
  void *param1;
  uint8_t val4;

  uint64_t *param2;

  uint8_t val5;
  int8_t val6;
  uint8_t val7;
  uint32_t val8;
  uint8_t val9;
  uint8_t val10;
  uint8_t val11;
  uint32_t val12;
  int8_t val13;

  uint32_t val14;
  uint32_t val15;
  uint32_t val16;
  uint32_t val17;

  uint64_t xStack_110;
  uint64_t xStack_108;
  uint64_t xStack_100;
  uint64_t xStack_f8;
  uint64_t xStack_f0;
  uint64_t xStack_e8;
  uint64_t xStack_e0;
  uint64_t xStack_d8;
  uint64_t xStack_d0;
  uint64_t xStack_c8;

  param1 = malloc(0x400);
  val17 = 0;
  xStack_110 = unk_84038;
  val17 = unk_84030;
  val4 = fread(param1,1,0x400,param1);
  if (val4 != 0) {
    val6 = 0;
    val14 = 0x67452301;
    val17 = 0xefcdab89;
    val15 = 0x98badcfe;
    val16 = 0x10325476;
    do {
      val5 = 0;
      val8 = (uint32_t)val6 & 0x3f;
      do {
        val12 = val8 + 1;
        *(uint8_t *)((int8_t)&xStack_110 + (uint8_t)val8) = *(uint8_t *)((int8_t)param1 + val5);
        val8 = val12;
        if ((val12 & 0x3f) == 0) {
          val7 = 0;
          val9 = 0;
          val11 = 1;
          Var2 = ((int)((char)((uint8_t)xStack_f0 >> 0x20)) << 16 | (unsigned short)((int16_t)xStack_f0)) & 0xff00ff;
          val10 = 5;
          xStack_c8 = ((long long)((char)((uint8_t)xStack_f0 >> 0x38)) << 56 | (unsigned long long)(
                               CONCAT16((char)((uint8_t)xStack_f0 >> 0x30),
                                        CONCAT15((char)((uint8_t)xStack_f0 >> 0x28),
                                                 CONCAT14((char)(Var2 >> 0x10),
                                                          CONCAT13((char)((uint8_t)xStack_f0 >> 0x18),
                                                                   CONCAT12((char)((uint;
          xStack_c8 = xStack_e0;
          val8 = val14;
          val12 = val17;
          val2 = val15;
          val3 = val16;
          do {
            val1 = val3;
            val3 = val2;
            val2 = val12;
            val12 = (uint32_t)(val9 >> 4) & 0xfffffff;
            if (val12 == 2) {
              val12 = val3 ^ val1 ^ val2;
              val13 = val10 & 0xf;
            }
            else if (val12 == 1) {
              val12 = val2 & val1 | val3 & (val1 ^ 0xffffffff);
              val13 = val11 & 0xf;
            }
            else if ((val9 >> 4 & 0xfffffff) == 0) {
              val12 = val1 & (val2 ^ 0xffffffff) | val2 & val3;
              val13 = val9;
            }
            else {
              val12 = (val2 | val1 ^ 0xffffffff) ^ val3;
              val13 = val7 & 0xf;
            }
            val13 = val9 * 4;
            val9 = val9 + 1;
            val8 = val12 + val8 + *(int32_t *)(val13 + 0x84d68) +
                     *(int32_t *)((int8_t)&xStack_c0 + (uVar17 & 0xffffffff) * 4);
            val12 = 0x20U - *(int32_t *)(val13 + 0x84e68) & 0x1f;
            val7 = val7 + 7;
            val11 = val11 + 5;
            val12 = (val8 >> val12 | val8 << 0x20 - val12) + val2;
            val10 = val10 + 3;
            val8 = val1;
          } while (val9 != 0x40);
          val8 = 0;
          val14 = val1 + val14;
          val17 = val12 + val17;
          val15 = val2 + val15;
          val16 = val3 + val16;
        }
        val5 = (uint8_t)((int32_t)val5 + 1);
      } while (val5 < val4);
      val6 = val6 + val4;
      val4 = fread(param1,1,0x400,param1);
    } while (val4 != 0);
    val17 = ((long long)(val17) << 32 | (unsigned int)(val14));
    xStack_110 = ((long long)(val16) << 32 | (unsigned int)(val15));
    val17 = val6;
  }
  _Z11md5FinalizeP10MD5Context(&iStack_128);
  free(param1);
  param2[1] = xStack_c8;
  *param2 = xStack_d0;

  __stack_chk_fail();
}