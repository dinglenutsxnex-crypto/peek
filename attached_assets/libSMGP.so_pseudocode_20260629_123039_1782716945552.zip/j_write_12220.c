// thunk -> external import
void j_write(void) {
    write();
}
