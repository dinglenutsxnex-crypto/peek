uint64_t sub_29424(void)

{
  uint64_t *param1;
  
  *param1 = 0xbd350;
  sub_6F954();
}