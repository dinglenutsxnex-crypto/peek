// thunk -> external import
void j_fputc(void) {
    fputc();
}
