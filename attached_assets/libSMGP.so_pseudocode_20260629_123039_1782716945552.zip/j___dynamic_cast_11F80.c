// thunk -> external import
void j___dynamic_cast(void) {
    __dynamic_cast();
}
