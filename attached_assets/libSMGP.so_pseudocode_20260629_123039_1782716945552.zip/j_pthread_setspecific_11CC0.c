// thunk -> external import
void j_pthread_setspecific(void) {
    pthread_setspecific();
}
