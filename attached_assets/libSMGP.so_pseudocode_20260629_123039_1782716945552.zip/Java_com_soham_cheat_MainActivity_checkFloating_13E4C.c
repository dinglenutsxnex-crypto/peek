void Java_com_soham_cheat_MainActivity_checkFloating
               (uint64_t env,uint64_t thiz,uint64_t param_3)

{
  _Z21CheckFloatingPermisonP7_JNIEnvP8_jobject(env,param_3);
  return;
}