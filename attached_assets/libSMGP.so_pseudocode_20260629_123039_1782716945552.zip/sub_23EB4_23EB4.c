uint8_t * sub_23EB4(void)

{
  uint64_t *param1;
  uint8_t *pxVar1;
  
  sub_1FF5C(param1 + 2);
  param1[0x1d] = 0;
  *(uint32_t *)(param1 + 0x1e) = 0;
  *(uint8_t *)((int8_t)param1 + 0xf4) = 0;
  param1[0x1f] = 0;
  param1[0x20] = 0;
  param1[0x21] = 0;
  param1[0x22] = 0;
  *param1 = 0xba698;
  param1[1] = 0;
  param1[2] = 0xba6c0;
  pxVar1 = sub_1FAE8();
  return pxVar1;
}