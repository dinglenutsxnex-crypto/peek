uint64_t _ZN10__cxxabiv111__terminateEPFvvE(void)

{
  code *param1;
  void *param1;

  int8_t ret1;

  (*param1)();
  abort();
  __cxa_begin_catch(param1);
  abort();
  __cxa_end_catch();
  if (ret1 != -1) {
    sub_81F98(ret0);
  }
  __cxa_call_unexpected();
}