// thunk -> external import
void j_ioctl(void) {
    ioctl();
}
