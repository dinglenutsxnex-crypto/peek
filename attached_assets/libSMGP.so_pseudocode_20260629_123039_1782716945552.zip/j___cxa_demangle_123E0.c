// thunk -> external import
void j___cxa_demangle(void) {
    __cxa_demangle();
}
