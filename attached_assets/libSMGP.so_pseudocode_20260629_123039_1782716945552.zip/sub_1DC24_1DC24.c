uint64_t sub_1DC24(void)

{
  int8_t *param1;
  
  *param1 = 0xbcc00;
  sub_6F8D4(param1 + 2);
  *param1 = unk_bffc0 + 0x10;
}