// thunk -> external import
void j__Z15executeCommand3RKSsS0_S0_S0_(void) {
    _Z15executeCommand3RKSsS0_S0_S0_();
}
