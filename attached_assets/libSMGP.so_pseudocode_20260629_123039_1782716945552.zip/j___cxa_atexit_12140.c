// thunk -> external import
void j___cxa_atexit(void) {
    __cxa_atexit();
}
