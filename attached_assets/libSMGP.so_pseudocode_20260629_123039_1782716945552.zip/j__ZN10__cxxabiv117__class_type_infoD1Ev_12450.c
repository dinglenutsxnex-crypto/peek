// thunk -> external import
void j__ZN10__cxxabiv117__class_type_infoD1Ev(void) {
    _ZN10__cxxabiv117__class_type_infoD1Ev();
}
