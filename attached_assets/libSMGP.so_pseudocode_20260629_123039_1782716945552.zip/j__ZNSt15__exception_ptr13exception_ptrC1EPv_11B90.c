// thunk -> external import
void j__ZNSt15__exception_ptr13exception_ptrC1EPv(void) {
    _ZNSt15__exception_ptr13exception_ptrC1EPv();
}
