uint64_t sub_1E1D8(void)

{
  uint64_t *param1;
  uint64_t ret;
  int8_t param3;
  uint8_t axStack_8 [8];
  
  *(uint32_t *)(param1 + 1) = (uint32_t)(param3 != 0);
  *param1 = 0xbcc00;
  ret = sub_6F8DC(axStack_8);
  *(uint8_t *)(param1 + 3) = 0;
  param1[2] = ret;
  ret = sub_1EBCC();
  return ret;
}