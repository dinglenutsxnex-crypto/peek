// thunk -> external import
void j_perror(void) {
    perror();
}
