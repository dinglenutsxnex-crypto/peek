uint64_t sub_28ED4(void)

{
  uint64_t *param1;
  uint64_t ret0;
  
  *param1 = 0xba8d0;
  sub_3CBC4();
  _ZdlPv(param1);
  return ret0;
}