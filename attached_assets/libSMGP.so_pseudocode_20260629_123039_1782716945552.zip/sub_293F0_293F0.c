uint64_t sub_293F0(void)

{
  sub_29378();
}