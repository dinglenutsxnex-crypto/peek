uint8_t sub_1D3F0(void)

{
  int32_t val;
  int8_t param1;
  char *param1;
  int8_t param2;
  
  param1 = *(char **)(param1 + 8);
  if (param1 == *(char **)(param2 + 8)) {
    return 1;
  }
  if (*param1 != '*') {
    val = strcmp(param1,*(char **)(param2 + 8));
    return (uint8_t)(val == 0);
  }
  return 0;
}