uint64_t sub_1F1C0(void)

{
  uint64_t *param1;
  
  sub_1FF5C();
  param1[0x1b] = 0;
  *(uint8_t *)(param1 + 0x1c) = 0;
  *param1 = 0xba5c0;
  *(uint8_t *)((int8_t)param1 + 0xe1) = 0;
  param1[0x1d] = 0;
  param1[0x1e] = 0;
  param1[0x1f] = 0;
  param1[0x20] = 0;
  return 0xba5c0;
}