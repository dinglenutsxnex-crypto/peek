uint64_t sub_1ECA4(void)

{
  uint64_t *param1;
  uint64_t ret0;
  
  *param1 = 0xba5c0;
  sub_202FC();
  _ZdlPv(param1);
  return ret0;
}