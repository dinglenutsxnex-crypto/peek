// thunk -> external import
void j_setlocale(void) {
    setlocale();
}
