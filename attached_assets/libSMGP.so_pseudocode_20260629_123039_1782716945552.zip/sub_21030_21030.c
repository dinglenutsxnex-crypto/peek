void sub_21030(uint64_t param_1,code *param_2)

{
  (*param_2)();
  return;
}