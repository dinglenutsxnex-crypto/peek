uint64_t sub_1291C(void)

{
  __cxa_atexit((void *)0x67cc4,(void *)0xc0138,(void *)0xc0000);
}