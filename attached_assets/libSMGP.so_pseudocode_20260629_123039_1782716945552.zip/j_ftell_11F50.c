// thunk -> external import
void j_ftell(void) {
    ftell();
}
