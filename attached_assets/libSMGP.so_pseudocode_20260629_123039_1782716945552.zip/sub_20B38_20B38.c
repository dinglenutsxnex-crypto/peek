uint8_t sub_20B38(void)

{
  int8_t val1;
  uint8_t val2;
  uint8_t *puVar3;
  uint8_t param1;

  uint8_t axStack_8 [8];

  puVar3 = unk_bff60;
  val2 = *unk_bff60;
  if (val2 <= param1) {
    return (uint8_t)(uint32_t)val2;
  }
  sub_203B4();
  *puVar3 = param1;
  val1 = unk_bfc70 + 0x10;
  param1 = unk_bfc60 + 7;
  *unk_bfc60 = val1;
  sub_3A188(piVar4);
  param1 = unk_bf9e0 + 7;
  *unk_bf9e0 = val1;
  sub_3A188(piVar4);
  param1 = unk_bfeb8 + 7;
  *unk_bfeb8 = val1;
  sub_3A188(piVar4);
  val1 = unk_bfd08 + 0x10;
  param1 = unk_bfb50 + 7;
  *unk_bfb50 = val1;
  sub_3A188(piVar4);
  param1 = unk_bfbd8 + 7;
  *unk_bfbd8 = val1;
  sub_3A188(piVar4);
  param1 = unk_bfbb0 + 7;
  *unk_bfbb0 = val1;
  sub_3A188(piVar4);
  sub_703AC(unk_bfa40,__sF + 0x98,0x10,0x400);
  sub_703AC(unk_bfc10,__sF,8,0x400);
  sub_703AC(unk_bfb20,__sF + 0x130,0x10,0x400);
  sub_1EF9C();
  sub_1EF9C();
  sub_1EF9C();
  sub_1EF9C();
  sub_70600(unk_bfbf8,__sF + 0x98,0x10,0x400);
  sub_70600(unk_bfd90,__sF,8,0x400);
  sub_70600(unk_bffa8,__sF + 0x130,0x10,0x400);
  sub_1F948();
  sub_1F948();
  sub_1F948();
  sub_1F948();
  sub_20A8C(axStack_8);
  return (uint8_t)(uint32_t)val2;
}