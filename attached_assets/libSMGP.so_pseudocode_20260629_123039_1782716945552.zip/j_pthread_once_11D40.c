// thunk -> external import
void j_pthread_once(void) {
    pthread_once();
}
