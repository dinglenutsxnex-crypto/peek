// thunk -> external import
void j__ZN10__cxxabiv112__unexpectedEPFvvE(void) {
    _ZN10__cxxabiv112__unexpectedEPFvvE();
}
