// thunk -> external import
void j_fileno(void) {
    fileno();
}
