// thunk -> external import
void j_wcrtomb(void) {
    wcrtomb();
}
