uint64_t _Z11md5FinalizeP10MD5Context(void)

{
  uint32_t val1;
  uint32_t val2;
  uint32_t val3;
  uint32_t val4;

  unkuint3 Var6;
  uint8_t *param1;

  uint32_t val5;
  int8_t val6;
  uint8_t val7;
  int32_t val8;
  uint8_t val9;
  uint8_t *pxVar13;
  uint8_t val10;
  uint64_t xStack_90;

  val8 = 0x38;
  val5 = (uint32_t)*param1 & 0x3f;
  if (0x37 < val5) {
    val8 = 0x78;
  }
  val9 = (uint8_t)(val8 - val5);
  val7 = *param1 + val9;
  *param1 = val7;
  if (val8 - val5 != 0) {
    pxVar13 = (uint8_t *)0x84d28;
    val7 = val9;
    do {
      val1 = val5 + 1;
      *(uint8_t *)((int8_t)param1 + (uint8_t)val5 + 0x18) = *pxVar13;
      val5 = val1;
      if ((val1 & 0x3f) == 0) {
        xStack_90 = param1[4];
        val10 = param1[3];
        Var6 = ((int)((char)(val10 >> 0x20)) << 16 | (unsigned short)((int16_t)val10)) & 0xff00ff;
        xStack_90 = ((long long)((char)(val10 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)(val10 >> 0x30),
                                      CONCAT15((char)(val10 >> 0x28),
                                               CONCAT14((char)(Var6 >> 0x10),
                                                        CONCAT13((char)(val10 >> 0x18),
                                                                 CONCAT12((char)(val10 >> 0x10),
                                              ;
        xStack_90 = param1[6];
        val10 = param1[5];
        Var6 = ((int)((char)(val10 >> 0x20)) << 16 | (unsigned short)((int16_t)val10)) & 0xff00ff;
        xStack_90 = ((long long)((char)(val10 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)(val10 >> 0x30),
                                      CONCAT15((char)(val10 >> 0x28),
                                               CONCAT14((char)(Var6 >> 0x10),
                                                        CONCAT13((char)(val10 >> 0x18),
                                                                 CONCAT12((char)(val10 >> 0x10),
                                              ;
        xStack_90 = param1[8];
        val10 = param1[7];
        Var6 = ((int)((char)(val10 >> 0x20)) << 16 | (unsigned short)((int16_t)val10)) & 0xff00ff;
        xStack_90 = ((long long)((char)(val10 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)(val10 >> 0x30),
                                      CONCAT15((char)(val10 >> 0x28),
                                               CONCAT14((char)(Var6 >> 0x10),
                                                        CONCAT13((char)(val10 >> 0x18),
                                                                 CONCAT12((char)(val10 >> 0x10),
                                              ;
        xStack_90 = param1[10];
        val10 = param1[9];
        Var6 = ((int)((char)(val10 >> 0x20)) << 16 | (unsigned short)((int16_t)val10)) & 0xff00ff;
        xStack_90 = ((long long)((char)(val10 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)(val10 >> 0x30),
                                      CONCAT15((char)(val10 >> 0x28),
                                               CONCAT14((char)(Var6 >> 0x10),
                                                        CONCAT13((char)(val10 >> 0x18),
                                                                 CONCAT12((char)(val10 >> 0x10),
                                              ;
        _Z7md5StepPjS_(param1 + 1,&xStack_90);
        val5 = 0;
      }
      val7 = val7 - 1;
      pxVar13 = pxVar13 + 1;
    } while (val7 != 0);
    val7 = *param1;
  }
  val7 = val7 - val9;
  val6 = 0;
  *param1 = val7;
  do {
    *(uint32_t *)((int8_t)&xStack_90 + val6) = *(uint32_t *)((int8_t)param1 + val6 + 0x18);
    val6 = val6 + 4;
  } while (val6 != 0x38);
  xStack_90 = ((long long)((int32_t)(val7 >> 0x1d)) << 32 | (unsigned int)((int32_t)val7 << 3));
  param1 = _Z7md5StepPjS_(param1 + 1,&xStack_90);
  val2 = (uint32_t)param1[1];
  val3 = *(uint32_t *)((int8_t)param1 + 0xc);
  *(char *)(param1 + 0xb) = (char)val2;
  *(char *)((int8_t)param1 + 0x59) = (char)((uint32_t)val2 >> 8);
  *(char *)((int8_t)param1 + 0x5a) = (char)((uint32_t)val2 >> 0x10);
  *(char *)((int8_t)param1 + 0x5b) = (char)((uint32_t)val2 >> 0x18);
  *(char *)((int8_t)param1 + 0x5d) = (char)((uint32_t)val3 >> 8);
  *(char *)((int8_t)param1 + 0x5e) = (char)((uint32_t)val3 >> 0x10);
  val2 = (uint32_t)param1[2];
  val4 = *(uint32_t *)((int8_t)param1 + 0x14);
  *(char *)((int8_t)param1 + 0x5c) = (char)val3;
  *(char *)((int8_t)param1 + 0x5f) = (char)((uint32_t)val3 >> 0x18);
  *(char *)((int8_t)param1 + 0x61) = (char)((uint32_t)val2 >> 8);
  *(char *)(param1 + 0xc) = (char)val2;
  *(char *)((int8_t)param1 + 99) = (char)((uint32_t)val2 >> 0x18);
  *(char *)((int8_t)param1 + 0x62) = (char)((uint32_t)val2 >> 0x10);
  *(char *)((int8_t)param1 + 0x65) = (char)((uint32_t)val4 >> 8);
  *(char *)((int8_t)param1 + 100) = (char)val4;
  *(char *)((int8_t)param1 + 0x66) = (char)((uint32_t)val4 >> 0x10);
  *(char *)((int8_t)param1 + 0x67) = (char)((uint32_t)val4 >> 0x18);

  __stack_chk_fail();
}