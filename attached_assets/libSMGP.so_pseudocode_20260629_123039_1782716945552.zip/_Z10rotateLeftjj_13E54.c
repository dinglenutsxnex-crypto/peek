uint8_t _Z10rotateLeftjj(void)

{
  uint32_t val;
  uint32_t param1;
  int32_t param2;
  
  val = 0x20U - param2 & 0x1f;
  return (uint8_t)(param1 >> val | param1 << 0x20 - val);
}