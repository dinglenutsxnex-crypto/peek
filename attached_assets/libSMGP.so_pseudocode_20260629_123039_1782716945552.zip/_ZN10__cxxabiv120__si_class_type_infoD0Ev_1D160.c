uint64_t _ZN10__cxxabiv120__si_class_type_infoD0Ev(void)

{
  void *param1;
  uint64_t ret0;
  
  _ZN10__cxxabiv120__si_class_type_infoD1Ev();
  _ZdlPv(param1);
  return ret0;
}