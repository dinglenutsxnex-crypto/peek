uint8_t sub_1F0E8(void)

{
  uint8_t val1;
  int8_t param1;
  uint8_t ret;
  uint8_t param2;
  uint8_t param3;
  int8_t *env;
  
  env = *(int8_t **)(param1 + 0xf0);
  if (env == (int8_t *)0x0) {
    sub_61E30();
  }
  val1 = *(uint8_t *)((int8_t)env + (int8_t)(int32_t)(uint32_t)param2 + 0x139);
  ret = (uint8_t)val1;
  if (val1 == 0) {
    val1 = (*env)->FromReflectedField(env,param2,param3);
    if ((uint32_t)param3 != (uint32_t)val1) {
      *(uint8_t *)((int8_t)env + (int8_t)(int32_t)(uint32_t)param2 + 0x139) = val1;
      return (uint8_t)(uint32_t)val1;
    }
    ret = (uint8_t)(uint32_t)param3;
  }
  return ret;
}