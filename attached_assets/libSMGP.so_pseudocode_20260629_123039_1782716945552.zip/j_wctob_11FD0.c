// thunk -> external import
void j_wctob(void) {
    wctob();
}
