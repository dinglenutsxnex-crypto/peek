// thunk -> external import
void j__ZNSt9bad_allocD2Ev(void) {
    _ZNSt9bad_allocD2Ev();
}
