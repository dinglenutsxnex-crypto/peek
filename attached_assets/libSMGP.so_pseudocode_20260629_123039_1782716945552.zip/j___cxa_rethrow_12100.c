// thunk -> external import
void j___cxa_rethrow(void) {
    __cxa_rethrow();
}
