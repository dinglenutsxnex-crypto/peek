// thunk -> external import
void j___cxa_free_exception(void) {
    __cxa_free_exception();
}
