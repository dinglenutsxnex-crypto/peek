uint64_t sub_1F988(void)

{
  int8_t param1;
  int8_t *env;
  jclass cls;
  
  if (*(char *)(param1 + 0xe4) != '\0') {
    return (uint8_t)*(uint32_t *)(param1 + 0xe0);
  }
  env = *(int8_t **)(param1 + 0xf0);
  if (env != (int8_t *)0x0) {
    cls = (*env)->GetSuperclass(env,0x20);
    *(int32_t *)(param1 + 0xe0) = (int32_t)cls;
    *(uint8_t *)(param1 + 0xe4) = 1;
    jclass cls;
  }
  sub_61E30();
}