// thunk -> external import
void j__ZSt18uncaught_exceptionv(void) {
    _ZSt18uncaught_exceptionv();
}
