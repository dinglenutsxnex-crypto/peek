// thunk -> external import
void j_strcoll(void) {
    strcoll();
}
