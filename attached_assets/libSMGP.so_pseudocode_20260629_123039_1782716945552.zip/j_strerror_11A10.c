// thunk -> external import
void j_strerror(void) {
    strerror();
}
