// thunk -> external import
void j_exit(void) {
    exit();
}
