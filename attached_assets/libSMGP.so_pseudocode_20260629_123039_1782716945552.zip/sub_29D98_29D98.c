void sub_29D98(int8_t *env)

{
  (*env)->GetSuperclass();
  return;
}