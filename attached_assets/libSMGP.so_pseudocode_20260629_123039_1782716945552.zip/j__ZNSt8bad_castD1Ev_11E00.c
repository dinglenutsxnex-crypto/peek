// thunk -> external import
void j__ZNSt8bad_castD1Ev(void) {
    _ZNSt8bad_castD1Ev();
}
