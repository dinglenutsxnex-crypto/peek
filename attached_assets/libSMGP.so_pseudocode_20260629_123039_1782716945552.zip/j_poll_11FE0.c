// thunk -> external import
void j_poll(void) {
    poll();
}
