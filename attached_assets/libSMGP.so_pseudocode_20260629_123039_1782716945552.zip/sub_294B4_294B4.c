uint64_t sub_294B4(void)

{
  int8_t *env;
  jclass cls;
  
  sub_1DFC0();
  cls = (*env)->FindClass();
  jclass cls;
}