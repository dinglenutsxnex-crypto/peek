void _ZSt10unexpectedv(void)

{
  _ZSt14get_unexpectedv();
  _ZN10__cxxabiv112__unexpectedEPFvvE();
}