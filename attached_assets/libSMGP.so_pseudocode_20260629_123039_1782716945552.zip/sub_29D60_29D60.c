void sub_29D60(int8_t *env)

{
  (*env)->FromReflectedField();
  return;
}