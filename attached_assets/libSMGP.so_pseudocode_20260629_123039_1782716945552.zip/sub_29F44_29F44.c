uint64_t sub_29F44(void)

{

  uint64_t ret_ptr;

  (*env)->FindClass();
  return ret_ptr;
}