uint8_t sub_299F8(void)

{
  int32_t val1;
  uint32_t val2;
  char *param1;
  uint8_t val3;
  void *param1_00;
  char *param2;
  char *param4;
  uint8_t *pxStack_e0;

  uint8_t axStack_20 [32];

  param1 = (char *)setlocale(1,0);
  pxStack_e0 = (uint8_t *)x8_reg;
  pxStack_e0 = (uint8_t *)x8_reg;
  if ((param1 != (char *)0x0) && (val1 = strcmp(param1,(char *)"nu.version_r"), val1 != 0)) {
    val3 = strlen(param1);
    param1_00 = _Znam(val3 + 1);
    memcpy(param1_00,param1,val3 + 1);
    setlocale(1,"nu.version_r");
    pxStack_e0 = 0xffffff80ffffffe0;
    val2 = vsprintf(param2,param4,&pxStack_e0);
    setlocale(1,param1_00);
    _ZdaPv(param1_00);
    return (uint8_t)val2;
  }
  pxStack_e0 = 0xffffff80ffffffe0;
  val2 = vsprintf(param2,param4,&pxStack_e0);
  return (uint8_t)val2;
}