uint64_t sub_29378(void)

{
  uint64_t *param1;
  void *pvVar1;
  void *param1;
  
  param1 = (void *)param1[4];
  *param1 = 0xba8b0;
  pvVar1 = (void *)sub_39F3C();
  if ((param1 != pvVar1) && (param1 != (void *)0x0)) {
    _ZdaPv(param1);
  }
  if ((int8_t *)param1[2] != (int8_t *)0x0) {
    (**(code **)(*(int8_t *)param1[2] + 8))();
  }
  sub_6F8D4(param1 + 3);
}