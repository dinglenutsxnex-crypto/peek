uint64_t _ZSt14get_unexpectedv(void)

{
  return *_ZN10__cxxabiv120__unexpected_handlerE;
}