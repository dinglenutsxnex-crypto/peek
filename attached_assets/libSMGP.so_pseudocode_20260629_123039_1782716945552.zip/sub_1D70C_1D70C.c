uint64_t sub_1D70C(void)

{
  int8_t *param1;
  char *param2;
  void *pvVar1;
  char *param2;
  uint32_t param3;
  
  param2 = (char *)sub_1D440(param3);
  if ((param2 != (char *)0x0) && (*param1 == 0)) {
    pvVar1 = fopen(param2,param2);
    *param1 = (int8_t)pvVar1;
    if (pvVar1 != (void *)0x0) {
      *(uint8_t *)(param1 + 1) = 1;
      return param1;
    }
  }
  return 0;
}