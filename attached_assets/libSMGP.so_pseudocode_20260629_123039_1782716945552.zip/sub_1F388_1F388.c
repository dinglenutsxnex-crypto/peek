uint64_t sub_1F388(void)

{
  int8_t param1;
  uint64_t ret_ptr;
  int8_t *piVar1;
  uint8_t axStack_8 [8];
  
  sub_3989C();
  sub_20DCC(axStack_8);
  sub_3A188(axStack_8);
  sub_1F2DC();
  piVar1 = *(int8_t **)(param1 + 0xe8);
  if (piVar1 != (int8_t *)0x0) {
    sub_3989C(axStack_8,piVar1 + 7);
    (**(code **)(*piVar1 + 0x10))(piVar1);
    sub_3A0E8(piVar1 + 7);
    sub_3A188(axStack_8);
  }
  return ret_ptr;
}