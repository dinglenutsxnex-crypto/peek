// thunk -> external import
void j_wctype(void) {
    wctype();
}
