uint8_t sub_1FAE8(void)

{
  int8_t val1;
  char cVar2;
  int8_t param1;
  uint64_t val2;
  int8_t param2;
  
  val1 = param1 + 0xd0;
  sub_20D7C();
  cVar2 = sub_4E19C(val1);
  if (cVar2 == '\0') {
    *(uint64_t *)(param1 + 0xf0) = 0;
    cVar2 = sub_4E34C(val1);
  }
  else {
    val2 = sub_4C214(val1);
    *(uint64_t *)(param1 + 0xf0) = val2;
    cVar2 = sub_4E34C(val1);
  }
  if (cVar2 == '\0') {
    *(uint64_t *)(param1 + 0xf8) = 0;
    cVar2 = sub_4E3B8(val1);
  }
  else {
    val2 = sub_4CF28(val1);
    *(uint64_t *)(param1 + 0xf8) = val2;
    cVar2 = sub_4E3B8(val1);
  }
  if (cVar2 == '\0') {
    *(uint64_t *)(param1 + 0x100) = 0;
  }
  else {
    val2 = sub_4CF90(val1);
    *(uint64_t *)(param1 + 0x100) = val2;
  }
  *(int8_t *)(param1 + 0xe8) = param2;
  *(uint32_t *)(param1 + 0xe0) = 0;
  *(uint8_t *)(param1 + 0xe4) = 0;
  *(uint64_t *)(param1 + 0xd8) = 0;
  *(uint32_t *)(param1 + 0x1c) = 0;
  *(uint32_t *)(param1 + 0x20) = (uint32_t)(param2 == 0);
  return (uint8_t)(param2 == 0);
}