uint8_t sub_1E9D4(void)

{
  char cVar1;
  int8_t *param1;
  uint8_t param3;
  uint8_t param4;
  
  if (param3 < param4) {
    while (cVar1 = (**(code **)(*param1 + 0x10))(), cVar1 != '\0') {
      param3 = param3 + 4;
      if (param4 <= param3) {
        return param3;
      }
    }
  }
  return param3;
}