uint64_t sub_28DD0(void)

{
  uint64_t *param1;
  
  *param1 = 0xbab30;
  if (*(char *)((int8_t)param1 + 0x6f) != '\0') {
    if ((void *)param1[2] != (void *)0x0) {
      _ZdaPv((void *)param1[2]);
    }
    if ((void *)param1[5] != (void *)0x0) {
      _ZdaPv((void *)param1[5]);
    }
    if ((void *)param1[7] != (void *)0x0) {
      _ZdaPv((void *)param1[7]);
    }
    if ((void *)param1[9] != (void *)0x0) {
      _ZdaPv((void *)param1[9]);
    }
  }
}