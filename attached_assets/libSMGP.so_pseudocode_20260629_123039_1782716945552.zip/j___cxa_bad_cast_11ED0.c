// thunk -> external import
void j___cxa_bad_cast(void) {
    __cxa_bad_cast();
}
