void sub_29D7C(int8_t *env)

{
  (*env)->ToReflectedMethod();
  return;
}