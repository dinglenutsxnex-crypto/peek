void * sub_1E3C8(void)

{
  int8_t val;
  int8_t *param1;
  void *pvVar2;
  int8_t param2;
  uint8_t param3;
  int8_t param4;
  
  *(uint32_t *)(param1 + 1) = (uint32_t)(param4 != 0);
  val = unk_bff40;
  param1[4] = 0;
  *(uint8_t *)(param1 + 3) = param3 & param2 != 0;
  *param1 = val + 0x10;
  param1[5] = 0;
  if (param2 == 0) {
    param2 = *_ctype_ + 1;
  }
  param1[6] = param2;
  memset((void *)((int8_t)param1 + 0x39),0,0x100);
  *(uint8_t *)(param1 + 7) = 0;
  pvVar2 = memset((void *)((int8_t)param1 + 0x139),0,0x100);
  *(uint8_t *)((int8_t)param1 + 0x239) = 0;
  return pvVar2;
}