// thunk -> external import
void j__ZNKSt15__exception_ptr13exception_ptr6_M_getEv(void) {
    _ZNKSt15__exception_ptr13exception_ptr6_M_getEv();
}
