// thunk -> external import
void j__Z11md5FinalizeP10MD5Context(void) {
    _Z11md5FinalizeP10MD5Context();
}
