// thunk -> external import
void j_sscanf(void) {
    sscanf();
}
