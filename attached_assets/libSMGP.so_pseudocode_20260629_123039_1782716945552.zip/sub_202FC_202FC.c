uint64_t sub_202FC(void)

{
  uint64_t *param1;
  uint64_t *param1;
  
  *param1 = 0xba600;
  sub_20210();
  sub_20278();
  param1 = (uint64_t *)param1[0x19];
  if (param1 != param1 + 8) {
    if (param1 != (uint64_t *)0x0) {
      _ZdaPv(param1);
    }
    param1[0x19] = 0;
  }
}