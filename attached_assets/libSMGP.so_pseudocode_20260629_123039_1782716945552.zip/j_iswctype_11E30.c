// thunk -> external import
void j_iswctype(void) {
    iswctype();
}
