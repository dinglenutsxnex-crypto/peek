// thunk -> external import
void j_sprintf(void) {
    sprintf();
}
