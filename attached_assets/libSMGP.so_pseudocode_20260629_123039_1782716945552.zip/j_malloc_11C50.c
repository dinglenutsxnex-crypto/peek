// thunk -> external import
void j_malloc(void) {
    malloc();
}
