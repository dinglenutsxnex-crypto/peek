uint64_t sub_29CB0(void)

{

  uint64_t ret_ptr;

  (*env)->GetVersion();
  return ret_ptr;
}