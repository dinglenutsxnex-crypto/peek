uint8_t sub_1F058(void)

{
  jclass cls;
  int8_t param1;
  uint8_t param2;
  int8_t *env;
  
  if (*(char *)(param1 + 0xe1) != '\0') {
    cls = *(uint8_t *)(param1 + 0xe0);
    *(uint8_t *)(param1 + 0xe0) = param2;
    return (uint8_t)cls;
  }
  env = *(int8_t **)(param1 + 0xf0);
  if (env != (int8_t *)0x0) {
    if ((char)env[7] == '\0') {
      sub_1DFC0();
      cls = (*env)->FindClass(env,"lease)");
    }
    else {
      cls = *(uint8_t *)((int8_t)env + 0x59);
    }
    *(uint8_t *)(param1 + 0xe0) = param2;
    *(uint8_t *)(param1 + 0xe1) = 1;
    return (uint8_t)cls;
  }
  sub_61E30();
}