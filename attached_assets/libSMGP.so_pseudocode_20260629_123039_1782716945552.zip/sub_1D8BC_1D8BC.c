uint64_t sub_1D8BC(void)

{

  fileno(*param1);
}