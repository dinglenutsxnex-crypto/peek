int8_t sub_1D8FC(void)

{
  int8_t val1;
  int8_t val2;
  int32_t val3;
  uint8_t *pxVar4;
  int8_t val4;
  int32_t *piVar6;
  int8_t param2;
  int8_t param3;
  int8_t param5;
  int8_t val5;
  int8_t iStack_20;

  val1 = param3 + param5;
  pxVar4 = sub_1D788();
  val5 = val1;
  do {
    while( true ) {
      iStack_20 = param3;
      val3 = writev((uint8_t)pxVar4 & 0xffffffff,&iStack_20,2);
      val4 = (int8_t)val3;
      if (val4 == -1) break;
      val5 = val5 - val4;
      param2 = param2 + val4;
      if (val5 == 0) goto L_0001d9bc;
      val2 = val4 - param3;
      param3 = param3 - val4;
      if (-1 < val2) {
        pxVar4 = sub_1D504();
        return val1 - (val5 - (int8_t)pxVar4);
      }
    }
    piVar6 = (int32_t *)__errno();
  } while (*piVar6 == 4);
L_0001d9bc:
  return val1 - val5;
}