int8_t * sub_260B0(void)

{
  int8_t *param1;
  int8_t *env;
  uint32_t param2;
  int8_t val;
  uint8_t axVar3 [12];
  
  val = *(int8_t *)(*param1 - 0x18);
  if (*(char *)((int8_t)param1 + val + 0xe4) != '\0') {
    *(uint32_t *)((int8_t)param1 + val + 0xe0) = param2;
    return param1;
  }
  env = *(int8_t **)((int8_t)param1 + val + 0xf0);
  if (env != (int8_t *)0x0) {
    (*env)->GetSuperclass(env,0x20);
    *(uint32_t *)((int8_t)param1 + val + 0xe0) = param2;
    *(uint8_t *)((int8_t)param1 + val + 0xe4) = 1;
    return param1;
  }
  axVar3 = sub_61E30();
  env = axVar3._0_8_;
  *(uint32_t *)((int8_t)env + *(int8_t *)(*env - 0x18) + 0x18) =
       *(uint32_t *)((int8_t)env + *(int8_t *)(*env - 0x18) + 0x18) | axVar3._8_4_;
  return env;
}