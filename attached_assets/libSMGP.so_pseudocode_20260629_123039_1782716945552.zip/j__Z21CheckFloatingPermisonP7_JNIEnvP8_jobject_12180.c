// thunk -> external import
void j__Z21CheckFloatingPermisonP7_JNIEnvP8_jobject(void) {
    _Z21CheckFloatingPermisonP7_JNIEnvP8_jobject();
}
