uint64_t Java_com_soham_cheat_MainActivity_nativePath(void)

{
  char cVar1;
  bool bVar2;

  int8_t *param1;
  uint64_t ret;
  int32_t *piVar5;
  int32_t val;
  uint8_t axStack_50 [8];
  int8_t iStack_48;
  uint8_t axStack_40 [8];




  ret = (*param1)->GetStringUTFChars();
  sub_63720(&iStack_48,ret,axStack_50);
  sub_6473C(fullLibPatch,&iStack_48);
  if (iStack_48 - 0x18 != unk_bff48) {
    piVar5 = (int32_t *)(iStack_48 - 8);
    if (pthread_create == 0) {
      val = *piVar5;
      *piVar5 = val - 1;
    }
    else {
      do {
        val = *piVar5;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar5,0x10);
        if (bVar2) {
          *piVar5 = val - 1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      sub_66F0C(iStack_48 - 0x18,axStack_40);
    }
  }
  ret = (*param1)->ReleaseStringUTFChars();



  return ret;
}