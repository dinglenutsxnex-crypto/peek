// thunk -> external import
void j_towupper(void) {
    towupper();
}
