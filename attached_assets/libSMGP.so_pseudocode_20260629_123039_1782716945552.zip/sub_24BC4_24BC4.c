uint64_t sub_24BC4(void)

{
  int8_t *param1;
  int8_t *env;
  
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xf0);
  if (env != (int8_t *)0x0) {
    (*env)->GetSuperclass(env,10);
  }
  sub_61E30();
}