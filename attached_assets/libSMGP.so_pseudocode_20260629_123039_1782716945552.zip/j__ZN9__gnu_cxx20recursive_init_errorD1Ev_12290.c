// thunk -> external import
void j__ZN9__gnu_cxx20recursive_init_errorD1Ev(void) {
    _ZN9__gnu_cxx20recursive_init_errorD1Ev();
}
