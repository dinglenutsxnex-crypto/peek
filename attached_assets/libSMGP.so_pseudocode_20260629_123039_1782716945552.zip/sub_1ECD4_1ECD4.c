uint64_t sub_1ECD4(void)

{
  uint64_t *param1;
  
  *param1 = 0xba5e0;
  sub_202FC();
}