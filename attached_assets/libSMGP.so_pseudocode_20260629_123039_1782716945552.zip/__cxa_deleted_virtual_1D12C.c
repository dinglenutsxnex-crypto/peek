uint64_t __cxa_deleted_virtual(void)

{
  write(2,(void *)"deleted virtual method called\n",0x1e);
  _ZSt9terminatev();
}