// thunk -> external import
void j__Z7md5FileP7__sFILEPh(void) {
    _Z7md5FileP7__sFILEPh();
}
