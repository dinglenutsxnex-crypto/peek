uint64_t sub_20DCC(void)

{

  uint64_t ret_ptr;

  sub_3989C();
  sub_3A0E8(param1 + 0xd0);
  sub_20210();
  return ret_ptr;
}