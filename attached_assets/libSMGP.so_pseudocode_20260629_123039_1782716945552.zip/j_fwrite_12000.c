// thunk -> external import
void j_fwrite(void) {
    fwrite();
}
