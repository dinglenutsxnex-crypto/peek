int8_t * sub_22BDC(void)

{
  int8_t *param1;
  jint result;
  int8_t *env;
  char cStack_8;
  
  sub_1ED34();
  sub_21204();
  if (((cStack_8 != '\0') && ((*(uint32_t *)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0x20) & 5) == 0)
      ) && (env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8),
           result = (*env)->GetVersion(env), result == -1)) {
    sub_1ED34();
    return param1;
  }
  return param1;
}