int8_t * sub_24C20(void)

{
  jobject obj;
  int8_t *param1;
  int32_t *piVar2;
  int8_t *param2;
  int32_t param3;
  int32_t *piVar3;
  int8_t *env;
  char cStack_8;
  
  param1[1] = 0;
  sub_24104();
  if (cStack_8 != '\0') {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
    piVar2 = (int32_t *)env[2];
    if ((int32_t *)env[3] <= piVar2) goto L_00024ce0;
L_00024c78:
    obj = *piVar2;
    if (obj != -1) {
      do {
        if (obj == param3) break;
        piVar2 = (int32_t *)param2[5];
        if (piVar2 < (int32_t *)param2[6]) {
          *piVar2 = obj;
          param2[5] = (int8_t)(piVar2 + 1);
        }
        else {
          obj = (*param2)->Throw();
          if (obj == -1) goto L_00024d04;
        }
        piVar3 = (int32_t *)env[2];
        piVar2 = (int32_t *)env[3];
        param1[1] = param1[1] + 1;
        if (piVar3 < piVar2) {
          obj = *piVar3;
          env[2] = (int8_t)(piVar3 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj != -1) {
          piVar2 = (int32_t *)env[2];
          if (piVar2 < (int32_t *)env[3]) goto L_00024c78;
L_00024ce0:
          obj = (*env)->ToReflectedMethod(env);
        }
        if (obj == -1) break;
      } while( true );
    }
    if (obj == -1) goto L_00024d10;
  }
L_00024d04:
  if (param1[1] != 0) {
    return param1;
  }
L_00024d10:
  sub_1F6E0();
  return param1;
}