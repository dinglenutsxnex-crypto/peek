// thunk -> external import
void j___cxa_current_exception_type(void) {
    __cxa_current_exception_type();
}
