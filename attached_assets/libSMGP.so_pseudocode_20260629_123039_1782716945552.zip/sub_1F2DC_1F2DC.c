uint64_t sub_1F2DC(void)

{
  char cVar1;
  int8_t param1;
  uint64_t ret;
  
  cVar1 = sub_2D0B8();
  if (cVar1 == '\0') {
    *(uint64_t *)(param1 + 0xf0) = 0;
    cVar1 = sub_2D268();
  }
  else {
    ret = sub_2B34C();
    *(uint64_t *)(param1 + 0xf0) = ret;
    cVar1 = sub_2D268();
  }
  if (cVar1 == '\0') {
    *(uint64_t *)(param1 + 0xf8) = 0;
    cVar1 = sub_2D2D4();
  }
  else {
    ret = sub_2C17C();
    *(uint64_t *)(param1 + 0xf8) = ret;
    cVar1 = sub_2D2D4();
  }
  if (cVar1 != '\0') {
    ret = sub_2C1E4();
    *(uint64_t *)(param1 + 0x100) = ret;
    return ret;
  }
  *(uint64_t *)(param1 + 0x100) = 0;
  return 0;
}