uint64_t sub_21C8C(void)

{
  int8_t *param1;
  int8_t *env;
  
  env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xf0);
  if (env == (int8_t *)0x0) {
    sub_61E30();
  }
  if ((char)env[7] != '\0') {
  }
  sub_1DFC0();
  (*env)->FindClass(env,10);
}