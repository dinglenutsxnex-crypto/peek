// thunk -> external import
void j___cxa_get_globals_fast(void) {
    __cxa_get_globals_fast();
}
