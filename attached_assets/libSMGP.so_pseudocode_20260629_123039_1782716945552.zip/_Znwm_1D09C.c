void * _Znwm(void)

{
  uint8_t param1;
  void *pvVar1;
  code *pcVar2;
  int8_t *param1;
  
  if (param1 == 0) {
    param1 = 1;
  }
  pvVar1 = malloc(param1);
  while( true ) {
    if (pvVar1 != (void *)0x0) {
      return pvVar1;
    }
    pcVar2 = (code *)_ZSt15get_new_handlerv();
    if (pcVar2 == (code *)0x0) break;
    (*pcVar2)();
    pvVar1 = malloc(param1);
  }
  param1 = __cxa_allocate_exception(8);
  *param1 = _ZTVSt9bad_alloc + 0x10;
  __cxa_throw(param1,_ZTISt9bad_alloc,_ZNSt9bad_allocD1Ev);
}