int8_t * sub_26A98(void)

{
  uint8_t *pxVar1;
  uint64_t param1;
  int8_t *piVar2;
  int8_t val1;
  int8_t *env;
  void *ret0;
  void *param1;
  uint64_t ret0_b;
  uint64_t param2;
  uint64_t val2;
  int8_t *unaff_x19;
  uint64_t unaff_x20;
  uint8_t *frame_ptr;
  uint64_t link_reg;
  uint8_t axVar6 [16];
  
  axVar6._8_8_ = param2;
  axVar6._0_8_ = param1;
  do {
    val2 = axVar6._8_8_;
    piVar2 = axVar6._0_8_;
    pxVar1 = (uint8_t *)((int8_t)x8_reg - 0x40);
    *(uint8_t **)((int8_t)x8_reg - 0x40) = frame_ptr;
    *(uint64_t *)((int8_t)x8_reg - 0x38) = link_reg;
    *(int8_t **)((int8_t)x8_reg - 0x30) = unaff_x19;
    *(uint64_t *)((int8_t)x8_reg - 0x28) = unaff_x20;
    sub_24104();
    if (*(char *)((int8_t)x8_reg - 8) == '\0') {
      return piVar2;
    }
    val1 = *piVar2;
    *(uint32_t *)((int8_t)x8_reg - 4) = 0;
    val1 = (int8_t)piVar2 + *(int8_t *)(val1 - 0x18);
    env = *(int8_t **)(val1 + 0x100);
    if (env != (int8_t *)0x0) {
      (*env)->ToReflectedMethod
                (env,*(uint64_t *)(val1 + 0xe8),JNI_ERR,0,JNI_ERR,val1,
                 (uint8_t *)((int8_t)x8_reg - 4),val2);
      goto L_00026b00;
    }
    axVar6 = sub_61E30();
    param1 = axVar6._0_8_;
    if (axVar6._8_8_ == 1) {
      __cxa_begin_catch(param1);
      piVar2 = (int8_t *)((int8_t)piVar2 + *(int8_t *)(*piVar2 - 0x18));
      *(uint32_t *)(piVar2 + 4) = *(uint32_t *)(piVar2 + 4) | 1;
      if ((*(uint32_t *)((int8_t)piVar2 + 0x1c) & 1) != 0) {
        __cxa_rethrow();
        param1 = ret0;
        goto L_00026b78;
      }
      __cxa_rethrow();
    }
    else {
L_00026b78:
      __cxa_begin_catch(param1);
      val1 = *(int8_t *)(*piVar2 - 0x18);
      *(uint32_t *)((int8_t)piVar2 + val1 + 0x20) = *(uint32_t *)((int8_t)piVar2 + val1 + 0x20) | 1;
      if ((*(uint32_t *)((int8_t)piVar2 + val1 + 0x1c) & 1) == 0) {
        __cxa_end_catch();
L_00026b00:
        if (*(int32_t *)((int8_t)x8_reg - 4) == 0) {
          return piVar2;
        }
        sub_1F6E0();
        return piVar2;
      }
    }
    __cxa_rethrow();
    *(uint64_t *)((int8_t)x8_reg - 0x18) = ret0_b;
    __cxa_end_catch();
    link_reg = 0x26bcc;
    axVar6 = sub_81F98(*(uint64_t *)((int8_t)x8_reg - 0x18));
    x8_reg = (sp *)((int8_t)x8_reg - 0x40);
    unaff_x19 = piVar2;
    unaff_x20 = val2;
    frame_ptr = pxVar1;
  } while( true );
}