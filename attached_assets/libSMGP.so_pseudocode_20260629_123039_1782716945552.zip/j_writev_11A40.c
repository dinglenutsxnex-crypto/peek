// thunk -> external import
void j_writev(void) {
    writev();
}
