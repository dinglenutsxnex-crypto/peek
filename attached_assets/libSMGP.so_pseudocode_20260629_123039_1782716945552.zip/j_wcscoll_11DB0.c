// thunk -> external import
void j_wcscoll(void) {
    wcscoll();
}
