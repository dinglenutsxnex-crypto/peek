uint64_t sub_1E818(void)

{
  uint8_t val1;
  int32_t val2;
  int8_t param1;
  uint8_t param2;
  uint32_t param3;
  uint8_t *puVar3;
  uint64_t *pxVar4;
  
  puVar3 = (uint8_t *)(param1 + 0x49c);
  pxVar4 = (uint64_t *)(param1 + 0x4b0);
  while ((val1 = *puVar3, puVar3 = puVar3 + 1, (param2 & val1) == 0 ||
         (val2 = iswctype(param3,*pxVar4), val2 == 0))) {
    pxVar4 = pxVar4 + 1;
    if (puVar3 == (uint8_t *)(param1 + 0x4ac)) {
      return 0;
    }
  }
  return 1;
}