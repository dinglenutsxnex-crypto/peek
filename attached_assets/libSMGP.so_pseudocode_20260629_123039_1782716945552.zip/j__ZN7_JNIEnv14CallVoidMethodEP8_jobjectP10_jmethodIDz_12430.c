// thunk -> external import
void j__ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz(void) {
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
}
