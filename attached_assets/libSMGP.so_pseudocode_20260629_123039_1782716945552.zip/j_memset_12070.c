// thunk -> external import
void j_memset(void) {
    memset();
}
