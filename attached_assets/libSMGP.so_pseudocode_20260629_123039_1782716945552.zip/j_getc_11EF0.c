// thunk -> external import
void j_getc(void) {
    getc();
}
