uint64_t * _Z14cleanHexStringRKSs(void)

{
  uint8_t val1;
  char cVar2;
  int8_t val2;
  uint64_t *param1;
  int8_t *ret_ptr;
  int8_t val3;
  int8_t val4;
  char *pcVar6;
  int8_t val5;
  
  val2 = unk_bff48;
  *ret_ptr = unk_bff48 + 0x18;
  pcVar6 = (char *)*param1;
  for (val5 = *(int8_t *)(pcVar6 - 0x18); val5 != 0; val5 = val5 - 1) {
    cVar2 = *pcVar6;
    if (((cVar2 != ' ') && (cVar2 != 'H')) && (cVar2 != 'h')) {
      val3 = *ret_ptr;
      val4 = *(int8_t *)(val3 - 0x18);
      val1 = val4 + 1;
      if ((*(uint8_t *)(val3 - 0x10) < val1) || (0 < *(int32_t *)(val3 - 8))) {
        param1 = (uint64_t *)sub_63BF0();
        val3 = *ret_ptr;
        val4 = *(int8_t *)(val3 - 0x18);
      }
      *(char *)(val3 + val4) = cVar2;
      val4 = *ret_ptr;
      if (val4 - 0x18 != val2) {
        *(uint32_t *)(val4 - 8) = 0;
        *(uint8_t *)(val4 - 0x18) = val1;
        *(uint8_t *)(val4 + val1) = 0;
      }
    }
    pcVar6 = pcVar6 + 1;
  }
  return param1;
}