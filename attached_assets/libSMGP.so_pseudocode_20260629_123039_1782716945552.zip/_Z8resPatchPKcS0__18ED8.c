int8_t _Z8resPatchPKcS0_(void)

{
  uint32_t val1;
  uint8_t val2;
  bool bVar3;

  jclass cls;
  char *param1;
  int8_t *env;
  uint8_t val3;
  uint8_t val4;
  int8_t val5;

  int8_t val6;
  int32_t *piVar12;
  int32_t val7;
  uint8_t axStack_448 [8];
  int8_t iStack_440;
  uint8_t axStack_438 [8];
  int8_t iStack_430;
  uint8_t axStack_428 [8];
  int8_t iStack_420;
  int8_t iStack_418;
  int8_t iStack_410;
  uint8_t axStack_408 [8];
  int8_t aiStack_400 [3];
  uint64_t xStack_3e8;

  uint8_t axStack_3c0 [8];

  int8_t iStack_3b0;
  int8_t aiStack_3a8 [17];
  char acStack_320 [16];
  uint64_t axStack_310 [8];

  uint8_t axStack_298 [32];
  int8_t aiStack_278 [4];
  uint32_t auStack_258 [10];
  uint8_t axStack_230 [48];
  uint8_t axStack_200 [136];
  uint8_t axStack_178 [264];

  sub_67090(aiStack_278,fullLibPatch);
  sub_6433C(aiStack_278,"/",1);
  strlen(param2);
  env = (int8_t *)sub_6433C(aiStack_278);
  val6 = unk_bff48;
  iStack_410 = *env;
  *env = unk_bff48 + 0x18;
  if (aiStack_278[0] - 0x18 != val6) {
    piVar12 = (int32_t *)(aiStack_278[0] - 8);
    if (pthread_create == 0) {
      val7 = *piVar12;
      *piVar12 = val7 - 1;
    }
    else {
      do {
        val7 = *piVar12;
        cls = '\x01';
        bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
        if (bVar3) {
          *piVar12 = val7 - 1;
          cls = ExclusiveMonitorsStatus();
        }
      } while (cls != '\0');
    }
    if (val7 < 1) {
      sub_66F0C(aiStack_278[0] - 0x18,aiStack_400);
    }
  }
  val3 = strtoul(param1,(void *)0x0,0x10);
  sub_5D41C(aiStack_278,&iStack_410,4);
  val4 = sub_1D778(axStack_200);
  if ((val4 & 1) != 0) {
    sub_22BDC(aiStack_278,val3,0);
    if ((*(uint8_t *)((int8_t)auStack_258 + *(int8_t *)(aiStack_278[0] - 0x18)) & 5) == 0) {
      sub_22284(aiStack_278,axStack_298,0x20);
      val1 = *(uint32_t *)((int8_t)auStack_258 + *(int8_t *)(aiStack_278[0] - 0x18));
      val5 = sub_5BEF8(aiStack_278 + 2);
      if (val5 == 0) {
        sub_1ED34((int8_t)aiStack_278 + *(int8_t *)(aiStack_278[0] - 0x18),
                        *(uint32_t *)((int8_t)auStack_258 + *(int8_t *)(aiStack_278[0] - 0x18)) | 4);
      }
      if ((val1 & 5) == 0) {
        sub_1FF5C(aiStack_3a8);
        iStack_3b0 = 0;
        aiStack_3a8[0] = unk_bfb30 + 0x10;
        aiStack_400[0] = unk_bfa38[1];
        iStack_3b0 = 0;
        *(int8_t *)((int8_t)aiStack_400 + *(int8_t *)(aiStack_400[0] - 0x18)) = unk_bfa38[2];
        sub_1F208((int8_t)aiStack_400 + *(int8_t *)(aiStack_400[0] - 0x18),0);
        aiStack_3a8[0] = "X" + 0x40;
        aiStack_400[0] = "X" + 0x18;
        aiStack_400[1] = unk_bfc70 + 0x10;
        val4 = (uint8_t)aiStack_400 | 8;
        xStack_3e8 = 0;
        iStack_3b0 = 0;
        xStack_3e8 = 0;
        aiStack_400[2] = 0;
        xStack_3e8 = 0;
        sub_3BC18();
        iStack_3b0 = val6 + 0x18;
        aiStack_400[1] = unk_bfd48 + 0x10;
        sub_1F208((int8_t)aiStack_400 + *(int8_t *)(aiStack_400[0] - 0x18),val4);
        val3 = 0;
        do {
          *(uint32_t *)((int8_t)&xStack_3e8 + *(int8_t *)(aiStack_400[0] - 0x18)) =
               *(uint32_t *)((int8_t)&xStack_3e8 + *(int8_t *)(aiStack_400[0] - 0x18)) & 0xffffffb5 | 8;
          *(uint64_t *)((int8_t)aiStack_400 + *(int8_t *)(aiStack_400[0] - 0x18) + 0x10) = 2;
          val6 = *(int8_t *)(aiStack_400[0] - 0x18);
          if (acStack_320[val6 + 1] == '\0') {
            env = *(int8_t **)((int8_t)axStack_310 + val6);
            if (env == (int8_t *)0x0) goto L_000195f0;
            if ((char)env[7] == '\0') {
              sub_1DFC0(env);
              cls = (*env)->FindClass(env,"lease)");
            }
            else {
              cls = *(char *)((int8_t)env + 0x59);
            }
            acStack_320[val6] = cls;
            acStack_320[val6 + 1] = '\x01';
          }
          val2 = axStack_298[val3];
          acStack_320[val6] = '0';
          val5 = sub_3EDF0(aiStack_400,val2);
          sub_3E580(xVar10," ",1);
          val3 = val3 + 1;
        } while (val3 < 0x20);
        sub_43AC8(&iStack_418,val4);
        sub_63720(&iStack_420,param1,axStack_428);
        sub_63720(&iStack_430,iStack_418,axStack_438);
        sub_63720(&iStack_440,param2,axStack_448);
        _Z8hexPatchRKSsS0_S0_(&iStack_420,&iStack_430,&iStack_440);
        val6 = unk_bff48;
        if (iStack_440 - 0x18 != unk_bff48) {
          piVar12 = (int32_t *)(iStack_440 - 8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 - 1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 - 1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            sub_66F0C(iStack_440 - 0x18,axStack_408);
          }
        }
        if (iStack_430 - 0x18 != val6) {
          piVar12 = (int32_t *)(iStack_430 - 8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 - 1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 - 1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            sub_66F0C(iStack_430 - 0x18,&iStack_440);
          }
        }
        if (iStack_420 - 0x18 != val6) {
          piVar12 = (int32_t *)(iStack_420 - 8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 - 1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 - 1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            sub_66F0C(iStack_420 - 0x18,&iStack_430);
          }
        }
        if (iStack_418 - 0x18 != val6) {
          piVar12 = (int32_t *)(iStack_418 - 8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 - 1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 - 1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            sub_66F0C(iStack_418 - 0x18,&iStack_420);
          }
        }
        aiStack_400[0] = *unk_bfa38;
        *(int8_t *)((int8_t)aiStack_400 + *(int8_t *)(aiStack_400[0] - 0x18)) = unk_bfa38[3];
        aiStack_400[1] = unk_bfd48 + 0x10;
        if (iStack_3b0 - 0x18 != val6) {
          piVar12 = (int32_t *)(iStack_3b0 - 8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 - 1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 - 1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            sub_66F0C(iStack_3b0 - 0x18,&iStack_418);
          }
        }
        aiStack_400[1] = unk_bfc70 + 0x10;
        sub_3A188(axStack_3c0);
        sub_202FC(aiStack_3a8);
      }
    }
    else {
      val5 = sub_5BEF8(aiStack_278 + 2);
      if (val5 == 0) {
        sub_1ED34((int8_t)aiStack_278 + *(int8_t *)(aiStack_278[0] - 0x18),
                        *(uint32_t *)((int8_t)auStack_258 + *(int8_t *)(aiStack_278[0] - 0x18)) | 4);
      }
    }
  }
  env = unk_bff10;
  aiStack_278[0] = *unk_bff10;
  *(int8_t *)((int8_t)aiStack_278 + *(int8_t *)(aiStack_278[0] - 0x18)) = unk_bff10[3];
  aiStack_278[2] = unk_bff70 + 0x10;
  sub_5BEF8(aiStack_278 + 2);
  sub_1D58C(axStack_200);
  aiStack_278[2] = unk_bfc70 + 0x10;
  sub_3A188(axStack_230);
  aiStack_278[0] = env[1];
  *(int8_t *)((int8_t)aiStack_278 + *(int8_t *)(aiStack_278[0] - 0x18)) = env[2];
  aiStack_278[1] = 0;
  sub_202FC(axStack_178);
  val5 = iStack_410 - 0x18;
  if (val5 != val6) {
    piVar12 = (int32_t *)(iStack_410 - 8);
    if (pthread_create == 0) {
      val7 = *piVar12;
      *piVar12 = val7 - 1;
    }
    else {
      do {
        val7 = *piVar12;
        cls = '\x01';
        bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
        if (bVar3) {
          *piVar12 = val7 - 1;
          cls = ExclusiveMonitorsStatus();
        }
      } while (cls != '\0');
    }
    if (val7 < 1) {
      val5 = sub_66F0C(val5,aiStack_278);
    }
  }

  __stack_chk_fail();
L_000195f0:
  sub_61E30();
}