void sub_29DB4(uint64_t *param_1,int8_t param_2)

{
  *(uint32_t *)(param_1 + 1) = (uint32_t)(param_2 != 0);
  *param_1 = 0xbd1d0;
  param_1[2] = 0;
  sub_3C7F4(param_1,0,0);
  return;
}