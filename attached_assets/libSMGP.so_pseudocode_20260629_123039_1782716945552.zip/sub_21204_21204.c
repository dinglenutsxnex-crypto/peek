uint64_t sub_21204(void)

{
  jclass cls;
  jobject obj;
  uint8_t *param1;
  jobject obj2;
  uint8_t *puVar4;
  int8_t *param2;
  char param3;
  uint8_t *puVar5;
  int8_t val1;
  int8_t *env;
  int8_t val2;
  
  val1 = *(int8_t *)(*param2 - 0x18);
  *param1 = 0;
  val1 = (int8_t)param2 + val1;
  if (*(int32_t *)(val1 + 0x20) != 0) goto L_00021278;
  if (*(int8_t *)(val1 + 0xd8) == 0) {
    if (param3 != '\0') goto L_0002125c;
L_00021298:
    if ((*(uint32_t *)(val1 + 0x18) >> 0xc & 1) != 0) {
      env = *(int8_t **)(val1 + 0xe8);
      if ((uint8_t *)env[2] < (uint8_t *)env[3]) {
        val2 = *(int8_t *)(val1 + 0xf0);
        obj2 = (uint8_t)*(uint8_t *)env[2];
        if (val2 == 0) {
L_0002139c:
          sub_61E30();
        }
      }
      else {
        obj2 = (*env)->ToReflectedMethod(env);
        val1 = (int8_t)param2 + *(int8_t *)(*param2 - 0x18);
        val2 = *(int8_t *)(val1 + 0xf0);
        if (val2 == 0) goto L_0002139c;
        if ((int32_t)obj2 == -1) goto L_00021278;
      }
      if ((*(uint8_t *)(*(int8_t *)(val2 + 0x30) + (obj2 & 0xff)) >> 3 & 1) != 0) {
        do {
          puVar4 = (uint8_t *)env[3];
          if ((uint8_t *)env[2] < puVar4) {
            puVar5 = (uint8_t *)env[2] + 1;
            env[2] = (int8_t)puVar5;
          }
          else {
            cls = (*env)->GetSuperclass(env);
            if (cls == -1) goto L_00021278;
            puVar5 = (uint8_t *)env[2];
            puVar4 = (uint8_t *)env[3];
          }
          if (puVar5 < puVar4) {
            obj = (uint32_t)*puVar5;
          }
          else {
            obj = (*env)->ToReflectedMethod(env);
            if (obj == JNI_ERR) goto L_00021278;
          }
        } while ((*(uint8_t *)(*(int8_t *)(val2 + 0x30) + (uint8_t)(uint8_t)obj) >> 3 & 1) != 0);
        val1 = (int8_t)param2 + *(int8_t *)(*param2 - 0x18);
      }
    }
  }
  else {
    sub_3D868();
    val1 = (int8_t)param2 + *(int8_t *)(*param2 - 0x18);
    if (param3 == '\0') goto L_00021298;
  }
  if (*(int32_t *)(val1 + 0x20) == 0) {
L_0002125c:
    *param1 = 1;
    return 1;
  }
L_00021278:
}