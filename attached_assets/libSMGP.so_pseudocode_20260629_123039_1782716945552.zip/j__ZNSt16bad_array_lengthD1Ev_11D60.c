// thunk -> external import
void j__ZNSt16bad_array_lengthD1Ev(void) {
    _ZNSt16bad_array_lengthD1Ev();
}
