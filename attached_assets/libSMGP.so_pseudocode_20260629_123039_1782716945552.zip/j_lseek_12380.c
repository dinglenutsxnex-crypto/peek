// thunk -> external import
void j_lseek(void) {
    lseek();
}
