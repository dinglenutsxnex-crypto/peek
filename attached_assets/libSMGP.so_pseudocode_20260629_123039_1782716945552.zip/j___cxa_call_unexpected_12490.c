// thunk -> external import
void j___cxa_call_unexpected(void) {
    __cxa_call_unexpected();
}
