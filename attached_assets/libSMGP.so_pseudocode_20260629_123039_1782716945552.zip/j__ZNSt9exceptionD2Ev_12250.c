// thunk -> external import
void j__ZNSt9exceptionD2Ev(void) {
    _ZNSt9exceptionD2Ev();
}
