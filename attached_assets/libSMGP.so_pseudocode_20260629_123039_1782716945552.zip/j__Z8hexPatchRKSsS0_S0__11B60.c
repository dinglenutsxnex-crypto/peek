// thunk -> external import
void j__Z8hexPatchRKSsS0_S0_(void) {
    _Z8hexPatchRKSsS0_S0_();
}
