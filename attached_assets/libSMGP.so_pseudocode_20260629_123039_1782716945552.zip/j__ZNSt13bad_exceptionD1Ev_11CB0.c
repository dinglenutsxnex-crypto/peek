// thunk -> external import
void j__ZNSt13bad_exceptionD1Ev(void) {
    _ZNSt13bad_exceptionD1Ev();
}
