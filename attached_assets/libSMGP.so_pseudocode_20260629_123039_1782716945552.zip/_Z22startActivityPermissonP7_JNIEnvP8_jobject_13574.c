uint64_t _Z22startActivityPermissonP7_JNIEnvP8_jobject(void)

{
  int8_t val1;
  int8_t val2;
  int8_t val3;
  char cVar4;
  bool bVar5;

  int8_t *piVar7;
  int8_t val4;
  int8_t *env;
  char *env;

  uint64_t ret;
  int32_t *piVar11;
  int32_t val5;
  int8_t iStack_1f0;
  uint8_t axStack_1e8 [8];
  int8_t aiStack_1e0 [2];
  int8_t aiStack_1d0 [4];
  uint32_t auStack_1b0 [8];
  uint8_t axStack_190 [8];

  int8_t iStack_180;
  int8_t aiStack_178 [27];

  (*env)->GetObjectClass();
  (*env)->GetMethodID();
  (*env)->GetMethodID();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  env = (char *)(*env)->GetStringUTFChars();
  sub_1FF5C(aiStack_178);
  piVar7 = unk_bfc90;
  iStack_180 = 0;
  aiStack_178[0] = unk_bfb30 + 0x10;
  val1 = unk_bfc90[2];
  val2 = unk_bfc90[3];
  iStack_180 = 0;
  aiStack_1e0[0] = val1;
  *(int8_t *)((int8_t)aiStack_1e0 + *(int8_t *)(val1 - 0x18)) = val2;
  aiStack_1e0[1] = 0;
  sub_1F208((int8_t)aiStack_1e0 + *(int8_t *)(aiStack_1e0[0] - 0x18),0);
  aiStack_1d0[0] = piVar7[4];
  *(int8_t *)((int8_t)aiStack_1d0 + *(int8_t *)(aiStack_1d0[0] - 0x18)) = piVar7[5];
  sub_1F208((int8_t)aiStack_1d0 + *(int8_t *)(aiStack_1d0[0] - 0x18),0);
  *(int8_t *)((int8_t)aiStack_1e0 + *(int8_t *)(piVar7[1] - 0x18)) = piVar7[6];
  aiStack_1d0[0] = "h" + 0x40;
  auStack_1b0[4] = 0;
  auStack_1b0[5] = 0;
  auStack_1b0[6] = 0;
  auStack_1b0[7] = 0;
  aiStack_1d0[1] = unk_bfc70 + 0x10;
  aiStack_1e0[0] = "h" + 0x18;
  aiStack_178[0] = "h" + 0x68;
  auStack_1b0[0] = 0;
  auStack_1b0[1] = 0;
  auStack_1b0[2] = 0;
  auStack_1b0[3] = 0;
  aiStack_1d0[2] = 0;
  aiStack_1d0[3] = 0;
  sub_3BC18(axStack_190);
  iStack_180 = 0x18;
  aiStack_1d0[1] = unk_bfd48 + 0x10;
  iStack_180 = unk_bff48 + 0x18;
  sub_1F208((int8_t)aiStack_1e0 + *(int8_t *)(aiStack_1e0[0] - 0x18),aiStack_1d0 + 1);
  sub_3E580(aiStack_1d0,"package:",8);
  if (env == (char *)0x0) {
    sub_1ED34((int8_t)aiStack_1d0 + *(int8_t *)(aiStack_1d0[0] - 0x18),
                    *(uint32_t *)((int8_t)auStack_1b0 + *(int8_t *)(aiStack_1d0[0] - 0x18)) | 1);
  }
  else {
    env = strlen(env);
    sub_3E580(aiStack_1d0,env,uVar9);
  }
  sub_43AC8(&iStack_1f0,aiStack_1d0 + 1);
  (*env)->FindClass();
  (*env)->GetStaticMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv22CallStaticObjectMethodEP7_jclassP10_jmethodIDz();
  (*env)->FindClass();
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz();
  _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  val4 = unk_bff48;
  if (iStack_1f0 - 0x18 != unk_bff48) {
    piVar11 = (int32_t *)(iStack_1f0 - 8);
    if (pthread_create == 0) {
      val5 = *piVar11;
      *piVar11 = val5 - 1;
    }
    else {
      do {
        val5 = *piVar11;
        cVar4 = '\x01';
        bVar5 = (bool)ExclusiveMonitorPass(piVar11,0x10);
        if (bVar5) {
          *piVar11 = val5 - 1;
          cVar4 = ExclusiveMonitorsStatus();
        }
      } while (cVar4 != '\0');
    }
    if (val5 < 1) {
      sub_66F0C(iStack_1f0 - 0x18,axStack_1e8);
    }
  }
  aiStack_1e0[0] = *piVar7;
  val3 = piVar7[9];
  *(int8_t *)((int8_t)aiStack_1e0 + *(int8_t *)(aiStack_1e0[0] - 0x18)) = piVar7[8];
  aiStack_1d0[1] = unk_bfd48 + 0x10;
  aiStack_1d0[0] = val3;
  if (iStack_180 - 0x18 != val4) {
    piVar11 = (int32_t *)(iStack_180 - 8);
    if (pthread_create == 0) {
      val5 = *piVar11;
      *piVar11 = val5 - 1;
    }
    else {
      do {
        val5 = *piVar11;
        cVar4 = '\x01';
        bVar5 = (bool)ExclusiveMonitorPass(piVar11,0x10);
        if (bVar5) {
          *piVar11 = val5 - 1;
          cVar4 = ExclusiveMonitorsStatus();
        }
      } while (cVar4 != '\0');
    }
    if (val5 < 1) {
      sub_66F0C(iStack_180 - 0x18,&iStack_1f0);
    }
  }
  aiStack_1d0[1] = unk_bfc70 + 0x10;
  sub_3A188(axStack_190);
  aiStack_1e0[0] = val1;
  *(int8_t *)((int8_t)aiStack_1e0 + *(int8_t *)(val1 - 0x18)) = val2;
  aiStack_1e0[1] = 0;
  ret = sub_202FC(aiStack_178);

  return ret;
}