// thunk -> external import
void j_getwc(void) {
    getwc();
}
