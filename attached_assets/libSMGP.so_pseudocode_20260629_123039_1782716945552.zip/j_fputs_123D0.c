// thunk -> external import
void j_fputs(void) {
    fputs();
}
