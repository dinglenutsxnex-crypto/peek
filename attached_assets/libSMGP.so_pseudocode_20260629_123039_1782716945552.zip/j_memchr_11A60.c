// thunk -> external import
void j_memchr(void) {
    memchr();
}
