// detected - Rolling XOR cipher (detection may be wrong)
// detected - XOR with constant (detection may be wrong)
// detected - SHA-1 (detection may be wrong)
uint64_t _Z9md5StringPcPh(void)

{

  unkuint3 Var2;
  unkuint3 Var3;
  uint32_t val1;
  uint32_t val2;
  uint32_t val3;
  uint32_t val4;
  char *param1;

  uint64_t *param2;
  uint8_t val5;
  uint32_t val6;

  uint8_t val7;

  uint8_t val8;
  int8_t val9;
  uint32_t val10;
  uint8_t val11;
  uint8_t val12;
  uint32_t val13;
  uint32_t val14;
  uint32_t val15;
  uint32_t val16;
  uint8_t uStack_128;

  uint64_t xStack_110;
  uint64_t xStack_108;
  uint64_t xStack_100;
  uint64_t xStack_f8;
  uint64_t xStack_f0;
  uint64_t xStack_e8;
  uint64_t xStack_e0;
  uint64_t xStack_d8;
  uint64_t xStack_d0;
  uint64_t xStack_c8;

  xStack_110 = unk_84038;
  uStack_128 = strlen(param1);
  if (uStack_128 != 0) {
    val7 = 0;
    val10 = 0;
    val13 = 0x67452301;
    val14 = 0xefcdab89;
    val15 = 0x98badcfe;
    val16 = 0x10325476;
    do {
      val6 = val10 + 1;
      *(char *)((int8_t)&xStack_110 + (uint8_t)val10) = param1[val7];
      val10 = val6;
      if ((val6 & 0x3f) == 0) {
        val12 = 0;
        val5 = 0;
        val11 = 1;
        Var2 = ((int)((char)((uint8_t)xStack_f0 >> 0x20)) << 16 | (unsigned short)((int16_t)xStack_f0)) & 0xff00ff;
        Var3 = ((int)((char)((uint8_t)xStack_e0 >> 0x20)) << 16 | (unsigned short)((int16_t)xStack_e0)) & 0xff00ff;
        val8 = 5;
        xStack_c8 = ((long long)((char)((uint8_t)xStack_f0 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8_t)xStack_f0 >> 0x30),
                                      CONCAT15((char)((uint8_t)xStack_f0 >> 0x28),
                                               CONCAT14((char)(Var2 >> 0x10),
                                                        CONCAT13((char)((uint8_t)xStack_f0 >> 0x18),
                                                                 CONCAT12((char)((uint8_t)xStack;
        xStack_c8 = ((long long)((char)((uint8_t)xStack_e0 >> 0x38)) << 56 | (unsigned long long)(
                             CONCAT16((char)((uint8_t)xStack_e0 >> 0x30),
                                      CONCAT15((char)((uint8_t)xStack_e0 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8_t)xStack_e0 >> 0x18),
                                                                 CONCAT12((char)((uint8_t)xStack;
        val10 = val13;
        val3 = val16;
        val6 = val14;
        val4 = val15;
        do {
          val2 = val4;
          val4 = val6;
          val1 = val3;
          val6 = (uint32_t)(val5 >> 4) & 0xfffffff;
          if (val6 == 2) {
            val6 = val8 & 0xf;
          }
          else if (val6 == 1) {
            val6 = val4 & val1 | val2 & (val1 ^ 0xffffffff);
            val6 = val11 & 0xf;
          }
          else if ((val5 >> 4 & 0xfffffff) == 0) {
            val6 = val1 & (val4 ^ 0xffffffff) | val4 & val2;
            val6 = val5;
          }
          else {
            val6 = (val4 | val1 ^ 0xffffffff) ^ val2;
            val6 = val12 & 0xf;
          }
          val9 = val5 * 4;
          val10 = val6 + val10 + *(int32_t *)(val9 + 0x84d68) +
                   *(int32_t *)((int8_t)&xStack_c0 + (uVar11 & 0xffffffff) * 4);
          val5 = val5 + 1;
          val6 = 0x20U - *(int32_t *)(val9 + 0x84e68) & 0x1f;
          val12 = val12 + 7;
          val11 = val11 + 5;
          val6 = (val10 >> val6 | val10 << 0x20 - val6) + val4;
          val8 = val8 + 3;
          val10 = val1;
          val3 = val2;
        } while (val5 != 0x40);
        val16 = val2 + val16;
        val10 = 0;
        val13 = val1 + val13;
        val14 = val6 + val14;
        val15 = val4 + val15;
      }
      val7 = (uint8_t)((int32_t)val7 + 1);
    } while (val7 < uStack_128);
    uStack_128 = ((long long)(val14) << 32 | (unsigned int)(val13));
    xStack_110 = ((long long)(val16) << 32 | (unsigned int)(val15));
  }
  param1 = _Z11md5FinalizeP10MD5Context(&uStack_128);
  param2[1] = xStack_c8;
  *param2 = xStack_d0;

  __stack_chk_fail();
}