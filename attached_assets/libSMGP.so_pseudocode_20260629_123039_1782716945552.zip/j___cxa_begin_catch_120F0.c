// thunk -> external import
void j___cxa_begin_catch(void) {
    __cxa_begin_catch();
}
