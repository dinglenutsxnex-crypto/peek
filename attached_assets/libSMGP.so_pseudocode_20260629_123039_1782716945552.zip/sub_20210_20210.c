int8_t sub_20210(void)

{
  int8_t param1;
  uint32_t param2;
  int8_t *piVar1;
  
  for (piVar1 = *(int8_t **)(param1 + 0x28); piVar1 != (int8_t *)0x0; piVar1 = (int8_t *)*piVar1) {
    param1 = (*(code *)piVar1[1])(param2);
  }
  return param1;
}