// thunk -> external import
void j_access(void) {
    access();
}
