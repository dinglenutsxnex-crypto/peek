// thunk -> external import
void j___cxa_get_globals(void) {
    __cxa_get_globals();
}
