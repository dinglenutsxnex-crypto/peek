// thunk -> external import
void j__Z10executeHexRKSsS0_S0_S0_(void) {
    _Z10executeHexRKSsS0_S0_S0_();
}
