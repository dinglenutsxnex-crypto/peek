// thunk -> external import
void j_fread(void) {
    fread();
}
