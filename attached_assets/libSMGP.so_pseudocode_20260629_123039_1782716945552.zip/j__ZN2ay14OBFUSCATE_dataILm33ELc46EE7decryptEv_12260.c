// thunk -> external import
void j__ZN2ay14OBFUSCATE_dataILm33ELc46EE7decryptEv(void) {
    _ZN2ay14OBFUSCATE_dataILm33ELc46EE7decryptEv();
}
