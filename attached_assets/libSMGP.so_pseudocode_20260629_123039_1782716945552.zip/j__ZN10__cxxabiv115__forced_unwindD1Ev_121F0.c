// thunk -> external import
void j__ZN10__cxxabiv115__forced_unwindD1Ev(void) {
    _ZN10__cxxabiv115__forced_unwindD1Ev();
}
