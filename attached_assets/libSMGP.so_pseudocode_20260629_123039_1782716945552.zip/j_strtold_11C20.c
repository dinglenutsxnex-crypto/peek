// thunk -> external import
void j_strtold(void) {
    strtold();
}
