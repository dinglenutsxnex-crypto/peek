// thunk -> external import
void j_ungetwc(void) {
    ungetwc();
}
