// thunk -> external import
void j_pthread_getspecific(void) {
    pthread_getspecific();
}
