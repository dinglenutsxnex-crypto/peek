uint64_t sub_28EB0(void)

{
  void *param1;
  uint64_t ret0;
  
  sub_28DD0();
  _ZdlPv(param1);
  return ret0;
}