uint64_t sub_1DB10(void)

{
  uint64_t *param1;
  
  *param1 = 0xbcba0;
  sub_6F8D4(param1 + 2);
  if ((*(char *)(param1 + 3) != '\0') && ((void *)param1[6] != (void *)0x0)) {
    _ZdaPv((void *)param1[6]);
  }
}