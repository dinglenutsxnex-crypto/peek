uint64_t __cxa_pure_virtual(void)

{
  write(2,(void *)"pure virtual method called\n",0x1b);
  _ZSt9terminatev();
}