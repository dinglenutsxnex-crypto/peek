uint32_t * sub_1CF74(void)

{
  uint32_t val1;
  char cVar2;
  bool bVar3;
  uint32_t *param1;
  uint64_t val2;
  int8_t param3;
  
  if (*(int8_t *)(param3 + 0xd50) == 0) {
    *(uint8_t *)((int8_t)param1 + 1) = 0;
    return param1;
  }
  do {
    val1 = *param1;
    cVar2 = '\x01';
    bVar3 = (bool)ExclusiveMonitorPass(param1,0x10);
    if (bVar3) {
      *param1 = 0;
      cVar2 = ExclusiveMonitorsStatus();
    }
  } while (cVar2 != '\0');
  if ((val1 & 0x10000) != 0) {
    val2 = syscall(0x62);
    return (uint32_t *)val2;
  }
  return param1;
}