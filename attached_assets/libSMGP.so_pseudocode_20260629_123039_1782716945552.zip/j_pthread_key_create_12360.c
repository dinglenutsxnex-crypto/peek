// thunk -> external import
void j_pthread_key_create(void) {
    pthread_key_create();
}
