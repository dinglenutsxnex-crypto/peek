// thunk -> external import
void j__Z17executeparametersRKSsS0_S0_S0_(void) {
    _Z17executeparametersRKSsS0_S0_S0_();
}
