// thunk -> external import
void j__Znwm(void) {
    _Znwm();
}
