// thunk -> external import
void j___google_potentially_blocking_region_begin(void) {
    __google_potentially_blocking_region_begin();
}
