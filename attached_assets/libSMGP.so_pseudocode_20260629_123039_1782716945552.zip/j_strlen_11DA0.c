// thunk -> external import
void j_strlen(void) {
    strlen();
}
