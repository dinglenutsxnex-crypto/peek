uint64_t sub_28CDC(void)

{
  uint64_t ret_ptr;
  
  sub_63720();
  return ret_ptr;
}