uint32_t * sub_1E7B0(void)

{
  uint32_t *pxVar1;
  uint32_t val;
  uint32_t *param2;
  uint32_t *param3;
  uint32_t *pxVar3;
  uint32_t *pxVar4;
  
  if (param2 < param3) {
    pxVar1 = param2 + 1;
    pxVar4 = param2;
    do {
      pxVar3 = pxVar1;
      val = towlower(*pxVar4);
      *pxVar4 = val;
      pxVar1 = pxVar3 + 1;
      pxVar4 = pxVar3;
    } while (pxVar3 != (uint32_t *)
                       ((int8_t)param2 +
                       ((int8_t)param3 + (3 - (int8_t)(param2 + 1)) & 0xfffffffffffffffcU) + 4));
  }
  return param3;
}