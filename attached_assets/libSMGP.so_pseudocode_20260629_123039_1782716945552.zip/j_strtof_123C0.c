// thunk -> external import
void j_strtof(void) {
    strtof();
}
