uint64_t sub_20E64(void)

{
  uint64_t *param1;
  
  *param1 = 0xba638;
  param1[1] = 0;
  param1[2] = unk_bfb30 + 0x10;
  sub_202FC();
}