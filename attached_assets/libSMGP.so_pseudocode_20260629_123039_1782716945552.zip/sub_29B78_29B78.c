void sub_29B78(uint64_t *param_1,int8_t param_2)

{
  *(uint32_t *)(param_1 + 1) = (uint32_t)(param_2 != 0);
  *param_1 = 0xbd240;
  param_1[2] = 0;
  sub_3C980(param_1,0,0);
  return;
}