// thunk -> external import
void j_wmemcmp(void) {
    wmemcmp();
}
