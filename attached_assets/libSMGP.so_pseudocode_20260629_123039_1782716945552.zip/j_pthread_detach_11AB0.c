// thunk -> external import
void j_pthread_detach(void) {
    pthread_detach();
}
