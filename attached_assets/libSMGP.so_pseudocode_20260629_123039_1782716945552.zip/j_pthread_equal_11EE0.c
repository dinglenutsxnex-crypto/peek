// thunk -> external import
void j_pthread_equal(void) {
    pthread_equal();
}
