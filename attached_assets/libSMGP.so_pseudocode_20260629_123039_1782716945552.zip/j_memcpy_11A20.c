// thunk -> external import
void j_memcpy(void) {
    memcpy();
}
