uint64_t sub_1E598(void)

{
  int32_t val;
  uint64_t *param1;
  uint64_t ret;
  char *param2;
  
  sub_1E3C8(param1,0,0);
  *param1 = 0xbcd20;
  val = strcmp(param2,(char *)"nu.version_r");
  if ((val != 0) && (val = strcmp(param2,(char *)"POSIX"), val != 0)) {
    sub_6F8D4(param1 + 2);
    ret = sub_6F8A0(param1 + 2);
    return ret;
  }
  return 0;
}