void sub_29ED0(int8_t *param_1)

{
  (**(code **)(*param_1 + 0x18))();
  return;
}