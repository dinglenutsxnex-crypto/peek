uint8_t _ZNK10__cxxabiv120__si_class_type_info11__do_upcastEPKNS_17__class_type_infoEPKvRNS1_15__upcast_resultE
                (void)

{
  uint8_t val1;
  int8_t param1;
  
  val1 = _ZNK10__cxxabiv117__class_type_info11__do_upcastEPKS0_PKvRNS0_15__upcast_resultE();
  if (val1 == 0) {
    val1 = (**(code **)(**(int8_t **)(param1 + 0x10) + 0x30))(*(int8_t **)(param1 + 0x10));
  }
  return (uint8_t)val1;
}