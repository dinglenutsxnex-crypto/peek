uint64_t _Z21CheckFloatingPermisonP7_JNIEnvP8_jobject(void)

{
  char cVar1;

  uint64_t ret;

  (*env)->FindClass(env,"android/provider/Settings");
  (*env)->GetStaticMethodID();
  cVar1 = _ZN7_JNIEnv23CallStaticBooleanMethodEP7_jclassP10_jmethodIDz();
  if (cVar1 != '\0') {
    (*env)->GetObjectClass();
    (*env)->FindClass();
    (*env)->FindClass();
    (*env)->GetMethodID();
    _ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz();
    (*env)->GetMethodID();
  }
  (*env)->NewStringUTF();
  (*env)->FindClass();
  (*env)->GetStaticMethodID();
  _ZN7_JNIEnv22CallStaticObjectMethodEP7_jclassP10_jmethodIDz();
  (*env)->GetMethodID();
  _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  (*env)->NewStringUTF();
  (*env)->FindClass();
  (*env)->GetStaticMethodID();
  _ZN7_JNIEnv22CallStaticObjectMethodEP7_jclassP10_jmethodIDz();
  (*env)->GetMethodID();
  _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  ret = _Z22startActivityPermissonP7_JNIEnvP8_jobject();
  return ret;
}