uint64_t sub_28F94(void)

{
  void *param1;
  uint64_t ret0;
  
  sub_28E34();
  _ZdlPv(param1);
  return ret0;
}