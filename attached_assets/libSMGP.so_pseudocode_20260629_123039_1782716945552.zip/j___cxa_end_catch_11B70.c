// thunk -> external import
void j___cxa_end_catch(void) {
    __cxa_end_catch();
}
