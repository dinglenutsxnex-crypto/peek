// thunk -> external import
void j_memcmp(void) {
    memcmp();
}
