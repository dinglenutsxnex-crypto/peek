uint64_t sub_29EEC(void)

{

  uint64_t ret_ptr;

  (*env)->GetVersion();
  return ret_ptr;
}