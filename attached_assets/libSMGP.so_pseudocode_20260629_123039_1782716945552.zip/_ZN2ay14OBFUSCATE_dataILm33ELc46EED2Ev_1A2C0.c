// detected - ay::obfuscate (compile-time XOR string obfuscation) (detection may be wrong)
void _ZN2ay14OBFUSCATE_dataILm33ELc46EED2Ev(uint64_t *param_1)

{
  *(uint8_t *)(param_1 + 4) = 0;
  param_1[1] = 0;
  *param_1 = 0;
  param_1[3] = 0;
  param_1[2] = 0;
  return;
}