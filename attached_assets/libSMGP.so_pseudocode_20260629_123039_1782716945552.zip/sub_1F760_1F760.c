int8_t sub_1F760(void)

{
  int8_t param1;
  int8_t ret0;
  uint32_t param2;
  
  *(uint32_t *)(param1 + 0x20) = *(uint32_t *)(param1 + 0x20) | param2;
  if ((param2 & *(uint32_t *)(param1 + 0x1c)) == 0) {
    return param1;
  }
  __cxa_rethrow();
  return (uint8_t)(*(int32_t *)(ret0 + 0x20) == 0);
}