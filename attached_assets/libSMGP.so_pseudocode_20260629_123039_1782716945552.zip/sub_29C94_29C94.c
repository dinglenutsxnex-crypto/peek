void sub_29C94(int8_t *param_1)

{
  (**(code **)(*param_1 + 0x18))();
  return;
}