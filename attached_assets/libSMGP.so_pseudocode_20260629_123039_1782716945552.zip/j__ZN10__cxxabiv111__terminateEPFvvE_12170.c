// thunk -> external import
void j__ZN10__cxxabiv111__terminateEPFvvE(void) {
    _ZN10__cxxabiv111__terminateEPFvvE();
}
