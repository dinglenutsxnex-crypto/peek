// thunk -> external import
void j_syscall(void) {
    syscall();
}
