uint64_t sub_1F948(void)

{
  int8_t param1;
  int8_t param2;
  uint64_t ret;
  
  ret = *(uint64_t *)(param1 + 0xe8);
  *(uint32_t *)(param1 + 0x20) = (uint32_t)(param2 == 0);
  *(int8_t *)(param1 + 0xe8) = param2;
  if (((uint32_t)(param2 == 0) & *(uint32_t *)(param1 + 0x1c)) == 0) {
    return ret;
  }
  sub_62640("basic_ios::clear");
}