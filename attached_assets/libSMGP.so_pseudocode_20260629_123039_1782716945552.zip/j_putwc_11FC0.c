// thunk -> external import
void j_putwc(void) {
    putwc();
}
