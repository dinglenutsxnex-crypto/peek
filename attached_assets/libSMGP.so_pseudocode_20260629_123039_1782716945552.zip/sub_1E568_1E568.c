uint64_t sub_1E568(void)

{
  uint64_t *param1;
  uint64_t ret0;
  
  *param1 = 0xbcd20;
  sub_1DB10();
  _ZdlPv(param1);
  return ret0;
}