// thunk -> external import
void j___cxa_guard_release(void) {
    __cxa_guard_release();
}
