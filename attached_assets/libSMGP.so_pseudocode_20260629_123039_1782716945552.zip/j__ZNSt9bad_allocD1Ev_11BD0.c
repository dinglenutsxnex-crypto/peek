// thunk -> external import
void j__ZNSt9bad_allocD1Ev(void) {
    _ZNSt9bad_allocD1Ev();
}
