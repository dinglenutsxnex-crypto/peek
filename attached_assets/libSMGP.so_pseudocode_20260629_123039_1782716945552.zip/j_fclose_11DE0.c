// thunk -> external import
void j_fclose(void) {
    fclose();
}
