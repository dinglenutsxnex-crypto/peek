int8_t * sub_21A7C(void)

{
  bool bVar1;
  jobject obj;
  jclass cls;
  int8_t *param1;
  uint8_t *puVar4;
  uint8_t *param2;
  int8_t param3;
  uint8_t *puVar5;
  uint8_t param4;
  int8_t *env;
  uint8_t *pxVar7;
  char cStack_8;
  
  param1[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') {
    bVar1 = false;
  }
  else {
    env = *(int8_t **)((int8_t)param1 + *(int8_t *)(*param1 - 0x18) + 0xe8);
    puVar4 = (uint8_t *)env[2];
    if ((uint8_t *)env[3] <= puVar4) goto L_00021b38;
L_00021adc:
    obj = (uint32_t)*puVar4;
L_00021ae0:
    pxVar7 = param2;
    if (obj != JNI_ERR && obj != param4) {
      do {
        param2 = pxVar7;
        if (param3 <= param1[1] + 1) break;
        param2 = pxVar7 + 1;
        *pxVar7 = (char)obj;
        puVar4 = (uint8_t *)env[2];
        puVar5 = (uint8_t *)env[3];
        param1[1] = param1[1] + 1;
        if (puVar4 < puVar5) {
          puVar4 = puVar4 + 1;
          env[2] = (int8_t)puVar4;
        }
        else {
          cls = (*env)->GetSuperclass(env);
          obj = JNI_ERR;
          if (cls == -1) goto L_00021ae0;
          puVar4 = (uint8_t *)env[2];
          puVar5 = (uint8_t *)env[3];
        }
        if (puVar4 < puVar5) goto L_00021adc;
L_00021b38:
        obj = (*env)->ToReflectedMethod(env);
        pxVar7 = param2;
        if (obj == JNI_ERR || obj == param4) break;
      } while( true );
    }
    bVar1 = obj == JNI_ERR;
  }
  if (0 < param3) {
    *param2 = 0;
  }
  if ((param1[1] != 0) && (!bVar1)) {
    return param1;
  }
  sub_1ED34();
  return param1;
}