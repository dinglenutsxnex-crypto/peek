// thunk -> external import
void j_towlower(void) {
    towlower();
}
