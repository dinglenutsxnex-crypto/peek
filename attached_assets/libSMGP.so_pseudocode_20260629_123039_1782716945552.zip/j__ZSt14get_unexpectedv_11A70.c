// thunk -> external import
void j__ZSt14get_unexpectedv(void) {
    _ZSt14get_unexpectedv();
}
