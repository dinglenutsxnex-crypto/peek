void _ZdlPv(void *param_1)

{
  free(param_1);
  return;
}