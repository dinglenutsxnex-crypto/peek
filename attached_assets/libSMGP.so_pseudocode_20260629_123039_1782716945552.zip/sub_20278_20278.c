uint64_t * sub_20278(void)

{
  char cVar1;
  bool bVar2;
  void *param1;
  int32_t *piVar3;
  uint64_t *param1;
  void *ret0;
  uint64_t *pxVar4;
  int32_t val;
  
  pxVar4 = *(uint64_t **)((int8_t)param1 + 0x28);
  param1 = param1;
  if (pxVar4 != (uint64_t *)0x0) {
    piVar3 = (int32_t *)((int8_t)pxVar4 + 0x14);
    if (pthread_create == 0) goto L_000202ec;
    do {
      do {
        val = *piVar3;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar3,0x10);
        if (bVar2) {
          *piVar3 = val - 1;
          cVar1 = ExclusiveMonitorsStatus();
        }
        param1 = pxVar4;
      } while (cVar1 != '\0');
      while( true ) {
        if (val != 0) goto L_000202bc;
        pxVar4 = (uint64_t *)*param1;
        _ZdlPv(param1);
        param1 = ret0;
        if (pxVar4 == (uint64_t *)0x0) goto L_000202bc;
        piVar3 = (int32_t *)((int8_t)pxVar4 + 0x14);
        if (pthread_create != 0) break;
L_000202ec:
        val = *(int32_t *)((int8_t)pxVar4 + 0x14);
        *(int32_t *)((int8_t)pxVar4 + 0x14) = val - 1;
        param1 = pxVar4;
      }
    } while( true );
  }
L_000202bc:
  *(uint64_t *)((int8_t)param1 + 0x28) = 0;
  return param1;
}