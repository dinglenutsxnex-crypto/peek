int8 * _ZNSt6thread10_Impl_baseD2Ev(void)

{
  int8 *piVar1;
  int4 val1;
  char cVar3;
  bool bVar4;
  int8 val2;
  int8 *in_x0;
  uint64_t val3;
  int8 *piVar7;
  int4 *piVar8;
  
  piVar7 = (int8 *)in_x0[2];
  *in_x0 = _ZTVNSt6thread10_Impl_baseE + 0x10;
  val2 = pthread_create;
  if (piVar7 != (int8 *)0x0) {
    piVar1 = piVar7 + 1;
    if (pthread_create == 0) {
      val1 = (int4)*piVar1;
      *(int4 *)piVar1 = val1 + -1;
    }
    else {
      do {
        val1 = (int4)*piVar1;
        cVar3 = '\x01';
        bVar4 = (bool)ExclusiveMonitorPass(piVar1,0x10);
        if (bVar4) {
          *(int4 *)piVar1 = val1 + -1;
          cVar3 = ExclusiveMonitorsStatus();
        }
      } while (cVar3 != '\0');
    }
    if (val1 == 1) {
      piVar8 = (int4 *)((int8)piVar7 + 0xc);
      in_x0 = (int8 *)(**(code **)(*piVar7 + 0x10))(piVar7);
      if (val2 == 0) {
        val1 = *piVar8;
        *piVar8 = val1 + -1;
      }
      else {
        do {
          val1 = *piVar8;
          cVar3 = '\x01';
          bVar4 = (bool)ExclusiveMonitorPass(piVar8,0x10);
          if (bVar4) {
            *piVar8 = val1 + -1;
            cVar3 = ExclusiveMonitorsStatus();
          }
        } while (cVar3 != '\0');
      }
      if (val1 == 1) {
        val3 = (**(code **)(*piVar7 + 0x18))(piVar7);
        return (int8 *)val3;
      }
    }
  }
  return in_x0;
}