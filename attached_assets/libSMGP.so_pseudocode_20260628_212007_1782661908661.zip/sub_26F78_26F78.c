int8 * sub_26F78(void)

{
  uint1 val1;
  uint4 val2;
  jobject obj;
  int8 *in_x0;
  void *pvVar4;
  uint1 *puVar5;
  int4 val3;
  uint8_t *in_x1;
  int8 val4;
  uint8 val5;
  uint8 val6;
  int8 in_x2;
  int8 val7;
  uint1 *puVar11;
  uint1 in_w3;
  uint8 val8;
  int8 *env;
  uint8_t *param1;
  void *param1_00;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') {
code_r0x00027100:
    val3 = 0;
code_r0x00027104:
    if (0 < in_x2) {
      *in_x1 = 0;
    }
    if ((in_x0[1] != 0) && (val3 == 0)) {
      return in_x0;
    }
    sub_1ED34();
    return in_x0;
  }
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  if ((uint1 *)env[2] < (uint1 *)env[3]) {
    obj = (uint4)*(uint1 *)env[2];
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
  }
code_r0x00026fe0:
  val4 = in_x0[1];
  do {
    val7 = val4 + 1;
    param1 = in_x1;
    val2 = obj;
    if (obj == in_w3 || obj == JNI_ERR) {
code_r0x000270a0:
      if (obj == JNI_ERR) {
        val3 = 2;
        goto code_r0x00027104;
      }
      val3 = 4;
      if (in_w3 != obj) goto code_r0x00027104;
      val5 = env[2];
      val6 = env[3];
      in_x0[1] = val7;
      if (val6 <= val5) {
        (*env)->GetSuperclass(env);
        goto code_r0x00027100;
      }
      val3 = 0;
      env[2] = val5 + 1;
      goto code_r0x00027104;
    }
    while( true ) {
      obj = val2;
      in_x1 = param1;
      if (in_x2 <= val7) goto code_r0x000270a0;
      param1_00 = (void *)env[2];
      val5 = (in_x2 - val4) - 1;
      if (env[3] - (int8)param1_00 < (int8)val5) {
        val5 = env[3] - (int8)param1_00;
      }
      if ((int8)val5 < 2) break;
      pvVar4 = memchr(param1_00,(uint4)in_w3,val5);
      val6 = (int8)pvVar4 - (int8)param1_00;
      if (pvVar4 == (void *)0x0) {
        val6 = val5;
      }
      in_x1 = param1 + val6;
      memcpy(param1,param1_00,val6);
      val7 = env[2];
      val4 = in_x0[1];
      val8 = env[3];
      val5 = val7 + val6;
      env[2] = val5;
      val4 = val6 + val4;
      in_x0[1] = val4;
      if (val8 <= val5) {
        obj = (*env)->ToReflectedMethod(env);
        goto code_r0x00026fe0;
      }
      val1 = *(uint1 *)(val7 + val6);
      obj = (uint4)val1;
      val7 = val4 + 1;
      param1 = in_x1;
      val2 = (uint4)val1;
      if ((uint4)val1 == (uint4)in_w3 || val1 == JNI_ERR) goto code_r0x000270a0;
    }
    *param1 = (char)obj;
    in_x1 = param1 + 1;
    puVar5 = (uint1 *)env[2];
    puVar11 = (uint1 *)env[3];
    in_x0[1] = in_x0[1] + 1;
    if (puVar5 < puVar11) {
      puVar5 = puVar5 + 1;
      env[2] = (int8)puVar5;
    }
    else {
      obj = (*env)->GetSuperclass(env);
      if (obj == JNI_ERR) goto code_r0x00026fe0;
      puVar5 = (uint1 *)env[2];
      puVar11 = (uint1 *)env[3];
    }
    if (puVar11 <= puVar5) break;
    obj = (uint4)*puVar5;
    val4 = in_x0[1];
  } while( true );
  obj = (*env)->ToReflectedMethod(env);
  goto code_r0x00026fe0;
}