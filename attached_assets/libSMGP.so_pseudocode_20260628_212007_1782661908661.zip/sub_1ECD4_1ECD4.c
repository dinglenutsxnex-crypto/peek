uint64_t sub_1ECD4(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xba5e0;
  func_0x000202fc();
}