uint64_t sub_1F9E4(void)

{
  uint4 val1;
  int8 in_x0;
  int8 *env;
  jclass cls;
  uint32_t in_w1;
  
  if (*(char *)(in_x0 + 0xe4) != '\0') {
    val1 = *(uint4 *)(in_x0 + 0xe0);
    *(uint32_t *)(in_x0 + 0xe0) = in_w1;
    return (uint8)val1;
  }
  env = *(int8 **)(in_x0 + 0xf0);
  if (env != (int8 *)0x0) {
    cls = (*env)->GetSuperclass(env,0x20);
    *(uint32_t *)(in_x0 + 0xe0) = in_w1;
    *(uint8_t *)(in_x0 + 0xe4) = 1;
    jclass cls;
  }
  func_0x00061e30();
}