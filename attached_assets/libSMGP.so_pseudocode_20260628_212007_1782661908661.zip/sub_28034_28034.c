int8 * sub_28034(void)

{
  jobject obj;
  int8 *in_x0;
  int4 *piVar2;
  uint8 val1;
  int4 val2;
  int4 *in_x1;
  int8 in_x2;
  int8 val3;
  int8 val4;
  int4 in_w3;
  int4 *piVar7;
  int8 val5;
  uint8 val6;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_24104();
  if (cStack_8 == '\0') {
code_r0x000281c0:
    val3 = in_x0[1];
    val2 = 0;
code_r0x000281c8:
    if (0 < in_x2) {
      *in_x1 = 0;
    }
    if ((val3 != 0) && (val2 == 0)) {
      return in_x0;
    }
    sub_1F6E0();
    return in_x0;
  }
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  if ((int4 *)env[2] < (int4 *)env[3]) {
    obj = *(int4 *)env[2];
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
  }
code_r0x00028098:
  do {
    val3 = in_x0[1];
code_r0x0002809c:
    val5 = val3 + 1;
    if (in_w3 == obj || obj == -1) {
code_r0x0002815c:
      if (obj == -1) {
        val2 = 2;
        goto code_r0x000281c8;
      }
      val2 = 4;
      if (in_w3 != obj) goto code_r0x000281c8;
      val1 = env[2];
      val6 = env[3];
      in_x0[1] = val5;
      if (val6 <= val1) {
        (*env)->GetSuperclass(env);
        goto code_r0x000281c0;
      }
      env[2] = val1 + 4;
      val2 = 0;
      val3 = val5;
      goto code_r0x000281c8;
    }
    while( true ) {
      if (in_x2 <= val5) goto code_r0x0002815c;
      piVar7 = (int4 *)env[3];
      piVar2 = (int4 *)env[2];
      val4 = (in_x2 - val3) + -1;
      val3 = (int8)piVar7 - (int8)piVar2 >> 2;
      if (val3 < val4) {
        val4 = val3;
      }
      if (val4 < 2) break;
      val3 = wmemchr(piVar2,in_w3,val4);
      if (val3 != 0) {
        val4 = val3 - env[2] >> 2;
      }
      wmemcpy(in_x1,env[2],val4);
      val5 = env[2];
      val3 = in_x0[1];
      in_x1 = in_x1 + val4;
      val6 = env[3];
      val1 = val5 + val4 * 4;
      env[2] = val1;
      val3 = val4 + val3;
      in_x0[1] = val3;
      if (val6 <= val1) {
        obj = (*env)->ToReflectedMethod(env);
        goto code_r0x00028098;
      }
      obj = *(int4 *)(val5 + val4 * 4);
      val5 = val3 + 1;
      if (in_w3 == obj || obj == -1) goto code_r0x0002815c;
    }
    *in_x1 = obj;
    in_x0[1] = val5;
    in_x1 = in_x1 + 1;
    if (piVar2 < piVar7) {
      obj = *piVar2;
      env[2] = (int8)(piVar2 + 1);
    }
    else {
      obj = (*env)->GetSuperclass(env);
    }
    if (obj == -1) {
      val3 = in_x0[1];
      obj = -1;
      goto code_r0x0002809c;
    }
    if ((int4 *)env[2] < (int4 *)env[3]) {
      obj = *(int4 *)env[2];
      val3 = in_x0[1];
      goto code_r0x0002809c;
    }
    obj = (*env)->ToReflectedMethod(env);
  } while( true );
}