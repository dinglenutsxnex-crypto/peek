uint8 sub_22158(void)

{
  jobject obj;
  int8 *in_x0;
  int8 *env;
  uint8 ret;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') {
    ret = JNI_ERR;
  }
  else {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if ((uint1 *)env[2] < (uint1 *)env[3]) {
      ret = (uint8)*(uint1 *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod();
      ret = (uint8)obj;
      if (obj == JNI_ERR) {
        sub_1ED34();
        return JNI_ERR;
      }
    }
  }
  return ret;
}