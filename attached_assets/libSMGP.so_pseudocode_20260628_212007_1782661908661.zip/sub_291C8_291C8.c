uint64_t sub_291C8(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xbd2b0;
  func_0x0006f8d4(in_x0 + 2);
}