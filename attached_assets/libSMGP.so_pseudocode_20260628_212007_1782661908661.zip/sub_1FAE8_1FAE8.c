uint8 sub_1FAE8(void)

{
  int8 val1;
  char cVar2;
  int8 in_x0;
  uint64_t val2;
  int8 in_x1;
  
  val1 = in_x0 + 0xd0;
  func_0x00020d7c();
  cVar2 = func_0x0004e19c(val1);
  if (cVar2 == '\0') {
    *(uint64_t *)(in_x0 + 0xf0) = 0;
    cVar2 = func_0x0004e34c(val1);
  }
  else {
    val2 = func_0x0004c214(val1);
    *(uint64_t *)(in_x0 + 0xf0) = val2;
    cVar2 = func_0x0004e34c(val1);
  }
  if (cVar2 == '\0') {
    *(uint64_t *)(in_x0 + 0xf8) = 0;
    cVar2 = func_0x0004e3b8(val1);
  }
  else {
    val2 = func_0x0004cf28(val1);
    *(uint64_t *)(in_x0 + 0xf8) = val2;
    cVar2 = func_0x0004e3b8(val1);
  }
  if (cVar2 == '\0') {
    *(uint64_t *)(in_x0 + 0x100) = 0;
  }
  else {
    val2 = func_0x0004cf90(val1);
    *(uint64_t *)(in_x0 + 0x100) = val2;
  }
  *(int8 *)(in_x0 + 0xe8) = in_x1;
  *(uint32_t *)(in_x0 + 0xe0) = 0;
  *(uint8_t *)(in_x0 + 0xe4) = 0;
  *(uint64_t *)(in_x0 + 0xd8) = 0;
  *(uint32_t *)(in_x0 + 0x1c) = 0;
  *(uint4 *)(in_x0 + 0x20) = (uint4)(in_x1 == 0);
  return (uint8)(in_x1 == 0);
}