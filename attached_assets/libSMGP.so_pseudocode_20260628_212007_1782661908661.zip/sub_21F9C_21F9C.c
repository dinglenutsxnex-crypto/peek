uint64_t sub_21F9C(void)

{
  int8 *in_x0;
  int8 *env;
  
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xf0);
  if (env == (int8 *)0x0) {
    func_0x00061e30();
  }
  if ((char)env[7] != '\0') {
  }
  sub_1DFC0();
  (*env)->FindClass(env,10);
}