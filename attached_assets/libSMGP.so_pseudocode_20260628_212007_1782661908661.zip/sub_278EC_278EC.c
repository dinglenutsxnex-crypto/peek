int8 * sub_278EC(void)

{
  uint1 *puVar1;
  uint8 val1;
  uint1 val2;
  uint4 val3;
  jclass cls;
  int8 *in_x0;
  int8 val4;
  jobject obj;
  uint1 *puVar8;
  int8 *in_x1;
  int8 val5;
  int8 val6;
  uint1 *puVar11;
  int8 val7;
  uint1 *puVar13;
  int8 *env;
  uint1 *puVar15;
  char cStack_10;
  uint8_t axStack_8 [8];
  
  sub_21204();
  if (cStack_10 != '\0') {
    func_0x00065820();
    puVar15 = *(uint1 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10);
    if ((int8)puVar15 < 1) {
      puVar15 = (uint1 *)0x3ffffffffffffff9;
    }
    func_0x0003989c(axStack_8,(int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xd0);
    val4 = func_0x0002b34c(axStack_8);
    func_0x0003a188(axStack_8);
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if ((uint1 *)env[2] < (uint1 *)env[3]) {
      obj = (uint8)*(uint1 *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod(env);
      if ((int4)obj == -1) {
code_r0x00027ba8:
        *(uint64_t *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10) = 0;
        goto code_r0x00027930;
      }
    }
    val7 = *(int8 *)(val4 + 0x30);
    puVar13 = (uint1 *)0x0;
    val2 = *(uint1 *)(val7 + (obj & 0xff));
    while ((val2 >> 3 & 1) == 0) {
      val5 = env[2];
      val6 = (int8)puVar15 - (int8)puVar13;
      if (env[3] - val5 < (int8)puVar15 - (int8)puVar13) {
        val6 = env[3] - val5;
      }
      if (val6 < 2) {
        val6 = *in_x1;
        val7 = *(int8 *)(val6 + -0x18);
        val1 = val7 + 1;
        if ((*(uint8 *)(val6 + -0x10) < val1) || (0 < *(int4 *)(val6 + -8))) {
          func_0x00063bf0();
          val6 = *in_x1;
          val7 = *(int8 *)(val6 + -0x18);
        }
        *(char *)(val6 + val7) = (char)obj;
        val7 = *in_x1;
        if (val7 + -0x18 != unk_bff48) {
          *(uint32_t *)(val7 + -8) = 0;
          *(uint8 *)(val7 + -0x18) = val1;
          *(uint8_t *)(val7 + val1) = 0;
        }
        puVar13 = puVar13 + 1;
        puVar11 = (uint1 *)env[3];
        if ((uint1 *)env[2] < puVar11) {
          puVar8 = (uint1 *)env[2] + 1;
          env[2] = (int8)puVar8;
        }
        else {
          cls = (*env)->GetSuperclass(env);
          if (cls == -1) goto code_r0x00027ba8;
          puVar8 = (uint1 *)env[2];
          puVar11 = (uint1 *)env[3];
        }
        if (puVar8 < puVar11) {
          val2 = *puVar8;
          goto code_r0x00027a68;
        }
code_r0x00027b88:
        obj = (*env)->ToReflectedMethod(env);
        val3 = (uint4)obj;
        if (puVar15 <= puVar13) {
code_r0x00027ab8:
          if (val3 != JNI_ERR) {
            *(uint64_t *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10) = 0;
            return in_x0;
          }
          *(uint64_t *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10) = 0;
          goto code_r0x00027930;
        }
        if (val3 == JNI_ERR) goto code_r0x00027ba8;
      }
      else {
        puVar11 = (uint1 *)(val5 + 1);
        puVar8 = (uint1 *)(val5 + val6);
        if (puVar11 < puVar8) {
          val2 = *(uint1 *)(val7 + (uint8)*(uint1 *)(val5 + 1));
          while (((val2 >> 3 & 1) == 0 &&
                 (puVar1 = puVar11 + 1, puVar11 = puVar8, puVar1 != puVar8))) {
            val2 = *(uint1 *)(val7 + (uint8)*puVar1);
            puVar11 = puVar1;
          }
        }
        func_0x0006433c();
        val7 = env[2];
        puVar13 = puVar11 + ((int8)puVar13 - val5);
        env[2] = (int8)(puVar11 + (val7 - val5));
        if ((uint1 *)env[3] <= puVar11 + (val7 - val5)) goto code_r0x00027b88;
        val2 = puVar11[val7 - val5];
code_r0x00027a68:
        obj = (uint8)val2;
        val3 = (uint4)val2;
        if (puVar15 <= puVar13) goto code_r0x00027ab8;
      }
      val7 = *(int8 *)(val4 + 0x30);
      val2 = *(uint1 *)(val7 + (obj & 0xff));
    }
    *(uint64_t *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10) = 0;
    if (puVar13 != (uint1 *)0x0) {
      return in_x0;
    }
  }
code_r0x00027930:
  sub_1ED34();
  return in_x0;
}