void sub_29C28(uint64_t *param_1,uint64_t param_2,uint64_t param_3,int8 param_4)

{
  *(uint4 *)(param_1 + 1) = (uint4)(param_4 != 0);
  param_1[2] = 0;
  *param_1 = 0xbd240;
  func_0x0003c980();
  return;
}