uint64_t sub_1D9D8(void)

{

  uint64_t ret;

  fileno(*in_x0);
  ret = lseek();
  return ret;
}