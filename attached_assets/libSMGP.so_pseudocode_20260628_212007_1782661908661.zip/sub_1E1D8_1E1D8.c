uint64_t sub_1E1D8(void)

{
  uint64_t *in_x0;
  uint64_t ret;
  int8 in_x2;
  uint8_t axStack_8 [8];
  
  *(uint4 *)(in_x0 + 1) = (uint4)(in_x2 != 0);
  *in_x0 = 0xbcc00;
  ret = func_0x0006f8dc(axStack_8);
  *(uint8_t *)(in_x0 + 3) = 0;
  in_x0[2] = ret;
  ret = func_0x0001ebcc();
  return ret;
}