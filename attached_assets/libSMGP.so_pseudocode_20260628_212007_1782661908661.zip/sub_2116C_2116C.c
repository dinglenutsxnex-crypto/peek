uint8_t * sub_2116C(void)

{
  uint64_t *in_x0;
  uint8_t *pxVar1;
  
  func_0x0001ff5c(in_x0 + 2);
  in_x0[0x1d] = 0;
  *(uint8_t *)(in_x0 + 0x1e) = 0;
  *(uint8_t *)((int8)in_x0 + 0xf1) = 0;
  in_x0[0x1f] = 0;
  in_x0[0x20] = 0;
  in_x0[0x21] = 0;
  in_x0[0x22] = 0;
  *in_x0 = 0xba638;
  in_x0[1] = 0;
  in_x0[2] = 0xba660;
  pxVar1 = sub_1F208();
  return pxVar1;
}