int8 * sub_21044(void)

{
  int8 *in_x0;
  code *in_x1;
  
  (*in_x1)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18));
  return in_x0;
}