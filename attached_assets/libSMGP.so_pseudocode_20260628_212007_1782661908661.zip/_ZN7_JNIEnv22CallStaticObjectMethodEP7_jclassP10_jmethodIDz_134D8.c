void _ZN7_JNIEnv22CallStaticObjectMethodEP7_jclassP10_jmethodIDz
               (int8 *env,uint64_t param_2,uint64_t param_3,uint64_t param_4,
               uint64_t param_5,uint64_t param_6,uint64_t param_7,uint64_t param_8)

{

  uint8_t axStack_a0 [8];

  uint8_t *pxStack_70;

  pxStack_70 = (uint8_t *)register0x00000008;
  (*env)->CallStaticObjectMethodV();

  __stack_chk_fail();
}