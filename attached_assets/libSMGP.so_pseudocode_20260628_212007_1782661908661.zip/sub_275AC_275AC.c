int8 * sub_275AC(void)

{
  uint1 *puVar1;
  uint1 val1;
  uint4 val2;
  jclass cls;
  int8 *in_x0;
  int8 val3;
  jobject obj;
  uint1 *puVar7;
  uint8_t *in_x1;
  void *param2;
  uint1 *puVar8;
  int8 val4;
  int8 val5;
  uint8 param3;
  int8 *env;
  uint8_t *param1;
  int8 val6;
  int8 val7;
  char cStack_10;
  uint8_t axStack_8 [8];
  
  sub_21204();
  if (cStack_10 != '\0') {
    val7 = *(int8 *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10);
    if (val7 < 1) {
      val7 = 0x7fffffffffffffff;
    }
    func_0x0003989c(axStack_8,(int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xd0);
    val3 = func_0x0002b34c(axStack_8);
    func_0x0003a188(axStack_8);
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if ((uint1 *)env[2] < (uint1 *)env[3]) {
      obj = (uint8)*(uint1 *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod(env);
    }
    val6 = 0;
code_r0x00027650:
    val2 = (uint4)obj;
    param1 = in_x1;
    if (val6 < val7 + -1) {
      while( true ) {
        val2 = (uint4)obj;
        in_x1 = param1;
        if (val2 == JNI_ERR) goto code_r0x0002777c;
        val5 = *(int8 *)(val3 + 0x30);
        if ((*(uint1 *)(val5 + (obj & 0xff)) >> 3 & 1) != 0) goto code_r0x00027674;
        param2 = (void *)env[2];
        val4 = (val7 - val6) + -1;
        if (env[3] - (int8)param2 < val4) {
          val4 = env[3] - (int8)param2;
        }
        if (val4 < 2) {
          *param1 = (char)obj;
          in_x1 = param1 + 1;
          val6 = val6 + 1;
          puVar8 = (uint1 *)env[3];
          if ((uint1 *)env[2] < puVar8) {
            puVar7 = (uint1 *)env[2] + 1;
            env[2] = (int8)puVar7;
          }
          else {
            cls = (*env)->GetSuperclass(env);
            obj = JNI_ERR;
            if (cls == -1) goto code_r0x00027650;
            puVar7 = (uint1 *)env[2];
            puVar8 = (uint1 *)env[3];
          }
          if (puVar7 < puVar8) {
            obj = (uint8)*puVar7;
          }
          else {
            obj = (*env)->ToReflectedMethod(env);
          }
          goto code_r0x00027650;
        }
        puVar8 = (uint1 *)((int8)param2 + 1);
        puVar7 = (uint1 *)((int8)param2 + val4);
        if (puVar8 < puVar7) {
          val1 = *(uint1 *)(val5 + (uint8)*(uint1 *)((int8)param2 + 1));
          while (((val1 >> 3 & 1) == 0 && (puVar1 = puVar8 + 1, puVar8 = puVar7, puVar1 != puVar7))
                ) {
            val1 = *(uint1 *)(val5 + (uint8)*puVar1);
            puVar8 = puVar1;
          }
        }
        param3 = (int8)puVar8 - (int8)param2;
        in_x1 = param1 + param3;
        val6 = val6 + param3;
        memcpy(param1,param2,param3);
        val5 = env[2];
        obj = val5 + param3;
        env[2] = obj;
        if ((uint8)env[3] <= obj) break;
        val1 = *(uint1 *)(val5 + param3);
        obj = (uint8)val1;
        val2 = (uint4)val1;
        param1 = in_x1;
        if (val7 + -1 <= val6) goto code_r0x0002777c;
      }
      obj = (*env)->ToReflectedMethod(env);
      goto code_r0x00027650;
    }
code_r0x0002777c:
    if (val2 == JNI_ERR) {
      *in_x1 = 0;
      *(uint64_t *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10) = 0;
    }
    else {
code_r0x00027674:
      *in_x1 = 0;
      *(uint64_t *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10) = 0;
      if (val6 != 0) {
        return in_x0;
      }
    }
  }
  sub_1ED34();
  return in_x0;
}