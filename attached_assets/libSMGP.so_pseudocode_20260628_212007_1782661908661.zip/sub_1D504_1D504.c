uint8 sub_1D504(void)

{
  int4 in_w0;
  int8 val;
  int4 *piVar2;
  void *in_x1;
  uint8 in_x2;
  uint8 param3;
  
  param3 = in_x2;
  do {
    while (val = write(in_w0,in_x1,param3), val == -1) {
      piVar2 = (int4 *)__errno();
      if (*piVar2 != 4) {
        return in_x2 - param3;
      }
    }
    param3 = param3 - val;
    in_x1 = (void *)((int8)in_x1 + val);
  } while (param3 != 0);
  return in_x2;
}