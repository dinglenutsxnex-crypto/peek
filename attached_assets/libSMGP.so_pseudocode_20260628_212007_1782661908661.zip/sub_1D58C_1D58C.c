uint64_t * sub_1D58C(void)

{
  uint4 val;
  uint64_t *in_x0;
  int4 *piVar2;
  uint64_t *pxVar3;
  void *param1;
  
  param1 = (void *)*in_x0;
  pxVar3 = in_x0;
  if ((param1 != (void *)0x0) && (*(char *)(in_x0 + 1) != '\0')) {
    piVar2 = (int4 *)__errno();
    *piVar2 = 0;
    val = fclose(param1);
    while ((pxVar3 = (uint64_t *)(uint8)val, val != 0 && (*piVar2 == 4))) {
      val = fclose((void *)*in_x0);
    }
  }
  return pxVar3;
}