int8 * sub_250CC(void)

{
  int8 *in_x0;
  int8 val;
  int8 in_x2;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_24104();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    val = (*env)->FromReflectedField(env);
    in_x0[1] = val;
    if (in_x2 != val) {
      sub_1F6E0();
      return in_x0;
    }
  }
  return in_x0;
}