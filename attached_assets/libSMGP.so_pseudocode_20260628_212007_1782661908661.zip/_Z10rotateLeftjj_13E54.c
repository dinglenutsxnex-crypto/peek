uint8 _Z10rotateLeftjj(void)

{
  uint4 val;
  uint4 in_w0;
  int4 in_w1;
  
  val = 0x20U - in_w1 & 0x1f;
  return (uint8)(in_w0 >> val | in_w0 << 0x20 - val);
}