uint64_t sub_12980(void)

{
  int4 val;
  uint64_t ret;
  
  unk_d362c = false;
  if (pthread_create != 0) {
    val = pthread_key_create(0xd3628,0x6da30);
    unk_d362c = val == 0;
  }
  ret = __cxa_atexit(0x6da14,0xd3628,0xc0000);
  return ret;
}