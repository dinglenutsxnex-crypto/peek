uint64_t sub_29CB0(void)

{
  int8 *env;
  uint64_t in_x8;
  
  (*env)->GetVersion();
  return in_x8;
}