uint64_t sub_24104(void)

{
  char cVar1;
  jobject obj;
  uint8_t *in_x0;
  int8 *in_x1;
  char in_w2;
  int4 *piVar3;
  int8 val;
  int8 *env;
  int8 *piVar6;
  
  val = *(int8 *)(*in_x1 + -0x18);
  *in_x0 = 0;
  val = (int8)in_x1 + val;
  if (*(int4 *)(val + 0x20) != 0) goto code_r0x00024178;
  if (*(int8 *)(val + 0xd8) == 0) {
    if (in_w2 != '\0') goto code_r0x0002415c;
code_r0x00024198:
    if ((*(uint4 *)(val + 0x18) >> 0xc & 1) != 0) {
      env = *(int8 **)(val + 0xe8);
      if ((int4 *)env[2] < (int4 *)env[3]) {
        obj = *(int4 *)env[2];
      }
      else {
        obj = (*env)->ToReflectedMethod(env);
        val = (int8)in_x1 + *(int8 *)(*in_x1 + -0x18);
      }
      piVar6 = *(int8 **)(val + 0xf0);
      if (piVar6 == (int8 *)0x0) {
        func_0x00061e30();
      }
      while (obj != -1) {
        cVar1 = (**(code **)(*piVar6 + 0x10))(piVar6,8);
        if (cVar1 == '\0') {
          val = (int8)in_x1 + *(int8 *)(*in_x1 + -0x18);
          goto code_r0x00024154;
        }
        piVar3 = (int4 *)env[2];
        if (piVar3 < (int4 *)env[3]) {
          obj = *piVar3;
          env[2] = (int8)(piVar3 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj == -1) break;
        if ((int4 *)env[2] < (int4 *)env[3]) {
          obj = *(int4 *)env[2];
        }
        else {
          obj = (*env)->ToReflectedMethod(env);
        }
      }
      goto code_r0x00024178;
    }
  }
  else {
    func_0x0003ff8c();
    val = (int8)in_x1 + *(int8 *)(*in_x1 + -0x18);
    if (in_w2 == '\0') goto code_r0x00024198;
  }
code_r0x00024154:
  if (*(int4 *)(val + 0x20) == 0) {
code_r0x0002415c:
    *in_x0 = 1;
    return 1;
  }
code_r0x00024178:
}