uint64_t __cxa_guard_acquire(void)

{
  int4 val;
  char cVar2;
  bool bVar3;
  int4 *in_x0;
  uint64_t ret;
  int8 *param1;
  
  if (__google_potentially_blocking_region_begin != 0) {
    __google_potentially_blocking_region_begin();
  }
  if ((char)*in_x0 == '\0') {
    if (pthread_create != 0) {
code_r0x0001ce54:
      val = *in_x0;
      if (val == 0) goto code_r0x0001ce60;
      goto code_r0x0001ce68;
    }
    if ((char)*in_x0 == '\0') {
      if (*(char *)((int8)in_x0 + 1) != '\0') {
        param1 = __cxa_allocate_exception(8);
        *param1 = _ZTVN9__gnu_cxx20recursive_init_errorE + 0x10;
        __cxa_throw(param1,pvRam00000000000bfa28,pvRam00000000000bfef0);
      }
      ret = 1;
      *(uint8_t *)((int8)in_x0 + 1) = 1;
      goto code_r0x0001ce80;
    }
  }
code_r0x0001ce7c:
  ret = 0;
code_r0x0001ce80:
  if (__google_potentially_blocking_region_end != 0) {
    __google_potentially_blocking_region_end();
  }
  return ret;
code_r0x0001ce60:
  cVar2 = '\x01';
  bVar3 = (bool)ExclusiveMonitorPass(in_x0,0x10);
  if (bVar3) {
    *in_x0 = 0x100;
    cVar2 = ExclusiveMonitorsStatus();
  }
  if (cVar2 == '\0') {
code_r0x0001ce68:
    if (val == 0) {
      ret = 1;
      goto code_r0x0001ce80;
    }
    if (val != 1) {
      if (val == 0x100) {
        do {
          val = *in_x0;
          if (val != 0x100) break;
          cVar2 = '\x01';
          bVar3 = (bool)ExclusiveMonitorPass(in_x0,0x10);
          if (bVar3) {
            *in_x0 = 0x10100;
            cVar2 = ExclusiveMonitorsStatus();
          }
        } while (cVar2 != '\0');
        if (val != 0x100) {
          if (val == 1) goto code_r0x0001ce7c;
          if (val == 0) goto code_r0x0001ce54;
        }
      }
      syscall(0x62);
      goto code_r0x0001ce54;
    }
    goto code_r0x0001ce7c;
  }
  goto code_r0x0001ce54;
}