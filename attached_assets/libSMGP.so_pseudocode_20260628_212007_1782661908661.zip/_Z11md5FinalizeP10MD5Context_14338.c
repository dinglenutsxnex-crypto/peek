uint64_t _Z11md5FinalizeP10MD5Context(void)

{
  uint4 val1;
  uint32_t val2;
  uint32_t val3;
  uint32_t val4;

  unkuint3 Var6;
  uint8 *in_x0;

  uint4 val5;
  int8 val6;
  uint8 val7;
  int4 val8;
  uint8 val9;
  uint8_t *pxVar13;
  uint8 val10;
  uint64_t xStack_90;
  uint8 uStack_88;

  uint8 uStack_78;

  uint8 uStack_68;

  val8 = 0x38;
  val5 = (uint4)*in_x0 & 0x3f;
  if (0x37 < val5) {
    val8 = 0x78;
  }
  val9 = (uint8)(val8 - val5);
  val7 = *in_x0 + val9;
  *in_x0 = val7;
  if (val8 - val5 != 0) {
    pxVar13 = (uint8_t *)0x84d28;
    val7 = val9;
    do {
      val1 = val5 + 1;
      *(uint8_t *)((int8)in_x0 + (uint8)val5 + 0x18) = *pxVar13;
      val5 = val1;
      if ((val1 & 0x3f) == 0) {
        uStack_88 = in_x0[4];
        val10 = in_x0[3];
        Var6 = CONCAT12((char)(val10 >> 0x20),(int2)val10) & 0xff00ff;
        xStack_90 = CONCAT17((char)(val10 >> 0x38),
                             CONCAT16((char)(val10 >> 0x30),
                                      CONCAT15((char)(val10 >> 0x28),
                                               CONCAT14((char)(Var6 >> 0x10),
                                                        CONCAT13((char)(val10 >> 0x18),
                                                                 CONCAT12((char)(val10 >> 0x10),
                                                                          CONCAT11((char)(val10 >>
                                                                                         8),(char)
                                                  Var6)))))));
        uStack_78 = in_x0[6];
        val10 = in_x0[5];
        Var6 = CONCAT12((char)(val10 >> 0x20),(int2)val10) & 0xff00ff;
        xStack_90 = CONCAT17((char)(val10 >> 0x38),
                             CONCAT16((char)(val10 >> 0x30),
                                      CONCAT15((char)(val10 >> 0x28),
                                               CONCAT14((char)(Var6 >> 0x10),
                                                        CONCAT13((char)(val10 >> 0x18),
                                                                 CONCAT12((char)(val10 >> 0x10),
                                                                          CONCAT11((char)(val10 >>
                                                                                         8),(char)
                                                  Var6)))))));
        uStack_68 = in_x0[8];
        val10 = in_x0[7];
        Var6 = CONCAT12((char)(val10 >> 0x20),(int2)val10) & 0xff00ff;
        xStack_90 = CONCAT17((char)(val10 >> 0x38),
                             CONCAT16((char)(val10 >> 0x30),
                                      CONCAT15((char)(val10 >> 0x28),
                                               CONCAT14((char)(Var6 >> 0x10),
                                                        CONCAT13((char)(val10 >> 0x18),
                                                                 CONCAT12((char)(val10 >> 0x10),
                                                                          CONCAT11((char)(val10 >>
                                                                                         8),(char)
                                                  Var6)))))));
        xStack_90 = in_x0[10];
        val10 = in_x0[9];
        Var6 = CONCAT12((char)(val10 >> 0x20),(int2)val10) & 0xff00ff;
        xStack_90 = CONCAT17((char)(val10 >> 0x38),
                             CONCAT16((char)(val10 >> 0x30),
                                      CONCAT15((char)(val10 >> 0x28),
                                               CONCAT14((char)(Var6 >> 0x10),
                                                        CONCAT13((char)(val10 >> 0x18),
                                                                 CONCAT12((char)(val10 >> 0x10),
                                                                          CONCAT11((char)(val10 >>
                                                                                         8),(char)
                                                  Var6)))))));
        _Z7md5StepPjS_(in_x0 + 1,&xStack_90);
        val5 = 0;
      }
      val7 = val7 - 1;
      pxVar13 = pxVar13 + 1;
    } while (val7 != 0);
    val7 = *in_x0;
  }
  val7 = val7 - val9;
  val6 = 0;
  *in_x0 = val7;
  do {
    *(uint32_t *)((int8)&xStack_90 + val6) = *(uint32_t *)((int8)in_x0 + val6 + 0x18);
    val6 = val6 + 4;
  } while (val6 != 0x38);
  xStack_90 = CONCAT44((int4)(val7 >> 0x1d),(int4)val7 << 3);
  val4 = _Z7md5StepPjS_(in_x0 + 1,&xStack_90);
  val2 = (uint32_t)in_x0[1];
  val3 = *(uint32_t *)((int8)in_x0 + 0xc);
  *(char *)(in_x0 + 0xb) = (char)val2;
  *(char *)((int8)in_x0 + 0x59) = (char)((uint4)val2 >> 8);
  *(char *)((int8)in_x0 + 0x5a) = (char)((uint4)val2 >> 0x10);
  *(char *)((int8)in_x0 + 0x5b) = (char)((uint4)val2 >> 0x18);
  *(char *)((int8)in_x0 + 0x5d) = (char)((uint4)val3 >> 8);
  *(char *)((int8)in_x0 + 0x5e) = (char)((uint4)val3 >> 0x10);
  val2 = (uint32_t)in_x0[2];
  val4 = *(uint32_t *)((int8)in_x0 + 0x14);
  *(char *)((int8)in_x0 + 0x5c) = (char)val3;
  *(char *)((int8)in_x0 + 0x5f) = (char)((uint4)val3 >> 0x18);
  *(char *)((int8)in_x0 + 0x61) = (char)((uint4)val2 >> 8);
  *(char *)(in_x0 + 0xc) = (char)val2;
  *(char *)((int8)in_x0 + 99) = (char)((uint4)val2 >> 0x18);
  *(char *)((int8)in_x0 + 0x62) = (char)((uint4)val2 >> 0x10);
  *(char *)((int8)in_x0 + 0x65) = (char)((uint4)val4 >> 8);
  *(char *)((int8)in_x0 + 100) = (char)val4;
  *(char *)((int8)in_x0 + 0x66) = (char)((uint4)val4 >> 0x10);
  *(char *)((int8)in_x0 + 0x67) = (char)((uint4)val4 >> 0x18);

  __stack_chk_fail();
}