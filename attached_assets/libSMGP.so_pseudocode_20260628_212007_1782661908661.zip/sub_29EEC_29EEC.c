uint64_t sub_29EEC(void)

{
  int8 *env;
  uint64_t in_x8;
  
  (*env)->GetVersion();
  return in_x8;
}