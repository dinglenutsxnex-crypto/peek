uint64_t sub_29108(void)

{
  uint64_t *in_x0;
  uint64_t extraout_x0;
  
  *in_x0 = 0xbaa70;
  func_0x000397cc();
  _ZdlPv(in_x0);
  return extraout_x0;
}