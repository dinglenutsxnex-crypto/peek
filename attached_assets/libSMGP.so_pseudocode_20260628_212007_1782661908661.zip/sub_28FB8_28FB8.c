uint64_t sub_28FB8(void)

{
  uint64_t *in_x0;
  uint64_t extraout_x0;
  
  *in_x0 = 0xba760;
  func_0x0003d1d4();
  _ZdlPv(in_x0);
  return extraout_x0;
}