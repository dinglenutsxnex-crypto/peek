uint64_t sub_28E8C(void)

{
  void *in_x0;
  uint64_t extraout_x0;
  
  sub_28D6C();
  _ZdlPv(in_x0);
  return extraout_x0;
}