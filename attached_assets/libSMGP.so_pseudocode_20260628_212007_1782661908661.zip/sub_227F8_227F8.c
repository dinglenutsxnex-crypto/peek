uint64_t sub_227F8(void)

{
  jclass cls;
  int8 *in_x0;
  int8 *env;
  char cStack_8;
  
  sub_21204();
  if ((cStack_8 != '\0') &&
     (env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8), env != (int8 *)0x0)) {
    cls = (*env)->FindClass();
    if (cls != -1) {
      return 0;
    }
    sub_1ED34();
    return JNI_ERR;
  }
  return JNI_ERR;
}