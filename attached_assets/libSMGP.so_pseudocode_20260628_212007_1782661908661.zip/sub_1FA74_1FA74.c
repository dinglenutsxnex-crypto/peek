uint64_t sub_1FA74(void)

{
  int8 in_x0;
  uint64_t ret;

  if (*(int8 **)(in_x0 + 0xf0) != (int8 *)0x0) {
    ret = (**(code **)(**(int8 **)(in_x0 + 0xf0) + 0x50))();
    return ret;
  }
  func_0x00061e30(0,in_w1);
}