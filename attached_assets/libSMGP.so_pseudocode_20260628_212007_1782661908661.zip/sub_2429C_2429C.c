int8 * sub_2429C(void)

{
  int8 *in_x0;
  int8 *piVar1;
  void *param1;
  int8 val;

  uint16_t *in_x1;
  uint8_t axVar4 [16];
  char cStack_10;
  uint4 uStack_c;
  int8 iStack_8;

  sub_24104();
  if (cStack_10 != '\0') {
    uStack_c = 0;
    val = (int8)in_x0 + *(int8 *)(*in_x0 + -0x18);
    piVar1 = *(int8 **)(val + 0x100);
    if (piVar1 == (int8 *)0x0) {
      axVar4 = func_0x00061e30();
      param1 = axVar4._0_8_;
      if (axVar4._8_8_ == 1) {
        __cxa_begin_catch(param1);
        in_x0 = (int8 *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18));
        *(uint4 *)(in_x0 + 4) = *(uint4 *)(in_x0 + 4) | 1;
        if ((*(uint4 *)((int8)in_x0 + 0x1c) & 1) == 0) {
          __cxa_rethrow();
          goto code_r0x00024410;
        }
        param1 = (void *)__cxa_rethrow();
      }
      __cxa_begin_catch(param1);
      val = *(int8 *)(*in_x0 + -0x18);
      *(uint4 *)((int8)in_x0 + val + 0x20) = *(uint4 *)((int8)in_x0 + val + 0x20) | 1;
      if ((*(uint4 *)((int8)in_x0 + val + 0x1c) & 1) != 0) {
code_r0x00024410:
        in_x1 = __cxa_rethrow();
        __cxa_end_catch();
        func_0x00081f98(xVar3);
      }
      __cxa_end_catch();
    }
    else {
      (**(code **)(*piVar1 + 0x18))
                (piVar1,*(uint64_t *)(val + 0xe8),0xffffffff,0,0xffffffff,val,&uStack_c,
                 &iStack_8);
      if (iStack_8 < -0x8000) {
        *in_x1 = 0x8000;
        uStack_c = uStack_c | 4;
      }
      else {
        if (0x7fff < iStack_8) {
          *in_x1 = 0x7fff;
          uStack_c = uStack_c | 4;
          if (uStack_c == 0) {
            return in_x0;
          }
          goto code_r0x00024358;
        }
        *in_x1 = (int2)iStack_8;
      }
    }
    if (uStack_c != 0) {
code_r0x00024358:
      sub_1F6E0();
      return in_x0;
    }
  }
  return in_x0;
}