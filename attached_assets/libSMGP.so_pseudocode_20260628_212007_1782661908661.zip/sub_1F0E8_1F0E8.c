uint8 sub_1F0E8(void)

{
  uint1 val1;
  int8 in_x0;
  uint8 ret;
  uint1 in_w1;
  uint1 in_w2;
  int8 *env;
  
  env = *(int8 **)(in_x0 + 0xf0);
  if (env == (int8 *)0x0) {
    func_0x00061e30();
  }
  val1 = *(uint1 *)((int8)env + (int8)(int4)(uint4)in_w1 + 0x139);
  ret = (uint8)val1;
  if (val1 == 0) {
    val1 = (*env)->FromReflectedField(env,in_w1,in_w2);
    if ((uint4)in_w2 != (uint4)val1) {
      *(uint1 *)((int8)env + (int8)(int4)(uint4)in_w1 + 0x139) = val1;
      return (uint8)(uint4)val1;
    }
    ret = (uint8)(uint4)in_w2;
  }
  return ret;
}