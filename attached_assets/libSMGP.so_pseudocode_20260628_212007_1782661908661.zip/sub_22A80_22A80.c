int8 * sub_22A80(void)

{
  int8 *in_x0;
  int8 val;
  int8 *env;
  char cStack_8;
  
  sub_1ED34();
  sub_21204();
  if (((cStack_8 != '\0') && ((*(uint4 *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x20) & 5) == 0)
      ) && (env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8),
           val = (*env)->DefineClass(env), val == -1)) {
    sub_1ED34();
    return in_x0;
  }
  return in_x0;
}