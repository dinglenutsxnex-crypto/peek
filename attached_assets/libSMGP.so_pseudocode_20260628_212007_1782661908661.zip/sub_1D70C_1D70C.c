uint64_t sub_1D70C(void)

{
  int8 *in_x0;
  char *param2;
  void *pvVar1;
  char *in_x1;
  uint32_t in_w2;
  
  param2 = (char *)func_0x0001d440(in_w2);
  if ((param2 != (char *)0x0) && (*in_x0 == 0)) {
    pvVar1 = fopen(in_x1,param2);
    *in_x0 = (int8)pvVar1;
    if (pvVar1 != (void *)0x0) {
      *(uint8_t *)(in_x0 + 1) = 1;
      return in_x0;
    }
  }
  return 0;
}