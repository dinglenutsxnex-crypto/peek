uint8 sub_1E9D4(void)

{
  char cVar1;
  int8 *in_x0;
  uint8 in_x2;
  uint8 in_x3;
  
  if (in_x2 < in_x3) {
    while (cVar1 = (**(code **)(*in_x0 + 0x10))(), cVar1 != '\0') {
      in_x2 = in_x2 + 4;
      if (in_x3 <= in_x2) {
        return in_x2;
      }
    }
  }
  return in_x2;
}