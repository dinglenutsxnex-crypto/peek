void sub_29C78(int8 *param_1)

{
  (**(code **)(*param_1 + 0x10))();
  return;
}