int8 * sub_27CE0(void)

{
  uint8 val1;
  uint8 val2;
  uint4 val3;
  jobject obj;
  jclass cls;
  int8 *in_x0;
  void *pvVar6;
  int8 val4;
  uint1 *puVar8;
  int8 *in_x1;
  int8 val5;
  uint1 *puVar10;
  uint1 in_w2;
  int8 *env;
  uint8 val6;
  void *param1;
  char cStack_8;
  
  sub_21204();
  if (cStack_8 != '\0') {
    func_0x00065820();
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if ((uint1 *)env[2] < (uint1 *)env[3]) {
      obj = (uint4)*(uint1 *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod(env);
    }
    val6 = 0;
    do {
      while( true ) {
        val3 = obj;
        if ((obj == JNI_ERR) || (in_w2 == obj)) goto joined_r0x00027ed0;
        param1 = (void *)env[2];
        val1 = 0x3ffffffffffffff9 - val6;
        if (env[3] - (int8)param1 < (int8)(0x3ffffffffffffff9 - val6)) {
          val1 = env[3] - (int8)param1;
        }
        if ((int8)val1 < 2) break;
        pvVar6 = memchr(param1,(uint4)in_w2,val1);
        val2 = (int8)pvVar6 - (int8)param1;
        if (pvVar6 == (void *)0x0) {
          val2 = val1;
        }
        func_0x0006433c();
        val4 = env[2];
        val6 = val6 + val2;
        val1 = val4 + val2;
        env[2] = val1;
        if (val1 < (uint8)env[3]) {
          obj = (uint4)*(uint1 *)(val4 + val2);
        }
        else {
code_r0x00027f04:
          obj = (*env)->ToReflectedMethod(env);
        }
code_r0x00027df8:
        val3 = obj;
        if (0x3ffffffffffffff8 < val6) goto joined_r0x00027ed0;
      }
      val5 = *in_x1;
      val4 = *(int8 *)(val5 + -0x18);
      val1 = val4 + 1;
      if ((*(uint8 *)(val5 + -0x10) < val1) || (0 < *(int4 *)(val5 + -8))) {
        func_0x00063bf0();
        val5 = *in_x1;
        val4 = *(int8 *)(val5 + -0x18);
      }
      *(char *)(val5 + val4) = (char)obj;
      val4 = *in_x1;
      if (val4 + -0x18 != unk_bff48) {
        *(uint32_t *)(val4 + -8) = 0;
        *(uint8 *)(val4 + -0x18) = val1;
        *(uint8_t *)(val4 + val1) = 0;
      }
      val6 = val6 + 1;
      puVar10 = (uint1 *)env[3];
      if ((uint1 *)env[2] < puVar10) {
        puVar8 = (uint1 *)env[2] + 1;
        env[2] = (int8)puVar8;
      }
      else {
        cls = (*env)->GetSuperclass(env);
        obj = JNI_ERR;
        if (cls == -1) goto code_r0x00027df8;
        puVar8 = (uint1 *)env[2];
        puVar10 = (uint1 *)env[3];
      }
      if (puVar10 <= puVar8) goto code_r0x00027f04;
      obj = (uint4)*puVar8;
      val3 = (uint4)*puVar8;
    } while (val6 < 0x3ffffffffffffff9);
joined_r0x00027ed0:
    if ((val3 != JNI_ERR) && (in_w2 == val3)) {
      if ((uint8)env[2] < (uint8)env[3]) {
        env[2] = env[2] + 1;
      }
      else {
        (*env)->GetSuperclass(env);
      }
      if (val6 != 0xffffffffffffffff) {
        return in_x0;
      }
    }
  }
  sub_1ED34();
  return in_x0;
}