int8 * sub_25500(void)

{
  jboolean val1;
  int8 *in_x0;
  int8 *env;
  uint8 val2;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_1F6E0();
  sub_24104();
  if (cStack_8 == '\0') {
    return in_x0;
  }
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  if (env != (int8 *)0x0) {
    val2 = env[2];
    if ((uint8)env[1] < val2) {
      val1 = *(int4 *)(val2 - 4);
      env[2] = val2 - 4;
    }
    else {
      val1 = (*env)->IsAssignableFrom(env,JNI_ERR);
    }
    if (val1 != -1) {
      return in_x0;
    }
  }
  sub_1F6E0();
  return in_x0;
}