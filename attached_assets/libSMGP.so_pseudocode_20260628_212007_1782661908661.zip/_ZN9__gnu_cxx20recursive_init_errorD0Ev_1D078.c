uint64_t _ZN9__gnu_cxx20recursive_init_errorD0Ev(void)

{
  void *in_x0;
  uint64_t extraout_x0;
  
  _ZN9__gnu_cxx20recursive_init_errorD1Ev();
  _ZdlPv(in_x0);
  return extraout_x0;
}