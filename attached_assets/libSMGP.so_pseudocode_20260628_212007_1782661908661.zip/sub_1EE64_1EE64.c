uint8 sub_1EE64(void)

{
  uint64_t *pxVar1;
  char cVar2;
  uint64_t *in_x0;
  uint64_t val;
  int8 in_x1;
  
  func_0x0001ff5c();
  in_x0[0x1b] = 0;
  *in_x0 = 0xba5c0;
  pxVar1 = in_x0 + 0x1a;
  *(uint8_t *)(in_x0 + 0x1c) = 0;
  *(uint8_t *)((int8)in_x0 + 0xe1) = 0;
  in_x0[0x1d] = 0;
  in_x0[0x1e] = 0;
  in_x0[0x1f] = 0;
  in_x0[0x20] = 0;
  func_0x00020d7c();
  cVar2 = func_0x0002d0b8(pxVar1);
  if (cVar2 == '\0') {
    in_x0[0x1e] = 0;
    cVar2 = func_0x0002d268(pxVar1);
  }
  else {
    val = func_0x0002b34c(pxVar1);
    in_x0[0x1e] = val;
    cVar2 = func_0x0002d268(pxVar1);
  }
  if (cVar2 == '\0') {
    in_x0[0x1f] = 0;
    cVar2 = func_0x0002d2d4(pxVar1);
  }
  else {
    val = func_0x0002c17c(pxVar1);
    in_x0[0x1f] = val;
    cVar2 = func_0x0002d2d4(pxVar1);
  }
  if (cVar2 == '\0') {
    in_x0[0x20] = 0;
  }
  else {
    val = func_0x0002c1e4(pxVar1);
    in_x0[0x20] = val;
  }
  *(uint8_t *)(in_x0 + 0x1c) = 0;
  in_x0[0x1d] = in_x1;
  *(uint8_t *)((int8)in_x0 + 0xe1) = 0;
  in_x0[0x1b] = 0;
  *(uint32_t *)((int8)in_x0 + 0x1c) = 0;
  *(uint4 *)(in_x0 + 4) = (uint4)(in_x1 == 0);
  return (uint8)(in_x1 == 0);
}