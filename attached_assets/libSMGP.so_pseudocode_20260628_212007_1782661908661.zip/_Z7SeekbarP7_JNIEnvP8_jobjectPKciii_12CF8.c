uint64_t _Z7SeekbarP7_JNIEnvP8_jobjectPKciii(void)

{
  int8 *env;
  uint64_t ret;
  
  (*env)->GetObjectClass();
  (*env)->GetMethodID();
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  ret = _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}