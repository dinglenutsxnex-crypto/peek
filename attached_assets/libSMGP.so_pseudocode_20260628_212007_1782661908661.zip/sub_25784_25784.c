uint64_t sub_25784(void)

{
  int8 *in_x0;

  int8 *env;
  char cStack_8;

  sub_24104();
  if ((cStack_8 == '\0') || ((*(uint4 *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x20) & 5) != 0))
  {
    cStack_8 = 0xffffffffffffffff;
  }
  else {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    cStack_8 = (*env)->GetVersion(env,0,1,8);
  }

}