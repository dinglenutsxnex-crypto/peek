uint64_t sub_290A8(void)

{
  uint64_t *in_x0;
  uint64_t extraout_x0;
  
  *in_x0 = 0xbaa10;
  func_0x000397cc();
  _ZdlPv(in_x0);
  return extraout_x0;
}