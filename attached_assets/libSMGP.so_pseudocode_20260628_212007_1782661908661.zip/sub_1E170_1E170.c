uint64_t sub_1E170(void)

{
  uint64_t *in_x0;
  uint64_t val;
  int8 in_x1;
  
  *(uint4 *)(in_x0 + 1) = (uint4)(in_x1 != 0);
  *in_x0 = 0xbcc00;
  val = func_0x00039ed0();
  in_x0[2] = val;
  *(uint8_t *)(in_x0 + 3) = 0;
}