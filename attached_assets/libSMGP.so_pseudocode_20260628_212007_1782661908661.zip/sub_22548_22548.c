int8 * sub_22548(void)

{
  jboolean val1;
  int8 *in_x0;
  int8 *env;
  char in_w1;
  uint8 val2;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_1ED34();
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if (env != (int8 *)0x0) {
      val2 = env[2];
      if (((uint8)env[1] < val2) && (*(char *)(val2 - 1) == in_w1)) {
        env[2] = val2 - 1;
        return in_x0;
      }
      val1 = (*env)->IsAssignableFrom(env,in_w1);
      if (val1 != -1) {
        return in_x0;
      }
    }
    sub_1ED34();
  }
  return in_x0;
}