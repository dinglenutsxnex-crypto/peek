int8 sub_1D8FC(void)

{
  int8 val1;
  int8 val2;
  int4 val3;
  uint8_t *pxVar4;
  int8 val4;
  int4 *piVar6;
  int8 in_x1;
  int8 in_x2;
  int8 in_x4;
  int8 val5;
  int8 iStack_20;
  int8 iStack_18;
  
  val1 = in_x2 + in_x4;
  pxVar4 = sub_1D788();
  val5 = val1;
  do {
    while( true ) {
      iStack_20 = in_x1;
      iStack_18 = in_x2;
      val3 = writev((uint8)pxVar4 & 0xffffffff,&iStack_20,2);
      val4 = (int8)val3;
      if (val4 == -1) break;
      val5 = val5 - val4;
      in_x1 = in_x1 + val4;
      if (val5 == 0) goto code_r0x0001d9bc;
      val2 = val4 - in_x2;
      in_x2 = in_x2 - val4;
      if (-1 < val2) {
        pxVar4 = sub_1D504();
        return val1 - (val5 - (int8)pxVar4);
      }
    }
    piVar6 = (int4 *)__errno();
  } while (*piVar6 == 4);
code_r0x0001d9bc:
  return val1 - val5;
}