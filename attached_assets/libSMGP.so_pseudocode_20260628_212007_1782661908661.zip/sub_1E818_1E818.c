uint64_t sub_1E818(void)

{
  uint1 val1;
  int4 val2;
  int8 in_x0;
  uint1 in_w1;
  uint32_t in_w2;
  uint1 *puVar3;
  uint64_t *pxVar4;
  
  puVar3 = (uint1 *)(in_x0 + 0x49c);
  pxVar4 = (uint64_t *)(in_x0 + 0x4b0);
  while ((val1 = *puVar3, puVar3 = puVar3 + 1, (in_w1 & val1) == 0 ||
         (val2 = iswctype(in_w2,*pxVar4), val2 == 0))) {
    pxVar4 = pxVar4 + 1;
    if (puVar3 == (uint1 *)(in_x0 + 0x4ac)) {
      return 0;
    }
  }
  return 1;
}