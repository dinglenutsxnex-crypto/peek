int8 sub_1ED34(void)

{
  uint4 val;
  int8 in_x0;
  uint4 in_w1;
  
  val = in_w1 | 1;
  if (*(int8 *)(in_x0 + 0xe8) != 0) {
    val = in_w1;
  }
  *(uint4 *)(in_x0 + 0x20) = val;
  if ((val & *(uint4 *)(in_x0 + 0x1c)) == 0) {
    return in_x0;
  }
  func_0x00062640("basic_ios::clear");
}