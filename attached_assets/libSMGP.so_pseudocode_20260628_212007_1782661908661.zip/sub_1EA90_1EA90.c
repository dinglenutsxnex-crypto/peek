uint8 sub_1EA90(void)

{
  uint4 val1;
  uint4 val2;
  int8 in_x0;
  uint4 in_w1;
  uint1 in_w2;
  
  if ((in_w1 < 0x80) && (*(char *)(in_x0 + 0x18) != '\0')) {
    return (uint8)*(uint1 *)(in_x0 + (uint8)in_w1 + 0x19);
  }
  val1 = wctob(in_w1);
  val2 = val1 & 0xff;
  if (val1 == 0xffffffff) {
    val2 = (uint4)in_w2;
  }
  return (uint8)val2;
}