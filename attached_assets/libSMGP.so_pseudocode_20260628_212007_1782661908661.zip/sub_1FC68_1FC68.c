uint64_t sub_1FC68(void)

{
  int8 in_x0;
  uint64_t in_x8;
  int8 *piVar1;
  uint8_t axStack_8 [8];
  
  func_0x0003989c();
  func_0x00020dcc(axStack_8);
  func_0x0003a188(axStack_8);
  sub_1FBBC();
  piVar1 = *(int8 **)(in_x0 + 0xe8);
  if (piVar1 != (int8 *)0x0) {
    func_0x0003989c(axStack_8,piVar1 + 7);
    (**(code **)(*piVar1 + 0x10))(piVar1);
    func_0x0003a0e8(piVar1 + 7);
    func_0x0003a188(axStack_8);
  }
  return in_x8;
}