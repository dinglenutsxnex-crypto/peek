uint64_t sub_1D8BC(void)

{

  fileno(*in_x0);
}