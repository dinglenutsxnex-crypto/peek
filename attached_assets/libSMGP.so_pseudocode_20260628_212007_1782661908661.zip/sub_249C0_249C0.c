int8 * sub_249C0(void)

{
  bool bVar1;
  jobject obj;
  int8 *in_x0;
  int4 *piVar3;
  int4 *in_x1;
  int4 *piVar4;
  int8 in_x2;
  int4 in_w3;
  int8 val;
  int4 *piVar6;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_24104();
  if (cStack_8 == '\0') {
    val = in_x0[1];
    bVar1 = false;
  }
  else {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    piVar3 = (int4 *)env[2];
    if ((int4 *)env[3] <= piVar3) goto code_r0x00024a84;
code_r0x00024a20:
    obj = *piVar3;
    while (val = in_x0[1], piVar3 = in_x1, obj != -1 && in_w3 != obj) {
      while( true ) {
        in_x1 = piVar3;
        if (in_x2 <= val + 1) goto code_r0x00024ab4;
        piVar4 = (int4 *)env[2];
        piVar6 = (int4 *)env[3];
        in_x1 = piVar3 + 1;
        *piVar3 = obj;
        in_x0[1] = val + 1;
        if (piVar4 < piVar6) {
          obj = *piVar4;
          env[2] = (int8)(piVar4 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj == -1) break;
        piVar3 = (int4 *)env[2];
        if (piVar3 < (int4 *)env[3]) goto code_r0x00024a20;
code_r0x00024a84:
        obj = (*env)->ToReflectedMethod(env);
        val = in_x0[1];
        piVar3 = in_x1;
        if (obj == -1 || in_w3 == obj) goto code_r0x00024ab4;
      }
    }
code_r0x00024ab4:
    bVar1 = obj == -1;
  }
  if (0 < in_x2) {
    *in_x1 = 0;
  }
  if ((val != 0) && (!bVar1)) {
    return in_x0;
  }
  sub_1F6E0();
  return in_x0;
}