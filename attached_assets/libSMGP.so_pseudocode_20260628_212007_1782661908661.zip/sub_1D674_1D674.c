uint64_t sub_1D674(void)

{
  int8 *in_x0;
  int8 val;
  int4 in_w1;
  uint32_t in_w2;
  
  val = func_0x0001d440(in_w2);
  if ((val != 0) && (*in_x0 == 0)) {
    val = fdopen(in_w1,val);
    *in_x0 = val;
    if (val != 0) {
      *(uint8_t *)(in_x0 + 1) = 1;
      if (in_w1 != 0) {
        return in_x0;
      }
      setvbuf(val,0,2,0);
      return in_x0;
    }
  }
  return 0;
}