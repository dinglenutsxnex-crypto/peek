uint64_t _Z5ToastP7_JNIEnvP8_jobjectPKci(void)

{
  int8 *env;
  uint64_t ret;
  
  (*env)->NewStringUTF();
  (*env)->FindClass();
  (*env)->GetStaticMethodID();
  _ZN7_JNIEnv22CallStaticObjectMethodEP7_jclassP10_jmethodIDz();
  (*env)->GetMethodID();
  ret = _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}