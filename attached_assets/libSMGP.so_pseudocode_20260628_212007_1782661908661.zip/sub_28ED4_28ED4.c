uint64_t sub_28ED4(void)

{
  uint64_t *in_x0;
  uint64_t extraout_x0;
  
  *in_x0 = 0xba8d0;
  func_0x0003cbc4();
  _ZdlPv(in_x0);
  return extraout_x0;
}