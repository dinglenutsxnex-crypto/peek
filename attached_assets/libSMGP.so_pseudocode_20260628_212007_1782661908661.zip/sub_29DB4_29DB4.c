void sub_29DB4(uint64_t *param_1,int8 param_2)

{
  *(uint4 *)(param_1 + 1) = (uint4)(param_2 != 0);
  *param_1 = 0xbd1d0;
  param_1[2] = 0;
  func_0x0003c7f4(param_1,0,0);
  return;
}