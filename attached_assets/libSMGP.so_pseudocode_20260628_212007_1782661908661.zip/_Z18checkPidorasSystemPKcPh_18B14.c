uint8 _Z18checkPidorasSystemPKcPh(void)

{

  int4 val1;
  char *in_x0;
  void *param1;
  uint8 val2;
  void *in_x1;
  uint8_t axStack_48 [16];




  param1 = fopen(in_x0,(char *)"rb");
  if (param1 == (void *)0x0) {
    perror("fopen");
    val2 = 0;
  }
  else {
    _Z7md5FileP7__sFILEPh(param1,axStack_48);
    fclose(param1);
    val1 = memcmp(axStack_48,in_x1,0x10);
    val2 = (uint8)(val1 == 0);
  }



  __stack_chk_fail();
}