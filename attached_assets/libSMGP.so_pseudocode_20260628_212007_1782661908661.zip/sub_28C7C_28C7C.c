uint64_t sub_28C7C(void)

{
  uint64_t in_x8;
  
  func_0x00063720();
  return in_x8;
}