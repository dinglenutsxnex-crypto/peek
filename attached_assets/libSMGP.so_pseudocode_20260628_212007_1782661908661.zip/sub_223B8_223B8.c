int8 sub_223B8(void)

{
  int8 *in_x0;
  int8 *env;
  int8 ret;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    ret = env[3] - env[2];
    if (ret == 0) {
      ret = (*env)->FromReflectedMethod();
    }
    if (0 < ret) {
      env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
      ret = (*env)->FromReflectedField(env);
      in_x0[1] = ret;
      return ret;
    }
    if (ret == -1) {
      sub_1ED34();
      return in_x0[1];
    }
  }
  return in_x0[1];
}