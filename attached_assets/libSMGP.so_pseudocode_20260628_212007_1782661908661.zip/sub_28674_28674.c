int8 * sub_28674(void)

{
  uint8 val1;
  jclass cls;
  int8 *in_x0;
  int4 *piVar3;
  int8 *in_x1;
  int8 val2;
  int8 val3;
  int4 in_w2;
  int4 *piVar6;
  int8 *env;
  uint8 val4;
  char cStack_8;
  
  sub_24104();
  if (cStack_8 != '\0') {
    func_0x00069974();
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if ((int4 *)env[2] < (int4 *)env[3]) {
      cls = *(int4 *)env[2];
    }
    else {
      cls = (*env)->ToReflectedMethod(env);
    }
    val4 = 0;
    do {
      while( true ) {
        if ((cls == -1) || (in_w2 == cls)) goto joined_r0x00028878;
        piVar6 = (int4 *)env[3];
        piVar3 = (int4 *)env[2];
        val2 = (int8)piVar6 - (int8)piVar3 >> 2;
        val3 = 0xffffffffffffffe - val4;
        if (val2 < (int8)(0xffffffffffffffe - val4)) {
          val3 = val2;
        }
        if (val3 < 2) break;
        val2 = wmemchr(piVar3,in_w2,val3);
        if (val2 != 0) {
          val3 = val2 - env[2] >> 2;
        }
        func_0x0006ba98();
        val2 = env[2];
        val4 = val4 + val3;
        val1 = val2 + val3 * 4;
        env[2] = val1;
        if (val1 < (uint8)env[3]) {
          cls = *(int4 *)(val2 + val3 * 4);
        }
        else {
code_r0x000288ac:
          cls = (*env)->ToReflectedMethod(env);
        }
code_r0x00028788:
        if (0xffffffffffffffd < val4) goto joined_r0x00028878;
      }
      val3 = *in_x1;
      val2 = *(int8 *)(val3 + -0x18);
      val1 = val2 + 1;
      if ((*(uint8 *)(val3 + -0x10) < val1) || (0 < *(int4 *)(val3 + -8))) {
        func_0x0006b63c();
        val3 = *in_x1;
        piVar3 = (int4 *)env[2];
        piVar6 = (int4 *)env[3];
        val2 = *(int8 *)(val3 + -0x18);
      }
      *(int4 *)(val3 + val2 * 4) = cls;
      if ((uint8 *)(val3 + -0x18) != puRam00000000000bfb98) {
        *(uint32_t *)(val3 + -8) = 0;
        *(uint8 *)(val3 + -0x18) = val1;
        *(uint32_t *)(val3 + val1 * 4) = 0;
      }
      val4 = val4 + 1;
      if (piVar3 < piVar6) {
        cls = *piVar3;
        env[2] = (int8)(piVar3 + 1);
      }
      else {
        cls = (*env)->GetSuperclass(env);
      }
      if (cls == -1) goto code_r0x00028788;
      if ((int4 *)env[3] <= (int4 *)env[2]) goto code_r0x000288ac;
      cls = *(int4 *)env[2];
    } while (val4 < 0xffffffffffffffe);
joined_r0x00028878:
    if ((cls != -1) && (in_w2 == cls)) {
      if ((uint8)env[2] < (uint8)env[3]) {
        env[2] = env[2] + 4;
      }
      else {
        (*env)->GetSuperclass(env);
      }
      if (val4 != 0xffffffffffffffff) {
        return in_x0;
      }
    }
  }
  sub_1F6E0();
  return in_x0;
}