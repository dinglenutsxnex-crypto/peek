uint64_t Java_com_soham_cheat_Ui_StartOptionsDark(void)

{
  int8 *in_x0;
  uint64_t ret;
  int8 val;
  
  __android_log_print(4,(char *)"MainCpp",(char *)"StartOptionsDark called - variant=%d pkg=%s");
  if (unk_c0198 == 1) {
    (*in_x0)->FindClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    val = *in_x0;
  }
  else if (unk_c0198 == 2) {
    (*in_x0)->FindClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    val = *in_x0;
  }
  else {
    (*in_x0)->FindClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    (*in_x0)->GetMethodID();
    (*in_x0)->NewStringUTF();
    _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
    _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
    (*in_x0)->GetObjectClass();
    (*in_x0)->GetMethodID();
    val = *in_x0;
  }
  (**(code **)(val + 0x538))();
  ret = _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}