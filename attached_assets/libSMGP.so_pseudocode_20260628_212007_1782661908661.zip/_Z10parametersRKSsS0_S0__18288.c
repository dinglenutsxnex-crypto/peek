int8 _Z10parametersRKSsS0_S0_(void)

{
  uint8 val1;
  char cVar2;
  bool bVar3;

  int8 val2;
  uint64_t *in_x1;
  int4 *piVar6;
  int4 val3;
  int8 val4;
  char *pcVar9;
  int8 val5;
  int8 iStack_70;
  int8 iStack_68;
  uint8_t axStack_60 [8];




  func_0x00067090(&iStack_68,packageName);
  val2 = unk_bff48;
  iStack_70 = unk_bff48 + 0x18;
  pcVar9 = (char *)*in_x1;
  for (val5 = *(int8 *)(pcVar9 + -0x18); val5 != 0; val5 = val5 + -1) {
    cVar2 = *pcVar9;
    if (((cVar2 != ' ') && (cVar2 != 'H')) && (cVar2 != 'h')) {
      val4 = *(int8 *)(iStack_70 + -0x18);
      val1 = val4 + 1;
      if ((*(uint8 *)(iStack_70 + -0x10) < val1) || (0 < *(int4 *)(iStack_70 + -8))) {
        func_0x00063bf0(&iStack_70,val1);
        val4 = *(int8 *)(iStack_70 + -0x18);
      }
      *(char *)(iStack_70 + val4) = cVar2;
      if (iStack_70 + -0x18 != val2) {
        *(uint32_t *)(iStack_70 + -8) = 0;
        *(uint8 *)(iStack_70 + -0x18) = val1;
        *(uint8_t *)(iStack_70 + val1) = 0;
      }
    }
    pcVar9 = pcVar9 + 1;
  }
  _Z17executeparametersRKSsS0_S0_S0_();
  if (iStack_70 + -0x18 != val2) {
    piVar6 = (int4 *)(iStack_70 + -8);
    if (pthread_create == 0) {
      val3 = *piVar6;
      *piVar6 = val3 + -1;
    }
    else {
      do {
        val3 = *piVar6;
        cVar2 = '\x01';
        bVar3 = (bool)ExclusiveMonitorPass(piVar6,0x10);
        if (bVar3) {
          *piVar6 = val3 + -1;
          cVar2 = ExclusiveMonitorsStatus();
        }
      } while (cVar2 != '\0');
    }
    if (val3 < 1) {
      func_0x00066f0c(iStack_70 + -0x18,axStack_60);
    }
  }
  val5 = iStack_68 + -0x18;
  if (val5 != val2) {
    piVar6 = (int4 *)(iStack_68 + -8);
    if (pthread_create == 0) {
      val3 = *piVar6;
      *piVar6 = val3 + -1;
    }
    else {
      do {
        val3 = *piVar6;
        cVar2 = '\x01';
        bVar3 = (bool)ExclusiveMonitorPass(piVar6,0x10);
        if (bVar3) {
          *piVar6 = val3 + -1;
          cVar2 = ExclusiveMonitorsStatus();
        }
      } while (cVar2 != '\0');
    }
    if (val3 < 1) {
      val5 = func_0x00066f0c(val5,&iStack_70);
    }
  }



  __stack_chk_fail();
}