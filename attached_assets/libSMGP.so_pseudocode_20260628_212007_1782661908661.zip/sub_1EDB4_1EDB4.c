int8 sub_1EDB4(void)

{
  int8 in_x0;
  int8 val;
  uint4 in_w1;
  
  *(uint4 *)(in_x0 + 0x20) = *(uint4 *)(in_x0 + 0x20) | in_w1;
  if ((in_w1 & *(uint4 *)(in_x0 + 0x1c)) == 0) {
    return in_x0;
  }
  val = __cxa_rethrow();
  return (uint8)(*(int4 *)(val + 0x20) == 0);
}