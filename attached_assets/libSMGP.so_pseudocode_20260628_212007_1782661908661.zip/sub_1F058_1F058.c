uint8 sub_1F058(void)

{
  jclass cls;
  int8 in_x0;
  uint8_t in_w1;
  int8 *env;
  
  if (*(char *)(in_x0 + 0xe1) != '\0') {
    cls = *(uint1 *)(in_x0 + 0xe0);
    *(uint8_t *)(in_x0 + 0xe0) = in_w1;
    return (uint8)cls;
  }
  env = *(int8 **)(in_x0 + 0xf0);
  if (env != (int8 *)0x0) {
    if ((char)env[7] == '\0') {
      sub_1DFC0();
      cls = (*env)->FindClass(env,"lease)");
    }
    else {
      cls = *(uint1 *)((int8)env + 0x59);
    }
    *(uint8_t *)(in_x0 + 0xe0) = in_w1;
    *(uint8_t *)(in_x0 + 0xe1) = 1;
    return (uint8)cls;
  }
  func_0x00061e30();
}