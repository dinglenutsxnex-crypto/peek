int8 sub_1F458(void)

{
  int4 *piVar1;
  uint4 val1;
  int4 val2;
  uint32_t val3;
  uint4 val4;
  char cVar6;
  bool bVar7;
  jclass cls;
  int8 in_x0;
  void *param1;
  uint64_t *pxVar9;
  uint64_t *pxVar10;
  uint64_t *pxVar12;
  int8 in_x1;
  uint64_t *pxVar13;
  uint64_t val5;
  uint64_t val6;
  int8 *env;
  int8 ret;
  uint8_t axStack_8 [8];
  uint64_t *pxVar11;
  
  if (in_x0 == in_x1) {
    return in_x0;
  }
  val1 = *(uint4 *)(in_x1 + 0xc0);
  if ((int4)val1 < 9) {
    pxVar12 = (uint64_t *)(in_x0 + 0x40);
  }
  else {
    pxVar12 = _Znam(-(uint8)(val1 >> 0x1f) & 0xfffffff000000000 | (uint8)val1 << 4);
    val2 = *(int4 *)(in_x1 + 0xc0);
    ret = 0;
    pxVar10 = pxVar12;
    if ((int8)val2 != 0) {
      do {
        ret = ret + 1;
        *pxVar10 = 0;
        pxVar10[1] = 0;
        pxVar10 = pxVar10 + 2;
      } while (val2 != ret);
    }
  }
  ret = *(int8 *)(in_x1 + 0x28);
  if (ret != 0) {
    if (pthread_create == 0) {
      *(int4 *)(ret + 0x14) = *(int4 *)(ret + 0x14) + 1;
    }
    else {
      piVar1 = (int4 *)(ret + 0x14);
      do {
        cVar6 = '\x01';
        bVar7 = (bool)ExclusiveMonitorPass(piVar1,0x10);
        if (bVar7) {
          *piVar1 = *piVar1 + 1;
          cVar6 = ExclusiveMonitorsStatus();
        }
      } while (cVar6 != '\0');
    }
  }
  func_0x00020210();
  param1 = *(void **)(in_x0 + 200);
  if (param1 != (void *)(in_x0 + 0x40)) {
    if (param1 != (void *)0x0) {
      _ZdaPv(param1);
    }
    *(uint64_t *)(in_x0 + 200) = 0;
  }
  func_0x00020278();
  val2 = *(int4 *)(in_x1 + 0xc0);
  *(int8 *)(in_x0 + 0x28) = ret;
  if (0 < val2) {
    pxVar9 = *(uint64_t **)(in_x1 + 200);
    pxVar10 = pxVar9;
    pxVar13 = pxVar12;
    do {
      pxVar11 = pxVar10 + 2;
      val5 = pxVar10[1];
      *pxVar13 = *pxVar10;
      pxVar13[1] = val5;
      pxVar10 = pxVar11;
      pxVar13 = pxVar13 + 2;
    } while (pxVar11 != pxVar9 + ((uint8)(val2 - 1) + 1) * 2);
  }
  val3 = *(uint32_t *)(in_x1 + 0x18);
  *(uint64_t *)(in_x0 + 0x10) = *(uint64_t *)(in_x1 + 0x10);
  val5 = *(uint64_t *)(in_x1 + 0xd8);
  val6 = *(uint64_t *)(in_x1 + 8);
  cVar6 = *(char *)(in_x1 + 0xe1);
  *(uint64_t **)(in_x0 + 200) = pxVar12;
  *(int4 *)(in_x0 + 0xc0) = val2;
  *(uint32_t *)(in_x0 + 0x18) = val3;
  *(uint64_t *)(in_x0 + 8) = val6;
  *(uint64_t *)(in_x0 + 0xd8) = val5;
  if (cVar6 == '\0') {
    env = *(int8 **)(in_x1 + 0xf0);
    if (env != (int8 *)0x0) {
      if ((char)env[7] == '\0') {
        sub_1DFC0();
        cls = (*env)->FindClass(env,"lease)");
      }
      else {
        cls = *(uint8_t *)((int8)env + 0x59);
      }
      *(uint8_t *)(in_x1 + 0xe0) = cls;
      *(uint8_t *)(in_x1 + 0xe1) = 1;
      goto code_r0x0001f568;
    }
code_r0x0001f6a0:
    func_0x00061e30();
  }
  else {
    cls = *(uint8_t *)(in_x1 + 0xe0);
code_r0x0001f568:
    if (*(char *)(in_x0 + 0xe1) == '\0') {
      env = *(int8 **)(in_x0 + 0xf0);
      if (env == (int8 *)0x0) goto code_r0x0001f6a0;
      if ((char)env[7] == '\0') {
        sub_1DFC0();
        (*env)->FindClass(env,"lease)");
      }
      *(uint8_t *)(in_x0 + 0xe1) = 1;
    }
    *(uint8_t *)(in_x0 + 0xe0) = cls;
    func_0x0003989c(axStack_8,in_x1 + 0xd0);
    func_0x0003a0e8(in_x0 + 0xd0,axStack_8);
    func_0x0003a188(axStack_8);
    sub_1F2DC();
    func_0x00020210();
    val1 = *(uint4 *)(in_x1 + 0x1c);
    *(uint4 *)(in_x0 + 0x1c) = val1;
    val4 = *(uint4 *)(in_x0 + 0x20);
    if (*(int8 *)(in_x0 + 0xe8) == 0) {
      val4 = val4 | 1;
      *(uint4 *)(in_x0 + 0x20) = val4;
    }
    if ((val4 & val1) == 0) {
      return in_x0;
    }
  }
  ret = func_0x00062640("basic_ios::clear");
  if ((*(uint4 *)(ret + 0x20) & 5) != 0) {
    ret = 0;
  }
  return ret;
}