int8 * sub_24C20(void)

{
  jobject obj;
  int8 *in_x0;
  int4 *piVar2;
  int8 *in_x1;
  int4 in_w2;
  int4 *piVar3;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_24104();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    piVar2 = (int4 *)env[2];
    if ((int4 *)env[3] <= piVar2) goto code_r0x00024ce0;
code_r0x00024c78:
    obj = *piVar2;
    if (obj != -1) {
      do {
        if (obj == in_w2) break;
        piVar2 = (int4 *)in_x1[5];
        if (piVar2 < (int4 *)in_x1[6]) {
          *piVar2 = obj;
          in_x1[5] = (int8)(piVar2 + 1);
        }
        else {
          obj = (*in_x1)->Throw();
          if (obj == -1) goto code_r0x00024d04;
        }
        piVar3 = (int4 *)env[2];
        piVar2 = (int4 *)env[3];
        in_x0[1] = in_x0[1] + 1;
        if (piVar3 < piVar2) {
          obj = *piVar3;
          env[2] = (int8)(piVar3 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj != -1) {
          piVar2 = (int4 *)env[2];
          if (piVar2 < (int4 *)env[3]) goto code_r0x00024c78;
code_r0x00024ce0:
          obj = (*env)->ToReflectedMethod(env);
        }
        if (obj == -1) break;
      } while( true );
    }
    if (obj == -1) goto code_r0x00024d10;
  }
code_r0x00024d04:
  if (in_x0[1] != 0) {
    return in_x0;
  }
code_r0x00024d10:
  sub_1F6E0();
  return in_x0;
}