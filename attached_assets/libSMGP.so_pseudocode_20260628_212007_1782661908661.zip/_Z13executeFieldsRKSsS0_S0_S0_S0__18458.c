char * _Z13executeFieldsRKSsS0_S0_S0_S0_(void)

{
  char cVar1;
  bool bVar2;

  char *pcVar4;
  int8 *in_x0;
  int8 *piVar5;
  char *pcVar6;
  int4 *piVar7;
  int4 val;
  char *pcStack_b8;
  int8 iStack_b0;
  int8 iStack_a8;
  int8 iStack_a0;
  int8 iStack_98;
  int8 iStack_90;
  int8 iStack_88;
  int8 iStack_80;
  int8 iStack_78;
  int8 iStack_70;
  char *pcStack_68;
  uint8_t axStack_60 [8];




  func_0x00063720(&pcStack_68,"chmod 777 /data/data/com.soham.cheat/files/fields",&iStack_70);
  system(pcStack_68);
  pcVar4 = pcRam00000000000bff48;
  pcVar6 = pcRam00000000000bff48 + 0x18;
  pcStack_b8 = pcVar6;
  func_0x00063bf0(&pcStack_b8,*(int8 *)(*in_x0 + -0x18) + 0x2f);
  func_0x0006433c(&pcStack_b8,"su -c \"/data/data/com.soham.cheat/files/fields ",0x2f);
  func_0x0006417c(&pcStack_b8);
  piVar5 = (int8 *)func_0x0006433c(&pcStack_b8," ",1);
  iStack_b0 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_b0);
  iStack_a8 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_a8," ",1);
  iStack_a0 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_a0);
  iStack_98 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_98," ",1);
  iStack_90 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_90);
  iStack_88 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_88," ",1);
  iStack_80 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_80);
  iStack_78 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_78,"\"",1);
  iStack_70 = *piVar5;
  *piVar5 = (int8)pcVar6;
  func_0x0006473c(&pcStack_68,&iStack_70);
  if ((char *)(iStack_70 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_70 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_70 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_78 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_78 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_78 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_80 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_80 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_80 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_88 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_88 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_88 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_90 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_90 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_90 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_98 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_98 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_98 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_a0 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_a0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_a0 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_a8 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_a8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_a8 + -0x18),axStack_60);
    }
  }
  if ((char *)(iStack_b0 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_b0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_b0 + -0x18),axStack_60);
    }
  }
  if (pcStack_b8 + -0x18 != pcVar4) {
    piVar7 = (int4 *)(pcStack_b8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c(pcStack_b8 + -0x18,axStack_60);
    }
  }
  system(pcStack_68);
  pcVar6 = pcStack_68 + -0x18;
  if (pcVar6 != pcVar4) {
    piVar7 = (int4 *)(pcStack_68 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      pcVar6 = (char *)func_0x00066f0c(pcVar6,&iStack_70);
    }
  }



  return pcVar6;
}