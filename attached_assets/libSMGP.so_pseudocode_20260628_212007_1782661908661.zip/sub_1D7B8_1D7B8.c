uint64_t sub_1D7B8(void)

{
  int4 val;
  int8 *in_x0;
  int4 *piVar2;
  void *param1;
  
  param1 = (void *)*in_x0;
  if (param1 == (void *)0x0) {
    return 0;
  }
  if ((char)in_x0[1] != '\0') {
    piVar2 = (int4 *)__errno();
    *piVar2 = 0;
    while (val = fclose(param1), val != 0) {
      if (*piVar2 != 4) {
        *in_x0 = 0;
        return 0;
      }
      param1 = (void *)*in_x0;
    }
  }
  *in_x0 = 0;
  return in_x0;
}