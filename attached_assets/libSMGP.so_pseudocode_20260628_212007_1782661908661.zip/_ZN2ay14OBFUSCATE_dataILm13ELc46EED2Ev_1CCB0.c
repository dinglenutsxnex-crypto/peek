// detected - ay::obfuscate (compile-time XOR string obfuscation) (detection may be wrong)
void _ZN2ay14OBFUSCATE_dataILm13ELc46EED2Ev(uint64_t *param_1)

{
  *(uint64_t *)((int8)param_1 + 5) = 0;
  *param_1 = 0;
  return;
}