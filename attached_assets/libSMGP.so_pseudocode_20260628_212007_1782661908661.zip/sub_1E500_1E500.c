uint8_t * sub_1E500(void)

{
  jint result;
  int8 *env;
  uint8_t *in_x1;
  uint8_t *in_x2;
  uint8_t *pxVar2;
  
  if (in_x1 < in_x2) {
    do {
      result = (*env)->GetVersion();
      pxVar2 = in_x1 + 1;
      *in_x1 = result;
      in_x1 = pxVar2;
    } while (pxVar2 != in_x2);
  }
  return in_x2;
}