uint64_t sub_28E34(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xbab50;
  if (*(char *)(in_x0 + 0x11) != '\0') {
    if ((void *)in_x0[2] != (void *)0x0) {
      _ZdaPv((void *)in_x0[2]);
    }
    if ((void *)in_x0[5] != (void *)0x0) {
      _ZdaPv((void *)in_x0[5]);
    }
    if ((void *)in_x0[7] != (void *)0x0) {
      _ZdaPv((void *)in_x0[7]);
    }
  }
}