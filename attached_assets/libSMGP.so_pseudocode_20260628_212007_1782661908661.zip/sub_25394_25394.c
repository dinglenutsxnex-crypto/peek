int8 * sub_25394(void)

{
  int8 *in_x0;
  int8 *env;
  jboolean in_w1;
  uint8 val;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_1F6E0();
  sub_24104();
  if (cStack_8 == '\0') {
    return in_x0;
  }
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  if (env != (int8 *)0x0) {
    val = env[2];
    if (((uint8)env[1] < val) && (in_w1 == *(int4 *)(val - 4))) {
      env[2] = val - 4;
    }
    else {
      in_w1 = (*env)->IsAssignableFrom(env,in_w1);
    }
    if (in_w1 != -1) {
      return in_x0;
    }
  }
  sub_1F6E0();
  return in_x0;
}