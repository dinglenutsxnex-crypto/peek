uint64_t * sub_20070(void)

{
  uint64_t val1;
  int4 val2;
  uint4 val3;
  int8 in_x0;
  uint64_t *pxVar4;
  uint64_t *pxVar5;
  void *param1;
  int4 in_w1;
  uint64_t *pxVar6;
  char in_w2;
  uint64_t *pxVar8;
  int8 val4;
  int4 val5;
  uint8_t axVar11 [16];
  uint64_t *pxVar7;
  
  if (in_w1 < 8) {
    val5 = 8;
    pxVar4 = (uint64_t *)(in_x0 + 0x40);
code_r0x00020128:
    *(uint64_t **)(in_x0 + 200) = pxVar4;
    *(int4 *)(in_x0 + 0xc0) = val5;
    return pxVar4 + (int8)in_w1 * 2;
  }
  if (in_w1 != 0x7fffffff) {
    val5 = in_w1 + 1;
    val4 = (int8)val5;
    pxVar4 = _Znam(val4 << 4);
    pxVar5 = pxVar4;
    do {
      *pxVar5 = 0;
      val4 = val4 + -1;
      pxVar5[1] = 0;
      pxVar5 = pxVar5 + 2;
    } while (val4 != 0);
    val2 = *(int4 *)(in_x0 + 0xc0);
    if (val2 < 1) {
      pxVar5 = *(uint64_t **)(in_x0 + 200);
    }
    else {
      pxVar5 = *(uint64_t **)(in_x0 + 200);
      pxVar6 = pxVar5;
      pxVar8 = pxVar4;
      do {
        pxVar7 = pxVar6 + 2;
        val1 = pxVar6[1];
        *pxVar8 = *pxVar6;
        pxVar8[1] = val1;
        pxVar6 = pxVar7;
        pxVar8 = pxVar8 + 2;
      } while (pxVar7 != pxVar5 + ((uint8)(val2 - 1) + 1) * 2);
    }
    if ((pxVar5 != (uint64_t *)0x0) && ((uint64_t *)(in_x0 + 0x40) != pxVar5)) {
      _ZdaPv(pxVar5);
    }
    goto code_r0x00020128;
  }
  val3 = *(uint4 *)(in_x0 + 0x20) | 1;
  *(uint4 *)(in_x0 + 0x20) = val3;
  if ((val3 & *(uint4 *)(in_x0 + 0x1c)) == 0) {
    if (in_w2 == '\0') {
      *(uint64_t *)(in_x0 + 0x30) = 0;
    }
    else {
      *(uint64_t *)(in_x0 + 0x38) = 0;
    }
    return (uint64_t *)(in_x0 + 0x30);
  }
  axVar11 = func_0x00062640("ios_base::_M_grow_words is not valid");
  param1 = axVar11._0_8_;
  if (axVar11._8_8_ != 1) {
    param1 = (void *)func_0x00081f98();
  }
  __cxa_begin_catch(param1);
  val3 = *(uint4 *)(in_x0 + 0x20) | 1;
  *(uint4 *)(in_x0 + 0x20) = val3;
  if ((val3 & *(uint4 *)(in_x0 + 0x1c)) == 0) {
    if (in_w2 != '\0') {
      *(uint64_t *)(in_x0 + 0x38) = 0;
      goto code_r0x000201d8;
    }
  }
  else {
    func_0x00062640("ios_base::_M_grow_words allocation failed");
  }
  *(uint64_t *)(in_x0 + 0x30) = 0;
code_r0x000201d8:
  __cxa_end_catch();
  return (uint64_t *)(in_x0 + 0x30);
}