uint64_t sub_246D4(void)

{
  int8 *in_x0;
  jclass cls;
  uint4 *puVar2;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_24104();
  if (cStack_8 == '\0') {
    if (in_x0[1] != 0) {
      return JNI_ERR;
    }
  }
  else {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    puVar2 = (uint4 *)env[2];
    if (puVar2 < (uint4 *)env[3]) {
      cls = (uint8)*puVar2;
      env[2] = (int8)(puVar2 + 1);
    }
    else {
      cls = (*env)->GetSuperclass(env);
    }
    if ((int4)cls != -1) {
      in_x0[1] = 1;
      jclass cls;
    }
  }
  sub_1F6E0();
  return JNI_ERR;
}