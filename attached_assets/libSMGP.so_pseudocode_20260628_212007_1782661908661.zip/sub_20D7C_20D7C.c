uint64_t sub_20D7C(void)

{
  int8 in_x0;
  uint64_t ret;
  uint8_t axStack_8 [8];
  
  *(uint64_t *)(in_x0 + 8) = 6;
  *(uint64_t *)(in_x0 + 0x10) = 0;
  *(uint32_t *)(in_x0 + 0x18) = 0x1002;
  func_0x0003bc18(axStack_8);
  func_0x0003a0e8(in_x0 + 0xd0,axStack_8);
  ret = func_0x0003a188(axStack_8);
  return ret;
}