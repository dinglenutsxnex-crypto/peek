uint8 sub_1F810(void)

{
  uint64_t *pxVar1;
  char cVar2;
  uint64_t *in_x0;
  uint64_t val;
  int8 in_x1;
  
  func_0x0001ff5c();
  in_x0[0x1b] = 0;
  *in_x0 = 0xba5e0;
  pxVar1 = in_x0 + 0x1a;
  *(uint32_t *)(in_x0 + 0x1c) = 0;
  *(uint8_t *)((int8)in_x0 + 0xe4) = 0;
  in_x0[0x1d] = 0;
  in_x0[0x1e] = 0;
  in_x0[0x1f] = 0;
  in_x0[0x20] = 0;
  func_0x00020d7c();
  cVar2 = func_0x0004e19c(pxVar1);
  if (cVar2 == '\0') {
    in_x0[0x1e] = 0;
    cVar2 = func_0x0004e34c(pxVar1);
  }
  else {
    val = func_0x0004c214(pxVar1);
    in_x0[0x1e] = val;
    cVar2 = func_0x0004e34c(pxVar1);
  }
  if (cVar2 == '\0') {
    in_x0[0x1f] = 0;
    cVar2 = func_0x0004e3b8(pxVar1);
  }
  else {
    val = func_0x0004cf28(pxVar1);
    in_x0[0x1f] = val;
    cVar2 = func_0x0004e3b8(pxVar1);
  }
  if (cVar2 == '\0') {
    in_x0[0x20] = 0;
  }
  else {
    val = func_0x0004cf90(pxVar1);
    in_x0[0x20] = val;
  }
  in_x0[0x1d] = in_x1;
  *(uint32_t *)(in_x0 + 0x1c) = 0;
  *(uint8_t *)((int8)in_x0 + 0xe4) = 0;
  in_x0[0x1b] = 0;
  *(uint32_t *)((int8)in_x0 + 0x1c) = 0;
  *(uint4 *)(in_x0 + 4) = (uint4)(in_x1 == 0);
  return (uint8)(in_x1 == 0);
}