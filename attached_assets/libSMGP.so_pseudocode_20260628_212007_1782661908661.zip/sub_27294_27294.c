int8 * sub_27294(void)

{
  uint8 param3;
  uint8 val1;
  uint1 val2;
  bool bVar3;
  uint4 val3;
  jobject obj;
  int8 *in_x0;
  void *pvVar6;
  uint64_t val4;
  int8 in_x1;
  uint4 in_w2;
  int8 *env;
  uint1 *puVar9;
  uint1 *puVar10;
  int8 val5;
  char cStack_8;
  
  if (in_w2 == JNI_ERR) {
    val4 = func_0x0006c9ec();
    return (int8 *)val4;
  }
  in_x0[1] = 0;
  sub_21204();
  if ((in_x1 < 1) || (cStack_8 == '\0')) {
    return in_x0;
  }
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  if ((uint1 *)env[2] < (uint1 *)env[3]) {
    obj = (uint4)*(uint1 *)env[2];
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
  }
  val5 = in_x0[1];
  bVar3 = false;
code_r0x00027320:
  do {
    val3 = obj;
    if (in_w2 == obj || obj == JNI_ERR) {
code_r0x000273b0:
      if (bVar3) {
        in_x0[1] = 0x7fffffffffffffff;
      }
      if (obj == JNI_ERR) {
        sub_1ED34();
        return in_x0;
      }
      if (in_w2 != obj) {
        return in_x0;
      }
      if (in_x0[1] != 0x7fffffffffffffff) {
        in_x0[1] = in_x0[1] + 1;
      }
      if ((uint8)env[2] < (uint8)env[3]) {
        env[2] = env[2] + 1;
        return in_x0;
      }
      (*env)->GetSuperclass(env);
      return in_x0;
    }
    while (obj = val3, val5 < in_x1) {
      puVar10 = (uint1 *)env[3];
      puVar9 = (uint1 *)env[2];
      param3 = in_x1 - val5;
      if ((int8)puVar10 - (int8)puVar9 < in_x1 - val5) {
        param3 = (int8)puVar10 - (int8)puVar9;
      }
      if ((int8)param3 < 2) {
        in_x0[1] = val5 + 1;
        if (puVar9 < puVar10) {
          puVar9 = puVar9 + 1;
          env[2] = (int8)puVar9;
code_r0x00027420:
          if (puVar10 <= puVar9) goto code_r0x00027434;
          obj = (uint4)*puVar9;
          val5 = in_x0[1];
        }
        else {
          obj = (*env)->GetSuperclass(env);
          if (obj != JNI_ERR) {
            puVar9 = (uint1 *)env[2];
            puVar10 = (uint1 *)env[3];
            goto code_r0x00027420;
          }
code_r0x00027444:
          val5 = in_x0[1];
        }
        goto code_r0x00027320;
      }
      pvVar6 = memchr(puVar9,in_w2 & 0xff,param3);
      val1 = (int8)pvVar6 - (int8)puVar9;
      if (pvVar6 == (void *)0x0) {
        val1 = param3;
      }
      env[2] = (int8)(puVar9 + val1);
      val5 = val5 + val1;
      in_x0[1] = val5;
      if (puVar10 <= puVar9 + val1) {
code_r0x00027434:
        obj = (*env)->ToReflectedMethod(env);
        goto code_r0x00027444;
      }
      val2 = puVar9[val1];
      obj = (uint4)val2;
      val3 = (uint4)val2;
      if (in_w2 == val2 || val2 == JNI_ERR) goto code_r0x000273b0;
    }
    if (in_x1 != 0x7fffffffffffffff) goto code_r0x000273b0;
    in_x0[1] = -0x8000000000000000;
    val5 = -0x8000000000000000;
    bVar3 = true;
  } while( true );
}