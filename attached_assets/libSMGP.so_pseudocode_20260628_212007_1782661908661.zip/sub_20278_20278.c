uint64_t * sub_20278(void)

{
  char cVar1;
  bool bVar2;
  void *in_x0;
  int4 *piVar3;
  uint64_t *param1;
  void *extraout_x0;
  uint64_t *pxVar4;
  int4 val;
  
  pxVar4 = *(uint64_t **)((int8)in_x0 + 0x28);
  param1 = in_x0;
  if (pxVar4 != (uint64_t *)0x0) {
    piVar3 = (int4 *)((int8)pxVar4 + 0x14);
    if (pthread_create == 0) goto code_r0x000202ec;
    do {
      do {
        val = *piVar3;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar3,0x10);
        if (bVar2) {
          *piVar3 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
        param1 = pxVar4;
      } while (cVar1 != '\0');
      while( true ) {
        if (val != 0) goto code_r0x000202bc;
        pxVar4 = (uint64_t *)*param1;
        _ZdlPv(param1);
        param1 = extraout_x0;
        if (pxVar4 == (uint64_t *)0x0) goto code_r0x000202bc;
        piVar3 = (int4 *)((int8)pxVar4 + 0x14);
        if (pthread_create != 0) break;
code_r0x000202ec:
        val = *(int4 *)((int8)pxVar4 + 0x14);
        *(int4 *)((int8)pxVar4 + 0x14) = val + -1;
        param1 = pxVar4;
      }
    } while( true );
  }
code_r0x000202bc:
  *(uint64_t *)((int8)in_x0 + 0x28) = 0;
  return param1;
}