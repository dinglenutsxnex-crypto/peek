int8 * sub_226A8(void)

{
  jboolean val;
  int8 *in_x0;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_1ED34();
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if (env == (int8 *)0x0) {
code_r0x00022750:
      sub_1ED34();
      return in_x0;
    }
    if ((uint8)env[1] < (uint8)env[2]) {
      env[2] = env[2] - 1;
    }
    else {
      val = (*env)->IsAssignableFrom(env,JNI_ERR);
      if (val == -1) goto code_r0x00022750;
    }
  }
  return in_x0;
}