uint64_t * sub_20024(void)

{
  int8 in_x0;
  uint64_t *pxVar1;
  uint64_t in_x1;
  uint32_t in_w2;
  
  pxVar1 = _Znwm(0x18);
  *pxVar1 = *(uint64_t *)(in_x0 + 0x28);
  pxVar1[1] = in_x1;
  *(uint32_t *)(pxVar1 + 2) = in_w2;
  *(uint32_t *)((int8)pxVar1 + 0x14) = 0;
  *(uint64_t **)(in_x0 + 0x28) = pxVar1;
  return pxVar1;
}