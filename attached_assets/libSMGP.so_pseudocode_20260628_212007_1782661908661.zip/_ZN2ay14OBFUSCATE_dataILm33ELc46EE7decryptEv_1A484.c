// detected - ay::obfuscate (compile-time XOR string obfuscation) (detection may be wrong)
// detected - Single-byte XOR key (0x2e) (detection may be wrong)
// detected - XOR with constant (detection may be wrong)
void _ZN2ay14OBFUSCATE_dataILm33ELc46EE7decryptEv(uint8 *param_1)

{
  if ((char)param_1[4] != '\0') {
    param_1[1] = param_1[1] ^ 0x2e2e2e2e2e2e2e2e;
    *param_1 = *param_1 ^ 0x2e2e2e2e2e2e2e2e;
    param_1[3] = param_1[3] ^ 0x2e2e2e2e2e2e2e2e;
    param_1[2] = param_1[2] ^ 0x2e2e2e2e2e2e2e2e;
    *(uint1 *)(param_1 + 4) = (uint1)param_1[4] ^ 0x2e;
  }
  return;
}