uint8 Java_com_soham_cheat_Ui_nativeSetTargetPackage(void)

{
  uint4 val1;
  int8 *in_x0;
  char *param1;
  uint8 val2;
  
  param1 = (char *)(*in_x0)->GetStringUTFChars();
  if (param1 == (char *)0x0) {
    func_0x00065820(0xc0190,0,*(uint64_t *)(unk_c0190 + -0x18),0);
  }
  else {
    val2 = strlen(param1);
    func_0x00065cf4(0xc0190,param1,val2);
    (*in_x0)->ReleaseStringUTFChars();
  }
  val1 = __android_log_print(4,(char *)"MainCpp",(char *)"nativeSetTargetPackage -> %s");
  return (uint8)val1;
}