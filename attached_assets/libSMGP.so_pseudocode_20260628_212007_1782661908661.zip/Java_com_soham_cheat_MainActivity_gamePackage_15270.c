uint64_t Java_com_soham_cheat_MainActivity_gamePackage(void)

{
  char cVar1;
  bool bVar2;

  int8 *in_x0;
  uint64_t ret;
  int4 *piVar5;
  int4 val;
  uint8_t axStack_50 [8];
  int8 iStack_48;
  uint8_t axStack_40 [8];




  ret = (*in_x0)->GetStringUTFChars();
  func_0x00063720(&iStack_48,ret,axStack_50);
  func_0x0006473c(packageName,&iStack_48);
  if (iStack_48 + -0x18 != unk_bff48) {
    piVar5 = (int4 *)(iStack_48 + -8);
    if (pthread_create == 0) {
      val = *piVar5;
      *piVar5 = val + -1;
    }
    else {
      do {
        val = *piVar5;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar5,0x10);
        if (bVar2) {
          *piVar5 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c(iStack_48 + -0x18,axStack_40);
    }
  }
  ret = (*in_x0)->ReleaseStringUTFChars();



  return ret;
}