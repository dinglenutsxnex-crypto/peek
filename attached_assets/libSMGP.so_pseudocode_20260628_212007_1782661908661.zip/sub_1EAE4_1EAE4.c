uint8 sub_1EAE4(void)

{
  uint8_t val1;
  uint4 val2;
  int4 val3;
  int8 in_x0;
  uint8 in_x1;
  uint8 in_x2;
  uint8_t in_w3;
  int8 in_x4;
  int8 val4;
  
  if (*(char *)(in_x0 + 0x18) == '\0') {
    if (in_x1 < in_x2) {
      val4 = 0;
      do {
        val3 = wctob(*(uint32_t *)(in_x1 + val4 * 4));
        val1 = (char)val3;
        if (val3 == -1) {
          val1 = in_w3;
        }
        *(uint8_t *)(in_x4 + val4) = val1;
        val4 = val4 + 1;
      } while (val4 != (~in_x1 + in_x2 >> 2) + 1);
    }
  }
  else if (in_x1 < in_x2) {
    val4 = 0;
    do {
      val2 = *(uint4 *)(in_x1 + val4 * 4);
      if (val2 < 0x80) {
        *(uint8_t *)(in_x4 + val4) = *(uint8_t *)(in_x0 + (uint8)val2 + 0x19);
      }
      else {
        val3 = wctob();
        val1 = (char)val3;
        if (val3 == -1) {
          val1 = in_w3;
        }
        *(uint8_t *)(in_x4 + val4) = val1;
      }
      val4 = val4 + 1;
    } while (val4 != (~in_x1 + in_x2 >> 2) + 1);
  }
  return in_x2;
}