void * sub_1E330(void)

{
  int8 val;
  int8 *in_x0;
  void *pvVar2;
  int8 in_x2;
  uint1 in_w3;
  int8 in_x4;
  
  *(uint4 *)(in_x0 + 1) = (uint4)(in_x4 != 0);
  val = unk_bff40;
  in_x0[4] = 0;
  *(uint1 *)(in_x0 + 3) = in_w3 & in_x2 != 0;
  *in_x0 = val + 0x10;
  in_x0[5] = 0;
  if (in_x2 == 0) {
    in_x2 = *piRam00000000000bfec0 + 1;
  }
  in_x0[6] = in_x2;
  memset((void *)((int8)in_x0 + 0x39),0,0x100);
  *(uint8_t *)(in_x0 + 7) = 0;
  pvVar2 = memset((void *)((int8)in_x0 + 0x139),0,0x100);
  *(uint8_t *)((int8)in_x0 + 0x239) = 0;
  return pvVar2;
}