int8 * sub_24594(void)

{
  int8 *in_x0;
  int8 val;
  int8 in_x1;
  char cStack_8;
  char cStack_1;
  
  sub_24104();
  if ((in_x1 == 0) || (cStack_8 == '\0')) {
    if (in_x1 != 0) {
      return in_x0;
    }
  }
  else {
    val = func_0x00049058(*(uint64_t *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8));
    if ((val != 0) && (cStack_1 == '\0')) {
      return in_x0;
    }
  }
  sub_1F6E0();
  return in_x0;
}