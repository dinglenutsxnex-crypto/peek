uint8 sub_1EFDC(void)

{
  jclass cls;
  int8 in_x0;
  int8 *env;
  
  if (*(char *)(in_x0 + 0xe1) != '\0') {
    return (uint8)*(uint1 *)(in_x0 + 0xe0);
  }
  env = *(int8 **)(in_x0 + 0xf0);
  if (env != (int8 *)0x0) {
    if ((char)env[7] == '\0') {
      sub_1DFC0();
      cls = (*env)->FindClass(env,"lease)");
    }
    else {
      cls = *(uint1 *)((int8)env + 0x59);
    }
    *(uint1 *)(in_x0 + 0xe0) = cls;
    *(uint8_t *)(in_x0 + 0xe1) = 1;
    return (uint8)cls;
  }
  func_0x00061e30();
}