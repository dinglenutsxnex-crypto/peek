uint32_t * sub_1E740(void)

{
  uint32_t *pxVar1;
  uint32_t val;
  uint32_t *in_x1;
  uint32_t *in_x2;
  uint32_t *pxVar3;
  uint32_t *pxVar4;
  
  if (in_x1 < in_x2) {
    pxVar1 = in_x1 + 1;
    pxVar4 = in_x1;
    do {
      pxVar3 = pxVar1;
      val = towupper(*pxVar4);
      *pxVar4 = val;
      pxVar1 = pxVar3 + 1;
      pxVar4 = pxVar3;
    } while (pxVar3 != (uint32_t *)
                       ((int8)in_x1 +
                       ((int8)in_x2 + (3 - (int8)(in_x1 + 1)) & 0xfffffffffffffffcU) + 4));
  }
  return in_x2;
}