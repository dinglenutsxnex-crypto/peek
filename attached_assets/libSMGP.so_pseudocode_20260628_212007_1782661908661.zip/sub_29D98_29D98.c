void sub_29D98(int8 *env)

{
  (*env)->GetSuperclass();
  return;
}