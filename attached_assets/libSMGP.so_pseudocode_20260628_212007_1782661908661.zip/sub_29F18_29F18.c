uint64_t sub_29F18(void)

{
  int8 *env;
  uint64_t in_x8;
  
  (*env)->DefineClass();
  return in_x8;
}