int8 _Z9valuesGG3RKSsS0_S0_(void)

{
  char cVar1;
  bool bVar2;

  int8 val1;
  int8 *in_x0;
  int8 val2;
  int4 *piVar6;
  int4 val3;
  int8 iStack_60;
  int8 iStack_58;
  uint8_t axStack_50 [8];




  val2 = func_0x000649dc(in_x0,0x3b,0);
  if (val2 != -1) {
    func_0x000632ec(&iStack_58);
    if (*(uint8 *)(*in_x0 + -0x18) < val2 + 1U) goto code_r0x00016c64;
    func_0x000632ec(&iStack_60);
    _Z15executeCommand3RKSsS0_S0_S0_(&iStack_58,&iStack_60);
    val1 = unk_bff48;
    if (iStack_60 + -0x18 != unk_bff48) {
      piVar6 = (int4 *)(iStack_60 + -8);
      if (pthread_create == 0) {
        val3 = *piVar6;
        *piVar6 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar6;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar6,0x10);
          if (bVar2) {
            *piVar6 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        func_0x00066f0c(iStack_60 + -0x18,axStack_50);
      }
    }
    val2 = iStack_58 + -0x18;
    if (val2 != val1) {
      piVar6 = (int4 *)(iStack_58 + -8);
      if (pthread_create == 0) {
        val3 = *piVar6;
        *piVar6 = val3 + -1;
      }
      else {
        do {
          val3 = *piVar6;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar6,0x10);
          if (bVar2) {
            *piVar6 = val3 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val3 < 1) {
        val2 = func_0x00066f0c(val2,&iStack_60);
      }
    }
  }



  __stack_chk_fail();
code_r0x00016c64:
  func_0x0006221c("%s: __pos (which is %zu) > this->size() (which is %zu)","basic_string::substr");
}