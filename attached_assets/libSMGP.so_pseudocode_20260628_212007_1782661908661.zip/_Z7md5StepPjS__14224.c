// detected - Rolling XOR cipher (detection may be wrong)
// detected - XOR with constant (detection may be wrong)
void _Z7md5StepPjS_(uint4 *param_1,int8 param_2)

{
  uint4 val1;
  uint4 val2;
  uint4 val3;
  uint4 val4;
  uint4 val5;
  uint4 val6;
  uint4 val7;
  int8 val8;
  uint8 val9;
  uint8 val10;
  uint8 val11;
  uint8 val12;
  uint8 val13;
  
  val10 = 0;
  val11 = 0;
  val12 = 5;
  val13 = 1;
  val1 = *param_1;
  val5 = param_1[3];
  val6 = param_1[2];
  val7 = param_1[1];
  do {
    val4 = val7;
    val3 = val6;
    val2 = val5;
    val7 = (uint4)(val11 >> 4) & 0xfffffff;
    if (val7 == 2) {
      val7 = val3 ^ val4 ^ val2;
      val9 = val12 & 0xf;
    }
    else if (val7 == 1) {
      val7 = val2 & val4 | val3 & (val2 ^ 0xffffffff);
      val9 = val13 & 0xf;
    }
    else if ((val11 >> 4 & 0xfffffff) == 0) {
      val7 = val2 & (val4 ^ 0xffffffff) | val3 & val4;
      val9 = val11;
    }
    else {
      val7 = (val4 | val2 ^ 0xffffffff) ^ val3;
      val9 = val10 & 0xf;
    }
    val8 = val11 * 4;
    val11 = val11 + 1;
    val7 = val7 + val1 + *(int4 *)(val8 + 0x84d68) +
            *(int4 *)(param_2 + (val9 & 0xffffffff) * 4);
    val1 = 0x20U - *(int4 *)(val8 + 0x84e68) & 0x1f;
    val12 = val12 + 3;
    val10 = val10 + 7;
    val7 = (val7 >> val1 | val7 << 0x20 - val1) + val4;
    val13 = val13 + 5;
    val1 = val2;
    val5 = val3;
    val6 = val4;
  } while (val11 != 0x40);
  *param_1 = val2 + *param_1;
  param_1[1] = val7 + param_1[1];
  param_1[2] = val4 + param_1[2];
  param_1[3] = val3 + param_1[3];
  return;
}