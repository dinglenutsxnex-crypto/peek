void _ZN9__gnu_cxx20recursive_init_errorD1Ev(int8 *param_1)

{
  *param_1 = _ZTVN9__gnu_cxx20recursive_init_errorE + 0x10;
  _ZNSt9exceptionD2Ev();
  return;
}