void sub_29B78(uint64_t *param_1,int8 param_2)

{
  *(uint4 *)(param_1 + 1) = (uint4)(param_2 != 0);
  *param_1 = 0xbd240;
  param_1[2] = 0;
  func_0x0003c980(param_1,0,0);
  return;
}