void sub_29EB4(int8 *param_1)

{
  (**(code **)(*param_1 + 0x10))();
  return;
}