void sub_29BD0(uint64_t *param_1,uint64_t param_2,int8 param_3)

{
  *(uint4 *)(param_1 + 1) = (uint4)(param_3 != 0);
  param_1[2] = param_2;
  *param_1 = 0xbd240;
  func_0x0003c980(param_1,0,0);
  return;
}