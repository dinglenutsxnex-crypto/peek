uint64_t _Z8CategoryP7_JNIEnvP8_jobjectPKc(void)

{
  int8 *env;
  uint64_t ret;
  
  (*env)->GetObjectClass();
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  ret = _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  return ret;
}