uint64_t sub_20EF8(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xba698;
  in_x0[1] = 0;
  in_x0[2] = unk_bfee8 + 0x10;
  sub_202FC();
}