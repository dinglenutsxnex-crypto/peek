uint8 sub_20B38(void)

{
  int8 val1;
  uint1 val2;
  uint1 *puVar3;
  uint1 in_w0;
  int8 *piVar4;
  uint8_t axStack_8 [8];
  
  puVar3 = puRam00000000000bff60;
  val2 = *puRam00000000000bff60;
  if (val2 <= in_w0) {
    return (uint8)(uint4)val2;
  }
  sub_203B4();
  *puVar3 = in_w0;
  val1 = unk_bfc70 + 0x10;
  piVar4 = piRam00000000000bfc60 + 7;
  *piRam00000000000bfc60 = val1;
  func_0x0003a188(piVar4);
  piVar4 = piRam00000000000bf9e0 + 7;
  *piRam00000000000bf9e0 = val1;
  func_0x0003a188(piVar4);
  piVar4 = piRam00000000000bfeb8 + 7;
  *piRam00000000000bfeb8 = val1;
  func_0x0003a188(piVar4);
  val1 = unk_bfd08 + 0x10;
  piVar4 = piRam00000000000bfb50 + 7;
  *piRam00000000000bfb50 = val1;
  func_0x0003a188(piVar4);
  piVar4 = piRam00000000000bfbd8 + 7;
  *piRam00000000000bfbd8 = val1;
  func_0x0003a188(piVar4);
  piVar4 = piRam00000000000bfbb0 + 7;
  *piRam00000000000bfbb0 = val1;
  func_0x0003a188(piVar4);
  func_0x000703ac(unk_bfa40,__sF + 0x98,0x10,0x400);
  func_0x000703ac(unk_bfc10,__sF,8,0x400);
  func_0x000703ac(unk_bfb20,__sF + 0x130,0x10,0x400);
  sub_1EF9C();
  sub_1EF9C();
  sub_1EF9C();
  sub_1EF9C();
  func_0x00070600(unk_bfbf8,__sF + 0x98,0x10,0x400);
  func_0x00070600(unk_bfd90,__sF,8,0x400);
  func_0x00070600(unk_bffa8,__sF + 0x130,0x10,0x400);
  sub_1F948();
  sub_1F948();
  sub_1F948();
  sub_1F948();
  func_0x00020a8c(axStack_8);
  return (uint8)(uint4)val2;
}