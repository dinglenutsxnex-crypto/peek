int8 sub_1FD38(void)

{
  int4 *piVar1;
  uint4 val1;
  int4 val2;
  uint4 val3;
  char cVar5;
  bool bVar6;
  jclass cls;
  int8 in_x0;
  void *param1;
  uint64_t *pxVar8;
  uint64_t *pxVar9;
  int8 *env;
  uint64_t *pxVar12;
  int8 in_x1;
  uint64_t *pxVar13;
  uint64_t val4;
  uint64_t val5;
  int8 val6;
  uint8_t axStack_8 [8];
  uint64_t *pxVar10;
  
  if (in_x0 == in_x1) {
    return in_x0;
  }
  val1 = *(uint4 *)(in_x1 + 0xc0);
  if ((int4)val1 < 9) {
    pxVar12 = (uint64_t *)(in_x0 + 0x40);
  }
  else {
    pxVar12 = _Znam(-(uint8)(val1 >> 0x1f) & 0xfffffff000000000 | (uint8)val1 << 4);
    val2 = *(int4 *)(in_x1 + 0xc0);
    val6 = 0;
    pxVar9 = pxVar12;
    if ((int8)val2 != 0) {
      do {
        val6 = val6 + 1;
        *pxVar9 = 0;
        pxVar9[1] = 0;
        pxVar9 = pxVar9 + 2;
      } while (val2 != val6);
    }
  }
  val6 = *(int8 *)(in_x1 + 0x28);
  if (val6 != 0) {
    if (pthread_create == 0) {
      *(int4 *)(val6 + 0x14) = *(int4 *)(val6 + 0x14) + 1;
    }
    else {
      piVar1 = (int4 *)(val6 + 0x14);
      do {
        cVar5 = '\x01';
        bVar6 = (bool)ExclusiveMonitorPass(piVar1,0x10);
        if (bVar6) {
          *piVar1 = *piVar1 + 1;
          cVar5 = ExclusiveMonitorsStatus();
        }
      } while (cVar5 != '\0');
    }
  }
  func_0x00020210();
  param1 = *(void **)(in_x0 + 200);
  if ((void *)(in_x0 + 0x40) != param1) {
    if (param1 != (void *)0x0) {
      _ZdaPv(param1);
    }
    *(uint64_t *)(in_x0 + 200) = 0;
  }
  func_0x00020278();
  val2 = *(int4 *)(in_x1 + 0xc0);
  *(int8 *)(in_x0 + 0x28) = val6;
  if (0 < val2) {
    pxVar8 = *(uint64_t **)(in_x1 + 200);
    pxVar9 = pxVar8;
    pxVar13 = pxVar12;
    do {
      pxVar10 = pxVar9 + 2;
      val4 = pxVar9[1];
      *pxVar13 = *pxVar9;
      pxVar13[1] = val4;
      pxVar9 = pxVar10;
      pxVar13 = pxVar13 + 2;
    } while (pxVar10 != pxVar8 + ((uint8)(val2 - 1) + 1) * 2);
  }
  cls = *(uint32_t *)(in_x1 + 0x18);
  *(uint64_t *)(in_x0 + 0x10) = *(uint64_t *)(in_x1 + 0x10);
  val4 = *(uint64_t *)(in_x1 + 0xd8);
  val5 = *(uint64_t *)(in_x1 + 8);
  cVar5 = *(char *)(in_x1 + 0xe4);
  *(uint64_t **)(in_x0 + 200) = pxVar12;
  *(int4 *)(in_x0 + 0xc0) = val2;
  *(uint32_t *)(in_x0 + 0x18) = cls;
  *(uint64_t *)(in_x0 + 8) = val5;
  *(uint64_t *)(in_x0 + 0xd8) = val4;
  if (cVar5 == '\0') {
    env = *(int8 **)(in_x1 + 0xf0);
    if (env != (int8 *)0x0) {
      cls = (*env)->GetSuperclass(env,0x20);
      *(uint32_t *)(in_x1 + 0xe0) = cls;
      *(uint8_t *)(in_x1 + 0xe4) = 1;
      goto code_r0x0001fe50;
    }
code_r0x0001ff4c:
    func_0x00061e30();
  }
  else {
    cls = *(uint32_t *)(in_x1 + 0xe0);
code_r0x0001fe50:
    if (*(char *)(in_x0 + 0xe4) == '\0') {
      env = *(int8 **)(in_x0 + 0xf0);
      if (env == (int8 *)0x0) goto code_r0x0001ff4c;
      (*env)->GetSuperclass(env,0x20);
      *(uint8_t *)(in_x0 + 0xe4) = 1;
    }
    *(uint32_t *)(in_x0 + 0xe0) = cls;
    func_0x0003989c(axStack_8,in_x1 + 0xd0);
    func_0x0003a0e8(in_x0 + 0xd0,axStack_8);
    func_0x0003a188(axStack_8);
    sub_1FBBC();
    func_0x00020210();
    val1 = *(uint4 *)(in_x1 + 0x1c);
    *(uint4 *)(in_x0 + 0x1c) = val1;
    val3 = *(uint4 *)(in_x0 + 0x20);
    if (*(int8 *)(in_x0 + 0xe8) == 0) {
      val3 = val3 | 1;
      *(uint4 *)(in_x0 + 0x20) = val3;
    }
    if ((val3 & val1) == 0) {
      return in_x0;
    }
  }
  pxVar12 = (uint64_t *)func_0x00062640("basic_ios::clear");
  *pxVar12 = 0xba600;
  pxVar12[1] = 0;
  pxVar12[2] = 0;
  *(uint32_t *)(pxVar12 + 3) = 0;
  *(uint32_t *)((int8)pxVar12 + 0x1c) = 0;
  *(uint32_t *)(pxVar12 + 4) = 0;
  pxVar12[5] = 0;
  pxVar12[6] = 0;
  pxVar12[7] = 0;
  pxVar12[8] = 0;
  pxVar12[9] = 0;
  pxVar12[10] = 0;
  pxVar12[0xb] = 0;
  pxVar12[0xc] = 0;
  pxVar12[0xd] = 0;
  pxVar12[0xe] = 0;
  pxVar12[0xf] = 0;
  pxVar12[0x10] = 0;
  pxVar12[0x11] = 0;
  pxVar12[0x12] = 0;
  pxVar12[0x13] = 0;
  pxVar12[0x14] = 0;
  pxVar12[0x15] = 0;
  pxVar12[0x16] = 0;
  pxVar12[0x17] = 0;
  *(uint32_t *)(pxVar12 + 0x18) = 8;
  pxVar12[0x19] = pxVar12 + 8;
}