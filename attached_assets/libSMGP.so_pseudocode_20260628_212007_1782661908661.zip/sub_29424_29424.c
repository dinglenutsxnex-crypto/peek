uint64_t sub_29424(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xbd350;
  func_0x0006f954();
}