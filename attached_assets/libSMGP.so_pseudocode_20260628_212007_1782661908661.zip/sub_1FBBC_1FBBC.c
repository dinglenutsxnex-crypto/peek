uint64_t sub_1FBBC(void)

{
  char cVar1;
  int8 in_x0;
  uint64_t ret;
  
  cVar1 = func_0x0004e19c();
  if (cVar1 == '\0') {
    *(uint64_t *)(in_x0 + 0xf0) = 0;
    cVar1 = func_0x0004e34c();
  }
  else {
    ret = func_0x0004c214();
    *(uint64_t *)(in_x0 + 0xf0) = ret;
    cVar1 = func_0x0004e34c();
  }
  if (cVar1 == '\0') {
    *(uint64_t *)(in_x0 + 0xf8) = 0;
    cVar1 = func_0x0004e3b8();
  }
  else {
    ret = func_0x0004cf28();
    *(uint64_t *)(in_x0 + 0xf8) = ret;
    cVar1 = func_0x0004e3b8();
  }
  if (cVar1 != '\0') {
    ret = func_0x0004cf90();
    *(uint64_t *)(in_x0 + 0x100) = ret;
    return ret;
  }
  *(uint64_t *)(in_x0 + 0x100) = 0;
  return 0;
}