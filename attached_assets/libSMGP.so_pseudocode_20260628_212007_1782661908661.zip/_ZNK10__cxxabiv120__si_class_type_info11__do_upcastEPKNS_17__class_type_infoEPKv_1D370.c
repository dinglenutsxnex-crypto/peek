uint8 _ZNK10__cxxabiv120__si_class_type_info11__do_upcastEPKNS_17__class_type_infoEPKvRNS1_15__upcast_resultE
                (void)

{
  uint1 val1;
  int8 in_x0;
  
  val1 = _ZNK10__cxxabiv117__class_type_info11__do_upcastEPKS0_PKvRNS0_15__upcast_resultE();
  if (val1 == 0) {
    val1 = (**(code **)(**(int8 **)(in_x0 + 0x10) + 0x30))(*(int8 **)(in_x0 + 0x10));
  }
  return (uint8)val1;
}