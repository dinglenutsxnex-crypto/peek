uint64_t sub_24E0C(void)

{
  int8 *in_x0;
  int8 *env;
  
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xf0);
  if (env != (int8 *)0x0) {
    (*env)->GetSuperclass(env,10);
  }
  func_0x00061e30();
}