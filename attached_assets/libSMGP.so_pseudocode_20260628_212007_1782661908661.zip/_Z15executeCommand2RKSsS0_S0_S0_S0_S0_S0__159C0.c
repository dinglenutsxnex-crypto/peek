char * _Z15executeCommand2RKSsS0_S0_S0_S0_S0_S0_(void)

{
  char cVar1;
  bool bVar2;

  char *pcVar4;
  int8 *in_x0;
  int8 *piVar5;
  char *pcVar6;
  int4 *piVar7;
  int4 val;
  char *pcStack_100;
  int8 iStack_f8;
  int8 iStack_f0;
  int8 iStack_e8;
  int8 iStack_e0;
  int8 iStack_d8;
  int8 iStack_d0;
  int8 iStack_c8;
  int8 iStack_c0;
  int8 iStack_b8;
  int8 iStack_b0;
  int8 iStack_a8;
  int8 iStack_a0;
  int8 iStack_98;
  int8 iStack_90;
  int8 iStack_88;
  char *pcStack_80;
  uint8_t axStack_78 [8];




  func_0x00063720(&pcStack_80,"chmod 777 /data/data/com.soham.cheat/files/values2",&iStack_88);
  system(pcStack_80);
  pcVar4 = pcRam00000000000bff48;
  pcVar6 = pcRam00000000000bff48 + 0x18;
  pcStack_100 = pcVar6;
  func_0x00063bf0(&pcStack_100,*(int8 *)(*in_x0 + -0x18) + 0x30);
  func_0x0006433c(&pcStack_100,"su -c \"/data/data/com.soham.cheat/files/values2 ",0x30);
  func_0x0006417c(&pcStack_100);
  piVar5 = (int8 *)func_0x0006433c(&pcStack_100," ",1);
  iStack_f8 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_f8);
  iStack_f0 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_f0," ",1);
  iStack_e8 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_e8);
  iStack_e0 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_e0," ",1);
  iStack_d8 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_d8);
  iStack_d0 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_d0," ",1);
  iStack_c8 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_c8);
  iStack_c0 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_c0," ",1);
  iStack_b8 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_b8);
  iStack_b0 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_b0," ",1);
  iStack_a8 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_a8,packageName);
  iStack_a0 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_a0," ",1);
  iStack_98 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006417c(&iStack_98);
  iStack_90 = *piVar5;
  *piVar5 = (int8)pcVar6;
  piVar5 = (int8 *)func_0x0006433c(&iStack_90,"\"",1);
  iStack_88 = *piVar5;
  *piVar5 = (int8)pcVar6;
  func_0x0006473c(&pcStack_80,&iStack_88);
  if ((char *)(iStack_88 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_88 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_88 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_90 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_90 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_90 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_98 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_98 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_98 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_a0 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_a0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_a0 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_a8 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_a8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_a8 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_b0 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_b0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_b0 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_b8 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_b8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_b8 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_c0 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_c0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_c0 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_c8 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_c8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_c8 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_d0 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_d0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_d0 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_d8 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_d8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_d8 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_e0 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_e0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_e0 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_e8 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_e8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_e8 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_f0 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_f0 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_f0 + -0x18),axStack_78);
    }
  }
  if ((char *)(iStack_f8 + -0x18) != pcVar4) {
    piVar7 = (int4 *)(iStack_f8 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c((char *)(iStack_f8 + -0x18),axStack_78);
    }
  }
  if (pcStack_100 + -0x18 != pcVar4) {
    piVar7 = (int4 *)(pcStack_100 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      func_0x00066f0c(pcStack_100 + -0x18,axStack_78);
    }
  }
  system(pcStack_80);
  pcVar6 = pcStack_80 + -0x18;
  if (pcVar6 != pcVar4) {
    piVar7 = (int4 *)(pcStack_80 + -8);
    if (pthread_create == 0) {
      val = *piVar7;
      *piVar7 = val + -1;
    }
    else {
      do {
        val = *piVar7;
        cVar1 = '\x01';
        bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
        if (bVar2) {
          *piVar7 = val + -1;
          cVar1 = ExclusiveMonitorsStatus();
        }
      } while (cVar1 != '\0');
    }
    if (val < 1) {
      pcVar6 = (char *)func_0x00066f0c(pcVar6,&iStack_88);
    }
  }



  return pcVar6;
}