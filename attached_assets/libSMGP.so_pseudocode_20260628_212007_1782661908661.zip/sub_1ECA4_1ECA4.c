uint64_t sub_1ECA4(void)

{
  uint64_t *in_x0;
  uint64_t extraout_x0;
  
  *in_x0 = 0xba5c0;
  func_0x000202fc();
  _ZdlPv(in_x0);
  return extraout_x0;
}