uint8 Java_com_soham_cheat_Ui_nativeSetMenuVariant(void)

{
  uint4 val1;
  uint32_t in_w2;
  
  unk_c0198 = in_w2;
  val1 = __android_log_print(4,(char *)"MainCpp",(char *)"nativeSetMenuVariant -> %d");
  return (uint8)val1;
}