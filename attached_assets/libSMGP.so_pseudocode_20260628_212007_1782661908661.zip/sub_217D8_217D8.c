uint8 sub_217D8(void)

{
  int8 *in_x0;
  jclass cls;
  uint1 *puVar2;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') {
    if (in_x0[1] == 0) {
code_r0x0002186c:
      sub_1ED34();
      return JNI_ERR;
    }
    cls = JNI_ERR;
  }
  else {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    puVar2 = (uint1 *)env[2];
    if (puVar2 < (uint1 *)env[3]) {
      cls = (uint8)*puVar2;
      env[2] = (int8)(puVar2 + 1);
    }
    else {
      cls = (*env)->GetSuperclass(env);
      if ((int4)cls == -1) goto code_r0x0002186c;
    }
    in_x0[1] = 1;
  }
  jclass cls;
}