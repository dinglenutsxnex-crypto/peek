uint64_t sub_1DB10(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xbcba0;
  func_0x0006f8d4(in_x0 + 2);
  if ((*(char *)(in_x0 + 3) != '\0') && ((void *)in_x0[6] != (void *)0x0)) {
    _ZdaPv((void *)in_x0[6]);
  }
}