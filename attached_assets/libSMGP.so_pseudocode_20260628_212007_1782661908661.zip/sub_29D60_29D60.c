void sub_29D60(int8 *env)

{
  (*env)->FromReflectedField();
  return;
}