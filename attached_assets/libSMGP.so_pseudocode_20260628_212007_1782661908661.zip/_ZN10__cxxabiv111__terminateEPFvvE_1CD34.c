uint64_t _ZN10__cxxabiv111__terminateEPFvvE(void)

{
  code *in_x0;
  void *param1;

  int8 extraout_x1;

  (*in_x0)();
  abort();
  __cxa_begin_catch(param1);
  abort();
  __cxa_end_catch();
  if (extraout_x1 != -1) {
    func_0x00081f98(extraout_x0);
  }
  __cxa_call_unexpected();
}