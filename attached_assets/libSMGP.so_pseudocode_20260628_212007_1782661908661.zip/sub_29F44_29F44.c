uint64_t sub_29F44(void)

{
  int8 *env;
  uint64_t in_x8;
  
  (*env)->FindClass();
  return in_x8;
}