uint8 sub_1E8A0(void)

{
  int4 val1;
  int8 in_x0;
  uint8 in_x1;
  uint64_t val2;
  uint8 in_x2;
  int8 in_x3;
  uint64_t *pxVar3;
  int8 val3;
  uint1 val4;
  uint1 *puVar6;
  
  if (in_x1 < in_x2) {
    val3 = 0;
    do {
      val4 = 0;
      pxVar3 = (uint64_t *)(in_x0 + 0x4b0);
      puVar6 = (uint1 *)(in_x0 + 0x49c);
      do {
        val2 = *pxVar3;
        pxVar3 = pxVar3 + 1;
        val1 = iswctype(*(uint32_t *)(in_x1 + val3 * 4),val2);
        if (val1 != 0) {
          val4 = *puVar6 | val4;
        }
        puVar6 = puVar6 + 1;
      } while (pxVar3 != (uint64_t *)(in_x0 + 0x530));
      *(uint1 *)(in_x3 + val3) = val4;
      val3 = val3 + 1;
    } while (val3 != (~in_x1 + in_x2 >> 2) + 1);
  }
  return in_x2;
}