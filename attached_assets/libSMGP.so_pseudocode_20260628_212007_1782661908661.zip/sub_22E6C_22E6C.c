int8 * sub_22E6C(void)

{
  jclass cls;
  int8 *in_x0;
  int8 *env;
  uint8_t *in_x1;
  uint1 *puVar3;
  char cStack_8;
  
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    puVar3 = (uint1 *)env[2];
    if (puVar3 < (uint1 *)env[3]) {
      cls = (uint4)*puVar3;
      env[2] = (int8)(puVar3 + 1);
    }
    else {
      cls = (*env)->GetSuperclass();
      if (cls == JNI_ERR) {
        sub_1ED34();
        return in_x0;
      }
    }
    *in_x1 = (char)cls;
  }
  return in_x0;
}