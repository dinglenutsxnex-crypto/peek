uint64_t sub_20354(void)

{
  uint64_t *in_x0;
  uint64_t *param1;
  uint64_t extraout_x0;
  
  *in_x0 = 0xba600;
  sub_20210();
  sub_20278();
  param1 = (uint64_t *)in_x0[0x19];
  if (param1 != in_x0 + 8) {
    if (param1 != (uint64_t *)0x0) {
      _ZdaPv(param1);
    }
    in_x0[0x19] = 0;
  }
  func_0x0003a188(in_x0 + 0x1a);
  _ZdlPv(in_x0);
  return extraout_x0;
}