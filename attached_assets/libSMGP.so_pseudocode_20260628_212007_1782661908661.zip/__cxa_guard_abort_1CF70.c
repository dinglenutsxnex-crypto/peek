uint4 * __cxa_guard_abort(void)

{
  uint4 val1;
  char cVar2;
  bool bVar3;
  uint4 *in_x0;
  uint64_t val2;
  
  if (pthread_create == 0) {
    *(uint8_t *)((int8)in_x0 + 1) = 0;
    return in_x0;
  }
  do {
    val1 = *in_x0;
    cVar2 = '\x01';
    bVar3 = (bool)ExclusiveMonitorPass(in_x0,0x10);
    if (bVar3) {
      *in_x0 = 0;
      cVar2 = ExclusiveMonitorsStatus();
    }
  } while (cVar2 != '\0');
  if ((val1 & 0x10000) != 0) {
    val2 = syscall(0x62);
    return (uint4 *)val2;
  }
  return in_x0;
}