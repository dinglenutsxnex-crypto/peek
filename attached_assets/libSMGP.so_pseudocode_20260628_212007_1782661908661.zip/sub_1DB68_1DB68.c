uint64_t sub_1DB68(void)

{
  int8 *in_x0;
  
  *in_x0 = 0xbcc00;
  func_0x0006f8d4(in_x0 + 2);
  *in_x0 = unk_bffc0 + 0x10;
}