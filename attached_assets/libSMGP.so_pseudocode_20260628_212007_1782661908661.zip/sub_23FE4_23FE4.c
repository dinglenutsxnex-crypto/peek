uint8_t * sub_23FE4(void)

{
  int8 *in_x0;
  int8 *env;
  uint8_t *pxVar2;
  int8 val;
  uint8_t axVar4 [16];
  
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xf0);
  if (env != (int8 *)0x0) {
    (*env)->GetSuperclass(env,10);
  }
  axVar4 = func_0x00061e30();
  env = axVar4._0_8_;
  val = *axVar4._8_8_;
  *env = val;
  *(int8 *)((int8)env + *(int8 *)(val + -0x18)) = axVar4._8_8_[1];
  env[1] = 0;
  pxVar2 = sub_1FAE8();
  return pxVar2;
}