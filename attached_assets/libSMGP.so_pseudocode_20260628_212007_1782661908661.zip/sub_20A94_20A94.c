uint8 sub_20A94(void)

{
  uint4 val1;
  char cVar2;
  bool bVar3;
  int8 in_x0;
  uint64_t ret;
  int8 in_x1;
  uint4 *puVar5;
  
  puVar5 = *(uint4 **)(in_x1 + 0x9e8);
  if (*(int8 *)(in_x0 + 0xd50) == 0) {
    val1 = *puVar5;
    *puVar5 = val1 - 1;
  }
  else {
    do {
      val1 = *puVar5;
      cVar2 = '\x01';
      bVar3 = (bool)ExclusiveMonitorPass(puVar5,0x10);
      if (bVar3) {
        *puVar5 = val1 - 1;
        cVar2 = ExclusiveMonitorsStatus();
      }
    } while (cVar2 != '\0');
  }
  if (val1 == 2) {
    func_0x0003d868(unk_bfb28);
    func_0x0003d868(unk_bfce0);
    func_0x0003d868(unk_bfdc0);
    func_0x0003ff8c(unk_bfe48);
    func_0x0003ff8c(unk_bff18);
    ret = func_0x0003ff8c(unk_bfd80);
    return ret;
  }
  return (uint8)val1;
}