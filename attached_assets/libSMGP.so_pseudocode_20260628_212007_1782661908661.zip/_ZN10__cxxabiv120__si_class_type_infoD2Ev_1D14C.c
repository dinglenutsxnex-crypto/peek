void _ZN10__cxxabiv120__si_class_type_infoD2Ev(int8 *param_1)

{
  *param_1 = _ZTVN10__cxxabiv120__si_class_type_infoE + 0x10;
  _ZN10__cxxabiv117__class_type_infoD2Ev();
  return;
}