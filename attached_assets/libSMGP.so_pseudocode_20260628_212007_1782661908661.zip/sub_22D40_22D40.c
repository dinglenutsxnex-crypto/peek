int8 * sub_22D40(void)

{
  jclass cls;
  int8 *in_x0;
  int8 val;
  uint1 *puVar3;
  jobject obj;
  uint1 *puVar5;
  int8 *env;
  uint8_t axStack_8 [8];
  
  func_0x0003989c(axStack_8,(int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xd0);
  val = func_0x0002b34c(axStack_8);
  func_0x0003a188(axStack_8);
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  puVar3 = (uint1 *)env[2];
  if ((uint1 *)env[3] <= puVar3) goto code_r0x00022dec;
  do {
    obj = (uint8)*puVar3;
    while( true ) {
      if ((*(uint1 *)(*(int8 *)(val + 0x30) + (obj & 0xff)) >> 3 & 1) == 0) {
        return in_x0;
      }
      puVar5 = (uint1 *)env[3];
      if ((uint1 *)env[2] < puVar5) {
        puVar3 = (uint1 *)env[2] + 1;
        env[2] = (int8)puVar3;
      }
      else {
        cls = (*env)->GetSuperclass(env);
        if (cls == -1) goto code_r0x00022e04;
        puVar3 = (uint1 *)env[2];
        puVar5 = (uint1 *)env[3];
      }
      if (puVar3 < puVar5) break;
code_r0x00022dec:
      obj = (*env)->ToReflectedMethod(env);
      if ((int4)obj == -1) {
code_r0x00022e04:
        sub_1ED34();
        return in_x0;
      }
    }
  } while( true );
}