uint64_t sub_1E598(void)

{
  int4 val;
  uint64_t *in_x0;
  uint64_t ret;
  char *in_x1;
  
  sub_1E3C8(in_x0,0,0);
  *in_x0 = 0xbcd20;
  val = strcmp(in_x1,(char *)"nu.version_r");
  if ((val != 0) && (val = strcmp(in_x1,(char *)"POSIX"), val != 0)) {
    func_0x0006f8d4(in_x0 + 2);
    ret = func_0x0006f8a0(in_x0 + 2);
    return ret;
  }
  return 0;
}