void * _Znwm(void)

{
  uint8 in_x0;
  void *pvVar1;
  code *pcVar2;
  int8 *param1;
  
  if (in_x0 == 0) {
    in_x0 = 1;
  }
  pvVar1 = malloc(in_x0);
  while( true ) {
    if (pvVar1 != (void *)0x0) {
      return pvVar1;
    }
    pcVar2 = (code *)_ZSt15get_new_handlerv();
    if (pcVar2 == (code *)0x0) break;
    (*pcVar2)();
    pvVar1 = malloc(in_x0);
  }
  param1 = __cxa_allocate_exception(8);
  *param1 = _ZTVSt9bad_alloc + 0x10;
  __cxa_throw(param1,pvRam00000000000bfa70,pvRam00000000000bfad8);
}