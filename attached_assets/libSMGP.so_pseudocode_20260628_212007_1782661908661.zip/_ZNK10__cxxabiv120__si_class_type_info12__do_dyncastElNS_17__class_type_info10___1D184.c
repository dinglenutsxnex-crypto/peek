uint8 _ZNK10__cxxabiv120__si_class_type_info12__do_dyncastElNS_17__class_type_info10__sub_kindEPKS1_PKvS4_S6_RNS1_16__dyncast_resultE
                (void)

{
  char cVar1;
  uint1 val1;
  int4 val2;
  int8 in_x0;
  uint8 ret;
  uint32_t val3;
  int8 in_x1;
  uint32_t in_w2;
  int8 in_x3;
  int8 in_x4;
  int8 in_x5;
  int8 in_x6;
  int8 *in_x7;
  char *param1;
  
  param1 = *(char **)(in_x0 + 8);
  if (param1 == *(char **)(in_x3 + 8)) {
code_r0x0001d228:
    *in_x7 = in_x4;
    *(uint32_t *)(in_x7 + 1) = in_w2;
    if (-1 < in_x1) {
      val3 = 6;
      if (in_x6 != in_x4 + in_x1) {
        val3 = 1;
      }
      *(uint32_t *)(in_x7 + 2) = val3;
      return 0;
    }
    ret = 0;
    if (in_x1 == -2) {
      *(uint32_t *)(in_x7 + 2) = 1;
    }
  }
  else {
    cVar1 = *param1;
    if (cVar1 != '*') {
      val2 = strcmp(param1,*(char **)(in_x3 + 8));
      if (val2 == 0) goto code_r0x0001d228;
    }
    if (in_x4 == in_x6) {
      if (param1 == *(char **)(in_x5 + 8)) {
code_r0x0001d2c4:
        *(uint32_t *)((int8)in_x7 + 0xc) = in_w2;
        return 0;
      }
      if (cVar1 != '*') {
        val2 = strcmp(param1,*(char **)(in_x5 + 8));
        if (val2 == 0) goto code_r0x0001d2c4;
      }
    }
    val1 = (**(code **)(**(int8 **)(in_x0 + 0x10) + 0x38))(*(int8 **)(in_x0 + 0x10));
    ret = (uint8)val1;
  }
  return ret;
}