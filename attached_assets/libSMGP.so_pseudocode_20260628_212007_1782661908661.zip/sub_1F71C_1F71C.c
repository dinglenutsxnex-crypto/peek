int8 sub_1F71C(void)

{
  uint4 val1;
  uint4 val2;
  int8 in_x0;
  uint4 in_w1;
  
  val2 = in_w1 | *(uint4 *)(in_x0 + 0x20);
  val1 = val2 | 1;
  if (*(int8 *)(in_x0 + 0xe8) != 0) {
    val1 = val2;
  }
  *(uint4 *)(in_x0 + 0x20) = val1;
  if ((val1 & *(uint4 *)(in_x0 + 0x1c)) == 0) {
    return in_x0;
  }
  func_0x00062640("basic_ios::clear");
}