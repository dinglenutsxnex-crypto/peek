uint64_t _ZN10__cxxabiv120__si_class_type_infoD0Ev(void)

{
  void *in_x0;
  uint64_t extraout_x0;
  
  _ZN10__cxxabiv120__si_class_type_infoD1Ev();
  _ZdlPv(in_x0);
  return extraout_x0;
}