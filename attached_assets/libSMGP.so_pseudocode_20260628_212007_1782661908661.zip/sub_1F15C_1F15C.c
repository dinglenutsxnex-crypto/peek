uint8 sub_1F15C(void)

{
  jclass cls;
  int8 in_x0;
  uint1 in_w1;
  int8 *env;
  
  env = *(int8 **)(in_x0 + 0xf0);
  if (env == (int8 *)0x0) {
    func_0x00061e30();
  }
  if ((char)env[7] != '\0') {
    return (uint8)*(uint1 *)((int8)env + (int8)(int4)(uint4)in_w1 + 0x39);
  }
  sub_1DFC0();
  cls = (*env)->FindClass(env,in_w1);
  return (uint8)cls;
}