uint64_t _Z22startActivityPermissonP7_JNIEnvP8_jobject(void)

{
  int8 val1;
  int8 val2;
  int8 val3;
  char cVar4;
  bool bVar5;

  int8 *piVar7;
  int8 val4;
  int8 *env;
  char *param1;
  uint8 val5;
  uint64_t ret;
  int4 *piVar11;
  int4 val6;
  int8 iStack_1f0;
  uint8_t axStack_1e8 [8];
  int8 aiStack_1e0 [2];
  int8 aiStack_1d0 [4];
  uint4 auStack_1b0 [8];
  uint8_t axStack_190 [8];

  int8 iStack_180;
  int8 aiStack_178 [27];

  (*env)->GetObjectClass();
  (*env)->GetMethodID();
  (*env)->GetMethodID();
  _ZN7_JNIEnv16CallObjectMethodEP8_jobjectP10_jmethodIDz();
  param1 = (char *)(*env)->GetStringUTFChars();
  func_0x0001ff5c(aiStack_178);
  piVar7 = piRam00000000000bfc90;
  ret = 0;
  aiStack_178[0] = unk_bfb30 + 0x10;
  val1 = piRam00000000000bfc90[2];
  val2 = piRam00000000000bfc90[3];
  ret = 0;
  aiStack_1e0[0] = val1;
  *(int8 *)((int8)aiStack_1e0 + *(int8 *)(val1 + -0x18)) = val2;
  aiStack_1e0[1] = 0;
  func_0x0001f208((int8)aiStack_1e0 + *(int8 *)(aiStack_1e0[0] + -0x18),0);
  aiStack_1d0[0] = piVar7[4];
  *(int8 *)((int8)aiStack_1d0 + *(int8 *)(aiStack_1d0[0] + -0x18)) = piVar7[5];
  func_0x0001f208((int8)aiStack_1d0 + *(int8 *)(aiStack_1d0[0] + -0x18),0);
  *(int8 *)((int8)aiStack_1e0 + *(int8 *)(piVar7[1] + -0x18)) = piVar7[6];
  aiStack_1d0[0] = "h" + 0x40;
  auStack_1b0[4] = 0;
  auStack_1b0[5] = 0;
  auStack_1b0[6] = 0;
  auStack_1b0[7] = 0;
  aiStack_1d0[1] = unk_bfc70 + 0x10;
  aiStack_1e0[0] = "h" + 0x18;
  aiStack_178[0] = "h" + 0x68;
  auStack_1b0[0] = 0;
  auStack_1b0[1] = 0;
  auStack_1b0[2] = 0;
  auStack_1b0[3] = 0;
  aiStack_1d0[2] = 0;
  aiStack_1d0[3] = 0;
  func_0x0003bc18(axStack_190);
  ret = 0x18;
  aiStack_1d0[1] = unk_bfd48 + 0x10;
  iStack_180 = unk_bff48 + 0x18;
  func_0x0001f208((int8)aiStack_1e0 + *(int8 *)(aiStack_1e0[0] + -0x18),aiStack_1d0 + 1);
  func_0x0003e580(aiStack_1d0,"package:",8);
  if (param1 == (char *)0x0) {
    func_0x0001ed34((int8)aiStack_1d0 + *(int8 *)(aiStack_1d0[0] + -0x18),
                    *(uint4 *)((int8)auStack_1b0 + *(int8 *)(aiStack_1d0[0] + -0x18)) | 1);
  }
  else {
    val5 = strlen(param1);
    func_0x0003e580(aiStack_1d0,param1,val5);
  }
  func_0x00043ac8(&iStack_1f0,aiStack_1d0 + 1);
  (*env)->FindClass();
  (*env)->GetStaticMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv22CallStaticObjectMethodEP7_jclassP10_jmethodIDz();
  (*env)->FindClass();
  (*env)->GetMethodID();
  (*env)->NewStringUTF();
  _ZN7_JNIEnv9NewObjectEP7_jclassP10_jmethodIDz();
  _ZN7_JNIEnv14CallVoidMethodEP8_jobjectP10_jmethodIDz();
  val4 = unk_bff48;
  if (iStack_1f0 + -0x18 != unk_bff48) {
    piVar11 = (int4 *)(iStack_1f0 + -8);
    if (pthread_create == 0) {
      val6 = *piVar11;
      *piVar11 = val6 + -1;
    }
    else {
      do {
        val6 = *piVar11;
        cVar4 = '\x01';
        bVar5 = (bool)ExclusiveMonitorPass(piVar11,0x10);
        if (bVar5) {
          *piVar11 = val6 + -1;
          cVar4 = ExclusiveMonitorsStatus();
        }
      } while (cVar4 != '\0');
    }
    if (val6 < 1) {
      func_0x00066f0c(iStack_1f0 + -0x18,axStack_1e8);
    }
  }
  aiStack_1e0[0] = *piVar7;
  val3 = piVar7[9];
  *(int8 *)((int8)aiStack_1e0 + *(int8 *)(aiStack_1e0[0] + -0x18)) = piVar7[8];
  aiStack_1d0[1] = unk_bfd48 + 0x10;
  aiStack_1d0[0] = val3;
  if (iStack_180 + -0x18 != val4) {
    piVar11 = (int4 *)(iStack_180 + -8);
    if (pthread_create == 0) {
      val6 = *piVar11;
      *piVar11 = val6 + -1;
    }
    else {
      do {
        val6 = *piVar11;
        cVar4 = '\x01';
        bVar5 = (bool)ExclusiveMonitorPass(piVar11,0x10);
        if (bVar5) {
          *piVar11 = val6 + -1;
          cVar4 = ExclusiveMonitorsStatus();
        }
      } while (cVar4 != '\0');
    }
    if (val6 < 1) {
      func_0x00066f0c(iStack_180 + -0x18,&iStack_1f0);
    }
  }
  aiStack_1d0[1] = unk_bfc70 + 0x10;
  func_0x0003a188(axStack_190);
  aiStack_1e0[0] = val1;
  *(int8 *)((int8)aiStack_1e0 + *(int8 *)(val1 + -0x18)) = val2;
  aiStack_1e0[1] = 0;
  ret = func_0x000202fc(aiStack_178);

  return ret;
}