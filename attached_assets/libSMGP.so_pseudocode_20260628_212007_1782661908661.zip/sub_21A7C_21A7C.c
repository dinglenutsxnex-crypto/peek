int8 * sub_21A7C(void)

{
  bool bVar1;
  jobject obj;
  jclass cls;
  int8 *in_x0;
  uint1 *puVar4;
  uint8_t *in_x1;
  int8 in_x2;
  uint1 *puVar5;
  uint1 in_w3;
  int8 *env;
  uint8_t *pxVar7;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') {
    bVar1 = false;
  }
  else {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    puVar4 = (uint1 *)env[2];
    if ((uint1 *)env[3] <= puVar4) goto code_r0x00021b38;
code_r0x00021adc:
    obj = (uint4)*puVar4;
code_r0x00021ae0:
    pxVar7 = in_x1;
    if (obj != JNI_ERR && obj != in_w3) {
      do {
        in_x1 = pxVar7;
        if (in_x2 <= in_x0[1] + 1) break;
        in_x1 = pxVar7 + 1;
        *pxVar7 = (char)obj;
        puVar4 = (uint1 *)env[2];
        puVar5 = (uint1 *)env[3];
        in_x0[1] = in_x0[1] + 1;
        if (puVar4 < puVar5) {
          puVar4 = puVar4 + 1;
          env[2] = (int8)puVar4;
        }
        else {
          cls = (*env)->GetSuperclass(env);
          obj = JNI_ERR;
          if (cls == -1) goto code_r0x00021ae0;
          puVar4 = (uint1 *)env[2];
          puVar5 = (uint1 *)env[3];
        }
        if (puVar4 < puVar5) goto code_r0x00021adc;
code_r0x00021b38:
        obj = (*env)->ToReflectedMethod(env);
        pxVar7 = in_x1;
        if (obj == JNI_ERR || obj == in_w3) break;
      } while( true );
    }
    bVar1 = obj == JNI_ERR;
  }
  if (0 < in_x2) {
    *in_x1 = 0;
  }
  if ((in_x0[1] != 0) && (!bVar1)) {
    return in_x0;
  }
  sub_1ED34();
  return in_x0;
}