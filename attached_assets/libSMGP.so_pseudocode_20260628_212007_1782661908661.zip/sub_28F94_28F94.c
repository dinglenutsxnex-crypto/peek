uint64_t sub_28F94(void)

{
  void *in_x0;
  uint64_t extraout_x0;
  
  sub_28E34();
  _ZdlPv(in_x0);
  return extraout_x0;
}