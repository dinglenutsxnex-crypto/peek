uint8 sub_24F98(void)

{
  jobject obj;
  int8 *in_x0;
  int8 *env;
  uint8 ret;
  char cStack_8;
  
  ret = JNI_ERR;
  in_x0[1] = 0;
  sub_24104();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if ((uint4 *)env[2] < (uint4 *)env[3]) {
      obj = *(uint4 *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod();
    }
    ret = (uint8)obj;
    if (obj == JNI_ERR) {
      sub_1F6E0();
      return JNI_ERR;
    }
  }
  return ret;
}