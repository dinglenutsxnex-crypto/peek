int8 sub_20210(void)

{
  int8 in_x0;
  uint32_t in_w1;
  int8 *piVar1;
  
  for (piVar1 = *(int8 **)(in_x0 + 0x28); piVar1 != (int8 *)0x0; piVar1 = (int8 *)*piVar1) {
    in_x0 = (*(code *)piVar1[1])(in_w1);
  }
  return in_x0;
}