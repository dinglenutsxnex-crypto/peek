int8 * sub_22284(void)

{
  int8 *in_x0;
  int8 val;
  int8 in_x2;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    val = (*env)->FromReflectedField(env);
    in_x0[1] = val;
    if (in_x2 != val) {
      sub_1ED34();
      return in_x0;
    }
  }
  return in_x0;
}