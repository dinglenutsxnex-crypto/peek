uint64_t sub_28DD0(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xbab30;
  if (*(char *)((int8)in_x0 + 0x6f) != '\0') {
    if ((void *)in_x0[2] != (void *)0x0) {
      _ZdaPv((void *)in_x0[2]);
    }
    if ((void *)in_x0[5] != (void *)0x0) {
      _ZdaPv((void *)in_x0[5]);
    }
    if ((void *)in_x0[7] != (void *)0x0) {
      _ZdaPv((void *)in_x0[7]);
    }
    if ((void *)in_x0[9] != (void *)0x0) {
      _ZdaPv((void *)in_x0[9]);
    }
  }
}