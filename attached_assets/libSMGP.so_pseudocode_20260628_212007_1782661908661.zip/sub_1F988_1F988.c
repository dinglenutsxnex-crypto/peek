uint64_t sub_1F988(void)

{
  int8 in_x0;
  int8 *env;
  jclass cls;
  
  if (*(char *)(in_x0 + 0xe4) != '\0') {
    return (uint8)*(uint4 *)(in_x0 + 0xe0);
  }
  env = *(int8 **)(in_x0 + 0xf0);
  if (env != (int8 *)0x0) {
    cls = (*env)->GetSuperclass(env,0x20);
    *(int4 *)(in_x0 + 0xe0) = (int4)cls;
    *(uint8_t *)(in_x0 + 0xe4) = 1;
    jclass cls;
  }
  func_0x00061e30();
}