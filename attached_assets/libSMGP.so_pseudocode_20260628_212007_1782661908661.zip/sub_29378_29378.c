uint64_t sub_29378(void)

{
  uint64_t *in_x0;
  void *pvVar1;
  void *param1;
  
  param1 = (void *)in_x0[4];
  *in_x0 = 0xba8b0;
  pvVar1 = (void *)func_0x00039f3c();
  if ((param1 != pvVar1) && (param1 != (void *)0x0)) {
    _ZdaPv(param1);
  }
  if ((int8 *)in_x0[2] != (int8 *)0x0) {
    (**(code **)(*(int8 *)in_x0[2] + 8))();
  }
  func_0x0006f8d4(in_x0 + 3);
}