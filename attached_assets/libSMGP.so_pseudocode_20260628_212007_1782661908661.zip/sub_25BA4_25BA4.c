int8 * sub_25BA4(void)

{
  char cVar1;
  jobject obj;
  int8 *in_x0;
  int8 *piVar3;
  int4 *piVar4;
  int8 *env;
  uint8_t axStack_8 [8];
  
  func_0x0003989c(axStack_8,(int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xd0);
  piVar3 = (int8 *)func_0x0004c214(axStack_8);
  func_0x0003a188(axStack_8);
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  piVar4 = (int4 *)env[2];
  if ((int4 *)env[3] <= piVar4) goto code_r0x00025c74;
  while (*piVar4 != -1) {
    while( true ) {
      cVar1 = (**(code **)(*piVar3 + 0x10))(piVar3,8);
      if (cVar1 == '\0') {
        return in_x0;
      }
      piVar4 = (int4 *)env[2];
      if (piVar4 < (int4 *)env[3]) {
        obj = *piVar4;
        env[2] = (int8)(piVar4 + 1);
      }
      else {
        obj = (*env)->GetSuperclass(env);
      }
      if (obj == -1) goto code_r0x00025c90;
      piVar4 = (int4 *)env[2];
      if (piVar4 < (int4 *)env[3]) break;
code_r0x00025c74:
      obj = (*env)->ToReflectedMethod(env);
      if (obj == -1) goto code_r0x00025c90;
    }
  }
code_r0x00025c90:
  sub_1F6E0();
  return in_x0;
}