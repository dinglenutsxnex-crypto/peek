uint64_t _ZSt14set_unexpectedPFvvE(void)

{
  char cVar1;
  bool bVar2;
  uint64_t *pxVar3;
  uint64_t in_x0;
  uint64_t ret;
  
  pxVar3 = pxRam00000000000bfd10;
  do {
    ret = *pxVar3;
    cVar1 = '\x01';
    bVar2 = (bool)ExclusiveMonitorPass(pxVar3,0x10);
    if (bVar2) {
      *pxVar3 = in_x0;
      cVar1 = ExclusiveMonitorsStatus();
    }
  } while (cVar1 != '\0');
  return ret;
}