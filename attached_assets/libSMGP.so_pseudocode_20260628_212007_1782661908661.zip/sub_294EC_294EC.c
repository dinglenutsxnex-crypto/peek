uint8 sub_294EC(void)

{
  uint8 *param1;
  char *pcVar1;
  bool bVar2;
  uint4 val1;
  uint8 *puVar4;
  uint8 val2;
  char *in_x1;
  char *in_x2;
  char *in_x3;
  char *in_x4;
  uint8 unaff_x19;
  uint8 ret;
  uint8 *param1_00;
  uint8 *unaff_x23;
  uint8 *param1_01;
  uint8 val3;
  uint8_t axStack_8 [8];
  
  if (in_x1 == in_x2) {
    param1_00 = puRam00000000000bff48 + 3;
    goto code_r0x00029580;
  }
  if ((in_x1 == (char *)0x0) && (in_x2 != (char *)0x0)) {
    func_0x00061e98("basic_string::_S_construct null not valid");
  }
  unaff_x19 = (int8)in_x2 - (int8)in_x1;
  unaff_x23 = (uint8 *)func_0x00065788(unaff_x19,0,axStack_8);
  param1_00 = unaff_x23 + 3;
  if (unaff_x19 == 1) goto code_r0x0002959c;
  memcpy(param1_00,in_x1,unaff_x19);
  while( true ) {
    if (unaff_x23 != puRam00000000000bff48) {
      *(uint32_t *)(unaff_x23 + 2) = 0;
      *unaff_x23 = unaff_x19;
      *(char *)((int8)unaff_x23 + unaff_x19 + 0x18) = '\0';
    }
code_r0x00029580:
    if (in_x3 == in_x4) {
      param1_01 = puRam00000000000bff48 + 3;
      goto code_r0x000295e0;
    }
    if ((in_x3 != (char *)0x0) || (in_x4 == (char *)0x0)) break;
    func_0x00061e98("basic_string::_S_construct null not valid");
code_r0x0002959c:
    *(char *)(unaff_x23 + 3) = *in_x1;
  }
  ret = (int8)in_x4 - (int8)in_x3;
  puVar4 = (uint8 *)func_0x00065788(ret,0,axStack_8);
  param1_01 = puVar4 + 3;
  if (ret == 1) {
    *(char *)(puVar4 + 3) = *in_x3;
  }
  else {
    memcpy(param1_01,in_x3,ret);
  }
  if (puVar4 != puRam00000000000bff48) {
    *(uint32_t *)(puVar4 + 2) = 0;
    *puVar4 = ret;
    *(char *)((int8)puVar4 + ret + 0x18) = '\0';
  }
code_r0x000295e0:
  val3 = param1_00[-3];
  ret = param1_01[-3];
  val1 = func_0x0006ffa4();
  puVar4 = param1_00;
  param1 = param1_01;
  while (val1 == 0) {
    val2 = strlen((char *)puVar4);
    pcVar1 = (char *)((int8)puVar4 + val2);
    val2 = strlen((char *)param1);
    bVar2 = pcVar1 == (char *)((int8)param1_00 + val3);
    if ((char *)((int8)param1 + val2) == (char *)((int8)param1_01 + ret)) {
      ret = (uint8)!bVar2;
code_r0x00029640:
      if (param1_01 + -3 != puRam00000000000bff48) goto code_r0x000296b0;
      goto code_r0x00029650;
    }
    if (bVar2) {
      ret = 0xffffffff;
      goto code_r0x00029640;
    }
    puVar4 = (uint8 *)(pcVar1 + 1);
    param1 = (uint8 *)((char *)((int8)param1 + val2) + 1);
    val1 = func_0x0006ffa4();
  }
  ret = (uint8)val1;
  if (param1_01 + -3 == puRam00000000000bff48) {
code_r0x00029650:
    if (param1_00 + -3 != puRam00000000000bff48) goto code_r0x000296cc;
  }
  else {
code_r0x000296b0:
    func_0x00029454(param1_01 + -3,axStack_8);
    if (param1_00 + -3 != puRam00000000000bff48) {
code_r0x000296cc:
      func_0x00029454(param1_00 + -3,axStack_8);
      return ret;
    }
  }
  return ret;
}