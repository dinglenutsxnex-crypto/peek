int8 * sub_22028(void)

{
  jclass cls;
  int8 *in_x0;
  int8 *env;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_21204();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if ((uint8)env[2] < (uint8)env[3]) {
      env[2] = env[2] + 1;
    }
    else {
      cls = (*env)->GetSuperclass();
      if (cls == -1) {
        sub_1ED34();
        return in_x0;
      }
    }
    in_x0[1] = 1;
  }
  return in_x0;
}