uint8 sub_1D3F0(void)

{
  int4 val;
  int8 in_x0;
  char *param1;
  int8 in_x1;
  
  param1 = *(char **)(in_x0 + 8);
  if (param1 == *(char **)(in_x1 + 8)) {
    return 1;
  }
  if (*param1 != '*') {
    val = strcmp(param1,*(char **)(in_x1 + 8));
    return (uint8)(val == 0);
  }
  return 0;
}