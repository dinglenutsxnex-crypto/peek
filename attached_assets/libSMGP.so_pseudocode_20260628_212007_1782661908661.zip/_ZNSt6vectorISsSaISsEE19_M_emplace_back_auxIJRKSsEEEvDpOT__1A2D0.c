int8 _ZNSt6vectorISsSaISsEE19_M_emplace_back_auxIJRKSsEEEvDpOT_(void)

{
  uint8 val1;
  uint8 val2;
  int8 *piVar3;
  char cVar4;
  bool bVar5;

  int8 val3;
  int8 val4;
  int8 val5;
  int8 *in_x0;
  int8 *piVar10;
  int8 val6;
  int8 extraout_x0;
  uint8 val7;
  int4 *piVar13;
  int4 val8;
  int8 *piVar15;
  int8 *piVar16;
  int8 *piVar17;
  int8 *param1;
  uint8_t axStack_70 [8];




  val7 = in_x0[1] - *in_x0 >> 3;
  val2 = val7;
  if (in_x0[1] - *in_x0 == 0) {
    val2 = 1;
  }
  val1 = 0x1fffffffffffffff;
  if (!CARRY8(val2,val7) && val2 + val7 >> 0x3d == 0) {
    val1 = val2 + val7;
  }
  if (val1 == 0) {
    piVar10 = (int8 *)0x0;
  }
  else {
    if (val1 >> 0x3d != 0) goto code_r0x0001a480;
    piVar10 = _Znwm(val1 << 3);
    val7 = in_x0[1] - *in_x0 >> 3;
  }
  val6 = func_0x00067090(piVar10 + val7);
  val5 = unk_bff48;
  param1 = (int8 *)*in_x0;
  piVar3 = (int8 *)in_x0[1];
  if (param1 == piVar3) {
    piVar3 = piVar10 + 1;
  }
  else {
    val6 = unk_bff48 + 0x18;
    piVar15 = piVar10;
    piVar16 = param1;
    do {
      *piVar15 = *piVar16;
      piVar17 = piVar16 + 1;
      *piVar16 = val6;
      val4 = pthread_create;
      piVar15 = piVar15 + 1;
      piVar16 = piVar17;
    } while (piVar3 != piVar17);
    val3 = -8 - (int8)param1;
    do {
      val6 = *param1 + -0x18;
      if (val6 != val5) {
        piVar13 = (int4 *)(*param1 + -8);
        if (val4 == 0) {
          val8 = *piVar13;
          *piVar13 = val8 + -1;
        }
        else {
          do {
            val8 = *piVar13;
            cVar4 = '\x01';
            bVar5 = (bool)ExclusiveMonitorPass(piVar13,0x10);
            if (bVar5) {
              *piVar13 = val8 + -1;
              cVar4 = ExclusiveMonitorsStatus();
            }
          } while (cVar4 != '\0');
        }
        if (val8 < 1) {
          val6 = func_0x00066f0c(val6,axStack_70);
        }
      }
      param1 = param1 + 1;
    } while (param1 != piVar3);
    param1 = (int8 *)*in_x0;
    piVar3 = (int8 *)((int8)piVar10 + ((int8)piVar3 + val3 & 0xfffffffffffffff8U) + 0x10);
  }
  if (param1 != (int8 *)0x0) {
    _ZdlPv(param1);
    val6 = extraout_x0;
  }
  *in_x0 = (int8)piVar10;
  in_x0[1] = (int8)piVar3;
  in_x0[2] = (int8)(piVar10 + val1);



  __stack_chk_fail();
code_r0x0001a480:
  func_0x00061dfc();
}