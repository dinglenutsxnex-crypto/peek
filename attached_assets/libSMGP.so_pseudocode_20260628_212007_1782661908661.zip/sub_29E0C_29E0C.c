void sub_29E0C(uint64_t *param_1,uint64_t param_2,int8 param_3)

{
  *(uint4 *)(param_1 + 1) = (uint4)(param_3 != 0);
  param_1[2] = param_2;
  *param_1 = 0xbd1d0;
  func_0x0003c7f4(param_1,0,0);
  return;
}