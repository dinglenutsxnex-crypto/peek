uint64_t sub_20DCC(void)

{
  int8 in_x0;
  uint64_t in_x8;
  
  func_0x0003989c();
  func_0x0003a0e8(in_x0 + 0xd0);
  sub_20210();
  return in_x8;
}