void start(int8 param_1)

{
  int4 *piVar1;
  char cVar2;
  bool bVar3;
  int4 val;
  
  if (pthread_create == 0) {
    val = *(int4 *)(param_1 + 0x10);
    *(int4 *)(param_1 + 0x10) = val + -1;
  }
  else {
    piVar1 = (int4 *)(param_1 + 0x10);
    do {
      val = *piVar1;
      cVar2 = '\x01';
      bVar3 = (bool)ExclusiveMonitorPass(piVar1,0x10);
      if (bVar3) {
        *piVar1 = val + -1;
        cVar2 = ExclusiveMonitorsStatus();
      }
    } while (cVar2 != '\0');
  }
  if (0 < val) {
    return;
  }
}