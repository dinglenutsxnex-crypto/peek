int8 _Z8resPatchPKcS0_(void)

{
  uint4 val1;
  uint8_t val2;
  bool bVar3;

  jclass cls;
  char *in_x0;
  int8 *env;
  uint8 val3;
  uint8 val4;
  int8 val5;

  int8 val6;
  int4 *piVar12;
  int4 val7;
  uint8_t axStack_448 [8];
  int8 iStack_440;
  uint8_t axStack_438 [8];
  int8 iStack_430;
  uint8_t axStack_428 [8];
  int8 iStack_420;
  int8 iStack_418;
  int8 iStack_410;
  uint8_t axStack_408 [8];
  int8 aiStack_400 [3];
  uint64_t xStack_3e8;

  uint8_t axStack_3c0 [8];

  int8 iStack_3b0;
  int8 aiStack_3a8 [17];
  char acStack_320 [16];
  uint64_t axStack_310 [8];

  uint8_t axStack_298 [32];
  int8 aiStack_278 [4];
  uint4 auStack_258 [10];
  uint8_t axStack_230 [48];
  uint8_t axStack_200 [136];
  uint8_t axStack_178 [264];

  func_0x00067090(aiStack_278,fullLibPatch);
  func_0x0006433c(aiStack_278,"/",1);
  strlen(in_x1);
  env = (int8 *)func_0x0006433c(aiStack_278);
  val6 = unk_bff48;
  iStack_410 = *env;
  *env = unk_bff48 + 0x18;
  if (aiStack_278[0] + -0x18 != val6) {
    piVar12 = (int4 *)(aiStack_278[0] + -8);
    if (pthread_create == 0) {
      val7 = *piVar12;
      *piVar12 = val7 + -1;
    }
    else {
      do {
        val7 = *piVar12;
        cls = '\x01';
        bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
        if (bVar3) {
          *piVar12 = val7 + -1;
          cls = ExclusiveMonitorsStatus();
        }
      } while (cls != '\0');
    }
    if (val7 < 1) {
      func_0x00066f0c(aiStack_278[0] + -0x18,aiStack_400);
    }
  }
  val3 = strtoul(in_x0,(void *)0x0,0x10);
  func_0x0005d41c(aiStack_278,&iStack_410,4);
  val4 = func_0x0001d778(axStack_200);
  if ((val4 & 1) != 0) {
    func_0x00022bdc(aiStack_278,val3,0);
    if ((*(uint1 *)((int8)auStack_258 + *(int8 *)(aiStack_278[0] + -0x18)) & 5) == 0) {
      func_0x00022284(aiStack_278,axStack_298,0x20);
      val1 = *(uint4 *)((int8)auStack_258 + *(int8 *)(aiStack_278[0] + -0x18));
      val5 = func_0x0005bef8(aiStack_278 + 2);
      if (val5 == 0) {
        func_0x0001ed34((int8)aiStack_278 + *(int8 *)(aiStack_278[0] + -0x18),
                        *(uint4 *)((int8)auStack_258 + *(int8 *)(aiStack_278[0] + -0x18)) | 4);
      }
      if ((val1 & 5) == 0) {
        func_0x0001ff5c(aiStack_3a8);
        xStack_3e8 = 0;
        aiStack_3a8[0] = unk_bfb30 + 0x10;
        aiStack_400[0] = piRam00000000000bfa38[1];
        xStack_3e8 = 0;
        *(int8 *)((int8)aiStack_400 + *(int8 *)(aiStack_400[0] + -0x18)) = piRam00000000000bfa38[2];
        func_0x0001f208((int8)aiStack_400 + *(int8 *)(aiStack_400[0] + -0x18),0);
        aiStack_3a8[0] = "X" + 0x40;
        aiStack_400[0] = "X" + 0x18;
        aiStack_400[1] = unk_bfc70 + 0x10;
        val4 = (uint8)aiStack_400 | 8;
        xStack_3e8 = 0;
        aiStack_400[2] = 0;
        xStack_3e8 = 0;
        func_0x0003bc18();
        xStack_3e8 = 0x10;
        iStack_3b0 = val6 + 0x18;
        aiStack_400[1] = unk_bfd48 + 0x10;
        func_0x0001f208((int8)aiStack_400 + *(int8 *)(aiStack_400[0] + -0x18),val4);
        val3 = 0;
        do {
          *(uint4 *)((int8)&xStack_3e8 + *(int8 *)(aiStack_400[0] + -0x18)) =
               *(uint4 *)((int8)&xStack_3e8 + *(int8 *)(aiStack_400[0] + -0x18)) & 0xffffffb5 | 8;
          *(uint64_t *)((int8)aiStack_400 + *(int8 *)(aiStack_400[0] + -0x18) + 0x10) = 2;
          val6 = *(int8 *)(aiStack_400[0] + -0x18);
          if (acStack_320[val6 + 1] == '\0') {
            env = *(int8 **)((int8)axStack_310 + val6);
            if (env == (int8 *)0x0) goto code_r0x000195f0;
            if ((char)env[7] == '\0') {
              func_0x0001dfc0(env);
              cls = (*env)->FindClass(env,"lease)");
            }
            else {
              cls = *(char *)((int8)env + 0x59);
            }
            acStack_320[val6] = cls;
            acStack_320[val6 + 1] = '\x01';
          }
          val2 = axStack_298[val3];
          acStack_320[val6] = '0';
          in_x0 = func_0x0003edf0(aiStack_400,val2);
          func_0x0003e580(xVar10," ",1);
          val3 = val3 + 1;
        } while (val3 < 0x20);
        func_0x00043ac8(&iStack_418,val4);
        func_0x00063720(&iStack_420,in_x0,axStack_428);
        func_0x00063720(&iStack_430,iStack_418,axStack_438);
        func_0x00063720(&iStack_440,in_x1,axStack_448);
        _Z8hexPatchRKSsS0_S0_(&iStack_420,&iStack_430,&iStack_440);
        val6 = unk_bff48;
        if (iStack_440 + -0x18 != unk_bff48) {
          piVar12 = (int4 *)(iStack_440 + -8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 + -1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 + -1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            func_0x00066f0c(iStack_440 + -0x18,axStack_408);
          }
        }
        if (iStack_430 + -0x18 != val6) {
          piVar12 = (int4 *)(iStack_430 + -8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 + -1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 + -1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            func_0x00066f0c(iStack_430 + -0x18,&iStack_440);
          }
        }
        if (iStack_420 + -0x18 != val6) {
          piVar12 = (int4 *)(iStack_420 + -8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 + -1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 + -1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            func_0x00066f0c(iStack_420 + -0x18,&iStack_430);
          }
        }
        if (iStack_418 + -0x18 != val6) {
          piVar12 = (int4 *)(iStack_418 + -8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 + -1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 + -1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            func_0x00066f0c(iStack_418 + -0x18,&iStack_420);
          }
        }
        aiStack_400[0] = *piRam00000000000bfa38;
        *(int8 *)((int8)aiStack_400 + *(int8 *)(aiStack_400[0] + -0x18)) = piRam00000000000bfa38[3];
        aiStack_400[1] = unk_bfd48 + 0x10;
        if (iStack_3b0 + -0x18 != val6) {
          piVar12 = (int4 *)(iStack_3b0 + -8);
          if (pthread_create == 0) {
            val7 = *piVar12;
            *piVar12 = val7 + -1;
          }
          else {
            do {
              val7 = *piVar12;
              cls = '\x01';
              bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
              if (bVar3) {
                *piVar12 = val7 + -1;
                cls = ExclusiveMonitorsStatus();
              }
            } while (cls != '\0');
          }
          val6 = unk_bff48;
          if (val7 < 1) {
            func_0x00066f0c(iStack_3b0 + -0x18,&iStack_418);
          }
        }
        aiStack_400[1] = unk_bfc70 + 0x10;
        func_0x0003a188(axStack_3c0);
        func_0x000202fc(aiStack_3a8);
      }
    }
    else {
      val5 = func_0x0005bef8(aiStack_278 + 2);
      if (val5 == 0) {
        func_0x0001ed34((int8)aiStack_278 + *(int8 *)(aiStack_278[0] + -0x18),
                        *(uint4 *)((int8)auStack_258 + *(int8 *)(aiStack_278[0] + -0x18)) | 4);
      }
    }
  }
  env = piRam00000000000bff10;
  aiStack_278[0] = *piRam00000000000bff10;
  *(int8 *)((int8)aiStack_278 + *(int8 *)(aiStack_278[0] + -0x18)) = piRam00000000000bff10[3];
  aiStack_278[2] = unk_bff70 + 0x10;
  func_0x0005bef8(aiStack_278 + 2);
  func_0x0001d58c(axStack_200);
  aiStack_278[2] = unk_bfc70 + 0x10;
  func_0x0003a188(axStack_230);
  aiStack_278[0] = env[1];
  *(int8 *)((int8)aiStack_278 + *(int8 *)(aiStack_278[0] + -0x18)) = env[2];
  aiStack_278[1] = 0;
  func_0x000202fc(axStack_178);
  val5 = iStack_410 + -0x18;
  if (val5 != val6) {
    piVar12 = (int4 *)(iStack_410 + -8);
    if (pthread_create == 0) {
      val7 = *piVar12;
      *piVar12 = val7 + -1;
    }
    else {
      do {
        val7 = *piVar12;
        cls = '\x01';
        bVar3 = (bool)ExclusiveMonitorPass(piVar12,0x10);
        if (bVar3) {
          *piVar12 = val7 + -1;
          cls = ExclusiveMonitorsStatus();
        }
      } while (cls != '\0');
    }
    if (val7 < 1) {
      val5 = func_0x00066f0c(val5,aiStack_278);
    }
  }

  __stack_chk_fail();
code_r0x000195f0:
  func_0x00061e30();
}