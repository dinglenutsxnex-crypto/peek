int8 * sub_29778(void)

{
  uint8 *puVar1;
  void *param1;
  uint8 val1;
  int8 val2;
  char *in_x1;
  int8 val3;
  char *in_x2;
  int8 *in_x8;
  uint8 val4;
  uint8 val5;
  uint8 *param1_00;
  uint8_t axStack_8 [8];
  
  param1_00 = puRam00000000000bff48 + 3;
  *in_x8 = (int8)param1_00;
  if (in_x1 == in_x2) {
    val4 = 0;
  }
  else {
    if ((in_x1 == (char *)0x0) && (in_x2 != (char *)0x0)) {
      func_0x00061e98("basic_string::_S_construct null not valid");
    }
    val4 = (int8)in_x2 - (int8)in_x1;
    puVar1 = (uint8 *)func_0x00065788(val4,0,axStack_8);
    param1_00 = puVar1 + 3;
    if (val4 == 1) {
      *(char *)(puVar1 + 3) = *in_x1;
    }
    else {
      memcpy(param1_00,in_x1,val4);
    }
    if (puVar1 != puRam00000000000bff48) {
      *(uint32_t *)(puVar1 + 2) = 0;
      *puVar1 = val4;
      *(char *)((int8)puVar1 + val4 + 0x18) = '\0';
    }
  }
  val4 = val4 << 1;
  val5 = param1_00[-3];
  param1 = _Znam(val4);
  puVar1 = param1_00;
  while( true ) {
    val1 = func_0x0006ffcc();
    if (val4 <= val1) {
      val4 = val1 + 1;
      _ZdaPv(param1);
      param1 = _Znam(val4);
      func_0x0006ffcc();
    }
    func_0x0006433c();
    val1 = strlen((char *)puVar1);
    if ((char *)((int8)puVar1 + val1) == (char *)((int8)param1_00 + val5)) break;
    val3 = *in_x8;
    puVar1 = (uint8 *)((char *)((int8)puVar1 + val1) + 1);
    val2 = *(int8 *)(val3 + -0x18);
    val1 = val2 + 1;
    if ((*(uint8 *)(val3 + -0x10) < val1) || (0 < *(int4 *)(val3 + -8))) {
      func_0x00063bf0();
      val3 = *in_x8;
      val2 = *(int8 *)(val3 + -0x18);
    }
    *(uint8_t *)(val3 + val2) = 0;
    val2 = *in_x8;
    if ((uint8 *)(val2 + -0x18) != puRam00000000000bff48) {
      *(uint32_t *)(val2 + -8) = 0;
      *(uint8 *)(val2 + -0x18) = val1;
      *(uint8_t *)(val2 + val1) = 0;
    }
  }
  _ZdaPv(param1);
  if (param1_00 + -3 == puRam00000000000bff48) {
    return in_x8;
  }
  func_0x00029454(param1_00 + -3,axStack_8);
  return in_x8;
}