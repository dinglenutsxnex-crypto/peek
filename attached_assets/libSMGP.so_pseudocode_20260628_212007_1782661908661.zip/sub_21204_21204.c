uint64_t sub_21204(void)

{
  jclass cls;
  jobject obj;
  uint8_t *in_x0;
  jobject obj2;
  uint1 *puVar4;
  int8 *in_x1;
  char in_w2;
  uint1 *puVar5;
  int8 val1;
  int8 *env;
  int8 val2;
  
  val1 = *(int8 *)(*in_x1 + -0x18);
  *in_x0 = 0;
  val1 = (int8)in_x1 + val1;
  if (*(int4 *)(val1 + 0x20) != 0) goto code_r0x00021278;
  if (*(int8 *)(val1 + 0xd8) == 0) {
    if (in_w2 != '\0') goto code_r0x0002125c;
code_r0x00021298:
    if ((*(uint4 *)(val1 + 0x18) >> 0xc & 1) != 0) {
      env = *(int8 **)(val1 + 0xe8);
      if ((uint1 *)env[2] < (uint1 *)env[3]) {
        val2 = *(int8 *)(val1 + 0xf0);
        obj2 = (uint8)*(uint1 *)env[2];
        if (val2 == 0) {
code_r0x0002139c:
          func_0x00061e30();
        }
      }
      else {
        obj2 = (*env)->ToReflectedMethod(env);
        val1 = (int8)in_x1 + *(int8 *)(*in_x1 + -0x18);
        val2 = *(int8 *)(val1 + 0xf0);
        if (val2 == 0) goto code_r0x0002139c;
        if ((int4)obj2 == -1) goto code_r0x00021278;
      }
      if ((*(uint1 *)(*(int8 *)(val2 + 0x30) + (obj2 & 0xff)) >> 3 & 1) != 0) {
        do {
          puVar4 = (uint1 *)env[3];
          if ((uint1 *)env[2] < puVar4) {
            puVar5 = (uint1 *)env[2] + 1;
            env[2] = (int8)puVar5;
          }
          else {
            cls = (*env)->GetSuperclass(env);
            if (cls == -1) goto code_r0x00021278;
            puVar5 = (uint1 *)env[2];
            puVar4 = (uint1 *)env[3];
          }
          if (puVar5 < puVar4) {
            obj = (uint4)*puVar5;
          }
          else {
            obj = (*env)->ToReflectedMethod(env);
            if (obj == JNI_ERR) goto code_r0x00021278;
          }
        } while ((*(uint1 *)(*(int8 *)(val2 + 0x30) + (uint8)(uint1)obj) >> 3 & 1) != 0);
        val1 = (int8)in_x1 + *(int8 *)(*in_x1 + -0x18);
      }
    }
  }
  else {
    func_0x0003d868();
    val1 = (int8)in_x1 + *(int8 *)(*in_x1 + -0x18);
    if (in_w2 == '\0') goto code_r0x00021298;
  }
  if (*(int4 *)(val1 + 0x20) == 0) {
code_r0x0002125c:
    *in_x0 = 1;
    return 1;
  }
code_r0x00021278:
}