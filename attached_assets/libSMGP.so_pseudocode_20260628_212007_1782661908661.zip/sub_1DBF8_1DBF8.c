int8 sub_1DBF8(void)

{
  void *in_x1;
  int8 in_x2;
  void *in_x3;
  
  memcpy(in_x3,in_x1,in_x2 - (int8)in_x1);
  return in_x2;
}