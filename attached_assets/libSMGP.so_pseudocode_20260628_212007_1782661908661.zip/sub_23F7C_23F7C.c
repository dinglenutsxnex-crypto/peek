int8 * sub_23F7C(void)

{
  int8 *in_x0;
  code *in_x1;
  
  (*in_x1)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18));
  return in_x0;
}