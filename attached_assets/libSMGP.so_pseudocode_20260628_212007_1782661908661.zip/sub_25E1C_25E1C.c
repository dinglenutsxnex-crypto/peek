int8 * sub_25E1C(void)

{
  char cVar1;
  jobject obj;
  int8 *in_x0;
  int8 *piVar3;
  int4 *piVar4;
  int4 *in_x1;
  int4 *piVar5;
  int8 *env;
  int8 val1;
  int4 *piVar8;
  int8 val2;
  char cStack_10;
  uint8_t axStack_8 [8];
  
  sub_24104();
  if (cStack_10 != '\0') {
    val2 = *(int8 *)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0x10);
    if (val2 < 1) {
      val2 = 0x7fffffffffffffff;
    }
    func_0x0003989c(axStack_8,(int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xd0);
    piVar3 = (int8 *)func_0x0004c214(axStack_8);
    func_0x0003a188(axStack_8);
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    if ((int4 *)env[2] < (int4 *)env[3]) {
      obj = *(int4 *)env[2];
    }
    else {
      obj = (*env)->ToReflectedMethod(env);
    }
    val1 = 0;
code_r0x00025ec0:
    piVar8 = in_x1;
    if (val1 < val2 + -1) {
      while( true ) {
        in_x1 = piVar8;
        if (obj == -1) goto code_r0x00025fbc;
        cVar1 = (**(code **)(*piVar3 + 0x10))(piVar3,8,obj);
        if (cVar1 != '\0') goto code_r0x00025ef0;
        piVar5 = (int4 *)env[2];
        val1 = val1 + 1;
        piVar4 = (int4 *)env[3];
        in_x1 = piVar8 + 1;
        *piVar8 = obj;
        if (piVar5 < piVar4) {
          obj = *piVar5;
          env[2] = (int8)(piVar5 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj == -1) goto code_r0x00025ec0;
        if ((int4 *)env[3] <= (int4 *)env[2]) break;
        obj = *(int4 *)env[2];
        piVar8 = in_x1;
        if (val2 + -1 <= val1) goto code_r0x00025fbc;
      }
      obj = (*env)->ToReflectedMethod(env);
      goto code_r0x00025ec0;
    }
code_r0x00025fbc:
    if (obj == -1) {
      val2 = *in_x0;
      *in_x1 = 0;
      *(uint64_t *)((int8)in_x0 + *(int8 *)(val2 + -0x18) + 0x10) = 0;
    }
    else {
code_r0x00025ef0:
      val2 = *in_x0;
      *in_x1 = 0;
      *(uint64_t *)((int8)in_x0 + *(int8 *)(val2 + -0x18) + 0x10) = 0;
      if (val1 != 0) {
        return in_x0;
      }
    }
  }
  sub_1F6E0();
  return in_x0;
}