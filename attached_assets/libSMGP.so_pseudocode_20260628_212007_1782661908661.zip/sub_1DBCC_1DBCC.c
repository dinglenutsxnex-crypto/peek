int8 sub_1DBCC(void)

{
  void *in_x1;
  int8 in_x2;
  void *in_x4;
  
  memcpy(in_x4,in_x1,in_x2 - (int8)in_x1);
  return in_x2;
}