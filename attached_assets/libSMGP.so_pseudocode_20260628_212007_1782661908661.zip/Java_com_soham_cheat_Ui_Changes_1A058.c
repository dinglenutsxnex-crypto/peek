// detected - AES key schedule (Rcon) (detection may be wrong)
uint64_t Java_com_soham_cheat_Ui_Changes(void)

{
  int8 *piVar1;
  int4 val1;
  char cVar3;
  bool bVar4;

  int8 val2;
  int8 *piVar7;
  uint64_t *pxVar8;
  uint64_t val3;
  uint32_t in_w2;
  uint32_t in_w3;
  int4 *piVar10;
  uint64_t xStack_60;
  uint8_t axStack_58 [8];
  uint8_t axStack_50 [8];

  int8 *piStack_40;

  xStack_60 = 0;
  pxVar8 = _Znwm(0x30);
  pxVar8[1] = 0;
  pxVar8[2] = 0;
  *(uint32_t *)(pxVar8 + 3) = in_w2;
  *(uint32_t *)((int8)pxVar8 + 0x1c) = in_w3;
  *pxVar8 = 0xbc9b8;
  pxVar8[4] = axStack_50;
  pxVar8[5] = axStack_58;
  piStack_40 = _Znwm(0x20);
  piStack_40[3] = (int8)pxVar8;
  piStack_40[1] = 0x100000001;
  *piStack_40 = 0xbc9e0;
  xStack_60 = pxVar8;
  func_0x0006830c(&xStack_60,&pxStack_48);
  piVar7 = piStack_40;
  val2 = pthread_create;
  if (piStack_40 != (int8 *)0x0) {
    piVar1 = piStack_40 + 1;
    if (pthread_create == 0) {
      val1 = (int4)*piVar1;
      *(int4 *)piVar1 = val1 + -1;
    }
    else {
      do {
        val1 = (int4)*piVar1;
        cVar3 = '\x01';
        bVar4 = (bool)ExclusiveMonitorPass(piVar1,0x10);
        if (bVar4) {
          *(int4 *)piVar1 = val1 + -1;
          cVar3 = ExclusiveMonitorsStatus();
        }
      } while (cVar3 != '\0');
    }
    if (val1 == 1) {
      piVar10 = (int4 *)((int8)piStack_40 + 0xc);
      (**(code **)(*piStack_40 + 0x10))(piStack_40);
      if (val2 == 0) {
        val1 = *piVar10;
        *piVar10 = val1 + -1;
      }
      else {
        do {
          val1 = *piVar10;
          cVar3 = '\x01';
          bVar4 = (bool)ExclusiveMonitorPass(piVar10,0x10);
          if (bVar4) {
            *piVar10 = val1 + -1;
            cVar3 = ExclusiveMonitorsStatus();
          }
        } while (cVar3 != '\0');
      }
      if (val1 == 1) {
        (**(code **)(*piVar7 + 0x18))(piVar7);
      }
    }
  }
  func_0x000680c4(&xStack_60);
  val3 = pthread_equal(xStack_60,0);
  if ((int4)val3 == 0) {
    _ZSt9terminatev();
  }

  __stack_chk_fail();
}