uint64_t sub_1F2DC(void)

{
  char cVar1;
  int8 in_x0;
  uint64_t ret;
  
  cVar1 = func_0x0002d0b8();
  if (cVar1 == '\0') {
    *(uint64_t *)(in_x0 + 0xf0) = 0;
    cVar1 = func_0x0002d268();
  }
  else {
    ret = func_0x0002b34c();
    *(uint64_t *)(in_x0 + 0xf0) = ret;
    cVar1 = func_0x0002d268();
  }
  if (cVar1 == '\0') {
    *(uint64_t *)(in_x0 + 0xf8) = 0;
    cVar1 = func_0x0002d2d4();
  }
  else {
    ret = func_0x0002c17c();
    *(uint64_t *)(in_x0 + 0xf8) = ret;
    cVar1 = func_0x0002d2d4();
  }
  if (cVar1 != '\0') {
    ret = func_0x0002c1e4();
    *(uint64_t *)(in_x0 + 0x100) = ret;
    return ret;
  }
  *(uint64_t *)(in_x0 + 0x100) = 0;
  return 0;
}