int8 sub_1D838(void)

{
  int4 param1;
  uint64_t *in_x0;
  int8 ret;
  int4 *piVar2;
  void *in_x1;
  uint8 in_x2;
  
  do {
    param1 = fileno(*in_x0);
    ret = read(param1,in_x1,in_x2);
    if (ret != -1) {
      return ret;
    }
    piVar2 = (int4 *)__errno();
  } while (*piVar2 == 4);
  return 0xffffffffffffffff;
}