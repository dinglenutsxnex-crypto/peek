uint64_t sub_1EF9C(void)

{
  int8 in_x0;
  int8 in_x1;
  uint64_t ret;
  
  ret = *(uint64_t *)(in_x0 + 0xe8);
  *(uint4 *)(in_x0 + 0x20) = (uint4)(in_x1 == 0);
  *(int8 *)(in_x0 + 0xe8) = in_x1;
  if (((uint4)(in_x1 == 0) & *(uint4 *)(in_x0 + 0x1c)) == 0) {
    return ret;
  }
  func_0x00062640("basic_ios::clear");
}