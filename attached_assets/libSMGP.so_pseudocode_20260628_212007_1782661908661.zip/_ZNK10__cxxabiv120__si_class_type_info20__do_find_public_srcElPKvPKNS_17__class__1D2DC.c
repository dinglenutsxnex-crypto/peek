uint8 _ZNK10__cxxabiv120__si_class_type_info20__do_find_public_srcElPKvPKNS_17__class_type_infoES2_
                (void)

{
  int4 val1;
  int8 in_x0;
  uint8 val2;
  char *param1;
  int8 in_x2;
  int8 in_x3;
  int8 in_x4;
  
  if (in_x4 == in_x2) {
    param1 = *(char **)(in_x0 + 8);
    if (param1 == *(char **)(in_x3 + 8)) {
      return 6;
    }
    if ((*param1 != '*') && (val1 = strcmp(param1,*(char **)(in_x3 + 8)), val1 == 0)) {
      return 6;
    }
  }
  val2 = (**(code **)(**(int8 **)(in_x0 + 0x10) + 0x40))(*(int8 **)(in_x0 + 0x10));
  return val2 & 0xffffffff;
}