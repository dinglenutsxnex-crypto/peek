uint64_t sub_29D34(void)

{
  int8 *env;
  uint64_t in_x8;
  
  (*env)->FromReflectedMethod();
  return in_x8;
}