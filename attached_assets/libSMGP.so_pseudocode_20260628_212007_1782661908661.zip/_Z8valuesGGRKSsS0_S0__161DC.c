uint8 _Z8valuesGGRKSsS0_S0_(void)

{
  char cVar1;
  bool bVar2;

  int8 *in_x0;
  int8 val1;
  uint8 val2;
  uint8 val3;
  int4 *piVar7;
  int4 val4;
  uint8 unaff_x23;
  int8 iStack_80;
  int8 iStack_78;
  int8 iStack_70;
  int8 iStack_68;
  uint8_t axStack_60 [8];




  func_0x00063720(&iStack_68,0x8479e,&iStack_70);
  func_0x00063720(&iStack_70,0x8479e,&iStack_78);
  val1 = func_0x000649dc();
  func_0x000632ec(&iStack_78);
  if (val1 == -1) {
code_r0x00016380:
    _Z14executeCommandRKSsS0_S0_S0_S0_(&iStack_78,&iStack_68,&iStack_70);
    val2 = unk_bff48;
    if (iStack_78 - 0x18U != unk_bff48) {
      piVar7 = (int4 *)(iStack_78 + -8);
      if (pthread_create == 0) {
        val4 = *piVar7;
        *piVar7 = val4 + -1;
      }
      else {
        do {
          val4 = *piVar7;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
          if (bVar2) {
            *piVar7 = val4 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val4 < 1) {
        func_0x00066f0c(iStack_78 - 0x18U,&iStack_80);
      }
    }
    if (iStack_70 - 0x18U != val2) {
      piVar7 = (int4 *)(iStack_70 + -8);
      if (pthread_create == 0) {
        val4 = *piVar7;
        *piVar7 = val4 + -1;
      }
      else {
        do {
          val4 = *piVar7;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
          if (bVar2) {
            *piVar7 = val4 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val4 < 1) {
        func_0x00066f0c(iStack_70 - 0x18U,&iStack_78);
      }
    }
    val3 = iStack_68 - 0x18;
    if (val3 != val2) {
      piVar7 = (int4 *)(iStack_68 + -8);
      if (pthread_create == 0) {
        val4 = *piVar7;
        *piVar7 = val4 + -1;
      }
      else {
        do {
          val4 = *piVar7;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
          if (bVar2) {
            *piVar7 = val4 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
      }
      if (val4 < 1) {
        val3 = func_0x00066f0c(val3,&iStack_70);
      }
    }



    __stack_chk_fail();
  }
  else {
    unaff_x23 = val1 + 1;
    val1 = func_0x000649dc();
    if (val1 == -1) {
      if (unaff_x23 <= *(uint8 *)(*in_x0 + -0x18)) {
        func_0x000632ec(&iStack_80);
        func_0x0006473c(&iStack_68,&iStack_80);
        val2 = iStack_80 - 0x18;
        if (val2 != unk_bff48) {
          piVar7 = (int4 *)(iStack_80 + -8);
          if (pthread_create == 0) {
code_r0x00016510:
            val4 = *piVar7;
            *piVar7 = val4 + -1;
          }
          else {
            do {
              val4 = *piVar7;
              cVar1 = '\x01';
              bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
              if (bVar2) {
                *piVar7 = val4 + -1;
                cVar1 = ExclusiveMonitorsStatus();
              }
            } while (cVar1 != '\0');
          }
code_r0x0001651c:
          if (val4 < 1) {
            func_0x00066f0c(val2,axStack_60);
          }
        }
        goto code_r0x00016380;
      }
    }
    else if (unaff_x23 <= *(uint8 *)(*in_x0 + -0x18)) {
      func_0x000632ec(&iStack_80);
      func_0x0006473c(&iStack_68,&iStack_80);
      unaff_x23 = unk_bff48;
      if (iStack_80 - 0x18U != unk_bff48) {
        piVar7 = (int4 *)(iStack_80 + -8);
        if (pthread_create == 0) {
          val4 = *piVar7;
          *piVar7 = val4 + -1;
        }
        else {
          do {
            val4 = *piVar7;
            cVar1 = '\x01';
            bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
            if (bVar2) {
              *piVar7 = val4 + -1;
              cVar1 = ExclusiveMonitorsStatus();
            }
          } while (cVar1 != '\0');
        }
        if (val4 < 1) {
          func_0x00066f0c(iStack_80 - 0x18U,axStack_60);
        }
      }
      if (*(uint8 *)(*in_x0 + -0x18) < val1 + 1U) goto code_r0x0001656c;
      func_0x000632ec(&iStack_80);
      func_0x0006473c(&iStack_70,&iStack_80);
      val2 = iStack_80 - 0x18;
      if (val2 != unaff_x23) {
        piVar7 = (int4 *)(iStack_80 + -8);
        if (pthread_create == 0) goto code_r0x00016510;
        do {
          val4 = *piVar7;
          cVar1 = '\x01';
          bVar2 = (bool)ExclusiveMonitorPass(piVar7,0x10);
          if (bVar2) {
            *piVar7 = val4 + -1;
            cVar1 = ExclusiveMonitorsStatus();
          }
        } while (cVar1 != '\0');
        goto code_r0x0001651c;
      }
      goto code_r0x00016380;
    }
  }
  func_0x0006221c("%s: __pos (which is %zu) > this->size() (which is %zu)","basic_string::substr",unaff_x23);
code_r0x0001656c:
  func_0x0006221c("%s: __pos (which is %zu) > this->size() (which is %zu)","basic_string::substr");
}