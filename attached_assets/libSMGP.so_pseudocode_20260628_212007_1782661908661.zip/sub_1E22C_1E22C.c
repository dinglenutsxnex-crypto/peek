uint64_t sub_1E22C(void)

{
  int4 val1;
  uint64_t *in_x0;
  uint64_t val2;
  char *in_x1;
  int8 in_x2;
  
  *(uint4 *)(in_x0 + 1) = (uint4)(in_x2 != 0);
  *in_x0 = 0xbcc00;
  val2 = func_0x00039ed0();
  in_x0[2] = val2;
  *(uint8_t *)(in_x0 + 3) = 0;
  func_0x0001ebcc();
  *in_x0 = 0xbcc80;
  val1 = strcmp(in_x1,(char *)"nu.version_r");
  if ((val1 != 0) && (val1 = strcmp(in_x1,(char *)"POSIX"), val1 != 0)) {
    func_0x0006f8d4(in_x0 + 2);
    func_0x0006f8a0(in_x0 + 2);
  }
  return 0;
}