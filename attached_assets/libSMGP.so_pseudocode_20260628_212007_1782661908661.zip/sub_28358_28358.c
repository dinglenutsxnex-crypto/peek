int8 * sub_28358(void)

{
  uint8 val1;
  bool bVar2;
  jobject obj;
  int8 *in_x0;
  int4 *piVar4;
  uint64_t val2;
  int8 in_x1;
  int8 val3;
  int4 in_w2;
  int8 val4;
  int4 *piVar8;
  uint8 val5;
  int8 val6;
  int8 *env;
  char cStack_8;
  
  if (in_w2 == -1) {
    val2 = func_0x0006cc58();
    return (int8 *)val2;
  }
  in_x0[1] = 0;
  sub_24104();
  if ((in_x1 < 1) || (cStack_8 == '\0')) {
    return in_x0;
  }
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  if ((int4 *)env[2] < (int4 *)env[3]) {
    obj = *(int4 *)env[2];
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
  }
  val3 = in_x0[1];
  bVar2 = false;
code_r0x000283dc:
  do {
    if (in_w2 == obj || obj == -1) {
code_r0x00028478:
      if (bVar2) {
        in_x0[1] = 0x7fffffffffffffff;
      }
      if (obj == -1) {
        sub_1F6E0();
        return in_x0;
      }
      if (in_w2 != obj) {
        return in_x0;
      }
      if (in_x0[1] != 0x7fffffffffffffff) {
        in_x0[1] = in_x0[1] + 1;
      }
      if ((uint8)env[2] < (uint8)env[3]) {
        env[2] = env[2] + 4;
        return in_x0;
      }
      (*env)->GetSuperclass(env);
      return in_x0;
    }
    while (val3 < in_x1) {
      piVar8 = (int4 *)env[3];
      piVar4 = (int4 *)env[2];
      val4 = (int8)piVar8 - (int8)piVar4 >> 2;
      val6 = in_x1 - val3;
      if (val4 < in_x1 - val3) {
        val6 = val4;
      }
      if (val6 < 2) {
        in_x0[1] = val3 + 1;
        if (piVar4 < piVar8) {
          obj = *piVar4;
          env[2] = (int8)(piVar4 + 1);
        }
        else {
          obj = (*env)->GetSuperclass(env);
        }
        if (obj == -1) {
          val3 = in_x0[1];
          obj = -1;
        }
        else if ((int4 *)env[2] < (int4 *)env[3]) {
          obj = *(int4 *)env[2];
          val3 = in_x0[1];
        }
        else {
code_r0x00028504:
          obj = (*env)->ToReflectedMethod(env);
          val3 = in_x0[1];
        }
        goto code_r0x000283dc;
      }
      val3 = wmemchr(piVar4,in_w2,val6);
      val4 = env[2];
      if (val3 != 0) {
        val6 = val3 - val4 >> 2;
      }
      val3 = in_x0[1];
      val1 = val4 + val6 * 4;
      val5 = env[3];
      env[2] = val1;
      val3 = val6 + val3;
      in_x0[1] = val3;
      if (val5 <= val1) goto code_r0x00028504;
      obj = *(int4 *)(val4 + val6 * 4);
      if (in_w2 == obj || obj == -1) goto code_r0x00028478;
    }
    if (in_x1 != 0x7fffffffffffffff) goto code_r0x00028478;
    in_x0[1] = -0x8000000000000000;
    val3 = -0x8000000000000000;
    bVar2 = true;
  } while( true );
}