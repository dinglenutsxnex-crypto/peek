uint64_t * _Z14cleanHexStringRKSs(void)

{
  uint8 val1;
  char cVar2;
  int8 val2;
  uint64_t *in_x0;
  int8 *in_x8;
  int8 val3;
  int8 val4;
  char *pcVar6;
  int8 val5;
  
  val2 = unk_bff48;
  *in_x8 = unk_bff48 + 0x18;
  pcVar6 = (char *)*in_x0;
  for (val5 = *(int8 *)(pcVar6 + -0x18); val5 != 0; val5 = val5 + -1) {
    cVar2 = *pcVar6;
    if (((cVar2 != ' ') && (cVar2 != 'H')) && (cVar2 != 'h')) {
      val3 = *in_x8;
      val4 = *(int8 *)(val3 + -0x18);
      val1 = val4 + 1;
      if ((*(uint8 *)(val3 + -0x10) < val1) || (0 < *(int4 *)(val3 + -8))) {
        in_x0 = (uint64_t *)func_0x00063bf0();
        val3 = *in_x8;
        val4 = *(int8 *)(val3 + -0x18);
      }
      *(char *)(val3 + val4) = cVar2;
      val4 = *in_x8;
      if (val4 + -0x18 != val2) {
        *(uint32_t *)(val4 + -8) = 0;
        *(uint8 *)(val4 + -0x18) = val1;
        *(uint8_t *)(val4 + val1) = 0;
      }
    }
    pcVar6 = pcVar6 + 1;
  }
  return in_x0;
}