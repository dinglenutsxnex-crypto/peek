uint64_t sub_1291C(void)

{
  __cxa_atexit(0x67cc4,0xc0138,0xc0000);
}