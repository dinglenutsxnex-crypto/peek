uint64_t sub_1E568(void)

{
  uint64_t *in_x0;
  uint64_t extraout_x0;
  
  *in_x0 = 0xbcd20;
  sub_1DB10();
  _ZdlPv(in_x0);
  return extraout_x0;
}