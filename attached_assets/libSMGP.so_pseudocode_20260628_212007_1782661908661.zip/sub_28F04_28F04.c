uint64_t sub_28F04(void)

{
  uint64_t *in_x0;
  uint64_t extraout_x0;
  
  *in_x0 = 0xba940;
  func_0x0003cb0c();
  _ZdlPv(in_x0);
  return extraout_x0;
}