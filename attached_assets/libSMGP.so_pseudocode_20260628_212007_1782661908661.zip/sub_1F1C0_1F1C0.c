uint64_t sub_1F1C0(void)

{
  uint64_t *in_x0;
  
  func_0x0001ff5c();
  in_x0[0x1b] = 0;
  *(uint8_t *)(in_x0 + 0x1c) = 0;
  *in_x0 = 0xba5c0;
  *(uint8_t *)((int8)in_x0 + 0xe1) = 0;
  in_x0[0x1d] = 0;
  in_x0[0x1e] = 0;
  in_x0[0x1f] = 0;
  in_x0[0x20] = 0;
  return 0xba5c0;
}