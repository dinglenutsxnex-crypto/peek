int8 * sub_1D5F4(void)

{
  int4 val;
  int8 *in_x0;
  int4 *piVar2;
  void *param1;
  int8 in_x1;
  
  if ((in_x1 != 0) && (*in_x0 == 0)) {
    piVar2 = (int4 *)__errno();
    param1 = (void *)0x0;
    *piVar2 = 0;
    while( true ) {
      val = fflush(param1);
      if (val == 0) {
        *in_x0 = in_x1;
        *(uint8_t *)(in_x0 + 1) = 0;
        return in_x0;
      }
      if (*piVar2 != 4) break;
      param1 = (void *)*in_x0;
    }
  }
  return (int8 *)0;
}