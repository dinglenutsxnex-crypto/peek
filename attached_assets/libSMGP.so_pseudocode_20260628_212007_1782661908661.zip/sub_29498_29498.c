void sub_29498(int8 *env)

{
  (*env)->GetSuperclass();
  return;
}