uint64_t sub_202FC(void)

{
  uint64_t *in_x0;
  uint64_t *param1;
  
  *in_x0 = 0xba600;
  sub_20210();
  sub_20278();
  param1 = (uint64_t *)in_x0[0x19];
  if (param1 != in_x0 + 8) {
    if (param1 != (uint64_t *)0x0) {
      _ZdaPv(param1);
    }
    in_x0[0x19] = 0;
  }
}