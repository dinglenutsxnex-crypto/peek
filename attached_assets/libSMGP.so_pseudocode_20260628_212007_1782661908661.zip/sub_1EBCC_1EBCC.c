uint64_t sub_1EBCC(void)

{
  int8 val1;
  int4 val2;
  uint32_t val3;
  int8 in_x0;
  uint8 val4;
  uint64_t ret;
  uint8 val5;
  int8 val6;
  uint32_t *pxVar8;
  
  val5 = 0;
  do {
    val2 = wctob(val5 & 0xffffffff);
    val6 = in_x0 + val5;
    val5 = val5 + 1;
    if (val2 == -1) {
      *(uint8_t *)(in_x0 + 0x18) = 0;
      goto code_r0x0001ec10;
    }
    *(char *)(val6 + 0x19) = (char)val2;
  } while (val5 != 0x80);
  *(uint8_t *)(in_x0 + 0x18) = 1;
code_r0x0001ec10:
  val5 = 0;
  pxVar8 = (uint32_t *)(in_x0 + 0x9c);
  do {
    val4 = val5 & 0xffffffff;
    val5 = val5 + 1;
    val3 = btowc(val4);
    *pxVar8 = val3;
    pxVar8 = pxVar8 + 1;
  } while (val5 != 0x100);
  val6 = 0;
  do {
    *(char *)(in_x0 + val6 + 0x49c) = (char)(1 << (uint8)((uint4)val6 & 0x1f));
    ret = func_0x0001e644();
    val1 = val6 * 8;
    val6 = val6 + 1;
    *(uint64_t *)(in_x0 + val1 + 0x4b0) = ret;
  } while (val6 != 0x10);
  return ret;
}