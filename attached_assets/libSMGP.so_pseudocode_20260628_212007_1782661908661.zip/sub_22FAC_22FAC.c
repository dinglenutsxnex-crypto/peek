int8 * sub_22FAC(void)

{
  int8 *in_x0;
  uint8_t in_w1;
  int8 val;
  int8 *env;
  uint8_t axVar3 [12];
  
  val = *(int8 *)(*in_x0 + -0x18);
  if (*(char *)((int8)in_x0 + val + 0xe1) != '\0') {
    *(uint8_t *)((int8)in_x0 + val + 0xe0) = in_w1;
    return in_x0;
  }
  env = *(int8 **)((int8)in_x0 + val + 0xf0);
  if (env != (int8 *)0x0) {
    if ((char)env[7] == '\0') {
      sub_1DFC0();
      (*env)->FindClass(env,"lease)");
    }
    *(uint8_t *)((int8)in_x0 + val + 0xe0) = in_w1;
    *(uint8_t *)((int8)in_x0 + val + 0xe1) = 1;
    return in_x0;
  }
  axVar3 = func_0x00061e30();
  env = axVar3._0_8_;
  *(uint4 *)((int8)env + *(int8 *)(*env + -0x18) + 0x18) =
       *(uint4 *)((int8)env + *(int8 *)(*env + -0x18) + 0x18) | axVar3._8_4_;
  return env;
}