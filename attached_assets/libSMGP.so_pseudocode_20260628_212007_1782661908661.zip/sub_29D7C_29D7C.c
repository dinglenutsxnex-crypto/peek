void sub_29D7C(int8 *env)

{
  (*env)->ToReflectedMethod();
  return;
}