uint64_t sub_2932C(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xba6e0;
  func_0x0006f8d4(in_x0 + 2);
  func_0x000397cc();
}