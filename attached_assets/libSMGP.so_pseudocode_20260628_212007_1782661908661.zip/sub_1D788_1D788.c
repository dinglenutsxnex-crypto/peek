uint64_t sub_1D788(void)

{
  uint64_t *in_x0;
  uint64_t ret;
  
  ret = fileno(*in_x0);
  return ret;
}