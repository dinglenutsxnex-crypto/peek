int8 * sub_21D20(void)

{
  uint1 val1;
  jclass cls;
  int8 *in_x0;
  uint1 *puVar3;
  uint4 val2;
  int8 *in_x1;
  uint1 in_w2;
  uint1 *puVar5;
  int8 *env;
  jobject obj;
  uint4 val3;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_21204();
  if (cStack_8 == '\0') goto code_r0x00021e64;
  env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
  val3 = (uint4)in_w2;
  if ((uint1 *)env[2] < (uint1 *)env[3]) {
    val1 = *(uint1 *)env[2];
    obj = (uint4)val1;
    val2 = (uint4)val1;
    if (val3 == obj) goto code_r0x00021e64;
code_r0x00021d8c:
    do {
      while( true ) {
        if ((uint8_t *)in_x1[5] < (uint8_t *)in_x1[6]) {
          *(uint8_t *)in_x1[5] = (char)val2;
          in_x1[5] = in_x1[5] + 1;
        }
        else {
          cls = (*in_x1)->Throw();
          if (cls == -1) goto code_r0x00021dec;
        }
        puVar3 = (uint1 *)env[2];
        puVar5 = (uint1 *)env[3];
        in_x0[1] = in_x0[1] + 1;
        if (puVar3 < puVar5) {
          puVar3 = puVar3 + 1;
          env[2] = (int8)puVar3;
        }
        else {
          cls = (*env)->GetSuperclass(env);
          if (cls == -1) goto code_r0x00021df4;
          puVar3 = (uint1 *)env[2];
          puVar5 = (uint1 *)env[3];
        }
        if (puVar5 <= puVar3) break;
        obj = (uint4)*puVar3;
        val2 = obj;
        if (val3 == obj) goto code_r0x00021dec;
      }
      obj = (*env)->ToReflectedMethod(env);
      val2 = obj & 0xff;
    } while (val3 != obj && obj != JNI_ERR);
  }
  else {
    obj = (*env)->ToReflectedMethod(env);
    val2 = obj & 0xff;
    if ((obj != JNI_ERR) && (val3 != obj)) goto code_r0x00021d8c;
  }
code_r0x00021dec:
  if (obj == JNI_ERR) {
code_r0x00021df4:
    sub_1ED34();
    return in_x0;
  }
code_r0x00021e64:
  if (in_x0[1] != 0) {
    return in_x0;
  }
  sub_1ED34();
  return in_x0;
}