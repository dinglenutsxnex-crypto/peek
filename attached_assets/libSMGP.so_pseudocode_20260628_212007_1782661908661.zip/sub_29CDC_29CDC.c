uint64_t sub_29CDC(void)

{
  int8 *env;
  uint64_t in_x8;
  
  (*env)->DefineClass();
  return in_x8;
}