uint8 _Z16hexStringToBytesPKcPh(void)

{
  uint4 val1;
  char *in_x0;
  uint8 val2;
  uint8 val3;
  uint8 ret;
  
  val2 = strlen(in_x0);
  ret = 0;
  if (val2 != 0) {
    val3 = 0;
    do {
      val1 = sscanf(in_x0 + val3,(char *)"%2hhx");
      ret = (uint8)val1;
      val3 = val3 + 2;
    } while (val3 < val2);
  }
  return ret;
}