uint64_t sub_294B4(void)

{
  int8 *env;
  jclass cls;
  
  sub_1DFC0();
  cls = (*env)->FindClass();
  jclass cls;
}