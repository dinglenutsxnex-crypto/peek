int8 * sub_24E60(void)

{
  jclass cls;
  int8 *in_x0;
  int8 *env;
  int4 *piVar3;
  char cStack_8;
  
  in_x0[1] = 0;
  sub_24104();
  if (cStack_8 != '\0') {
    env = *(int8 **)((int8)in_x0 + *(int8 *)(*in_x0 + -0x18) + 0xe8);
    piVar3 = (int4 *)env[2];
    if (piVar3 < (int4 *)env[3]) {
      cls = *piVar3;
      env[2] = (int8)(piVar3 + 1);
    }
    else {
      cls = (*env)->GetSuperclass();
    }
    if (cls == -1) {
      sub_1F6E0();
      return in_x0;
    }
    in_x0[1] = 1;
  }
  return in_x0;
}