// detected - Rolling XOR cipher (detection may be wrong)
// detected - XOR with constant (detection may be wrong)
// detected - SHA-1 (detection may be wrong)
uint64_t _Z9md5StringPcPh(void)

{

  unkuint3 Var2;
  unkuint3 Var3;
  uint4 val1;
  uint4 val2;
  uint4 val3;
  uint4 val4;
  char *in_x0;

  uint64_t *in_x1;
  uint8 val5;
  uint4 val6;
  uint8 val7;
  uint8 val8;

  uint8 val9;
  int8 val10;
  uint4 val11;
  uint8 val12;
  uint8 val13;
  uint4 val14;
  uint4 val15;
  uint4 val16;
  uint4 val17;
  uint8 uStack_128;

  uint64_t xStack_110;
  uint64_t xStack_108;
  uint64_t xStack_100;
  uint64_t xStack_f8;
  uint64_t xStack_f0;
  uint64_t xStack_e8;
  uint64_t xStack_e0;
  uint64_t xStack_d8;
  uint64_t xStack_d0;
  uint64_t xStack_c8;

  xStack_110 = unk_84030;
  uStack_128 = strlen(in_x0);
  if (uStack_128 != 0) {
    val8 = 0;
    val11 = 0;
    val14 = 0x67452301;
    val15 = 0xefcdab89;
    val16 = 0x98badcfe;
    val17 = 0x10325476;
    do {
      val6 = val11 + 1;
      *(char *)((int8)&xStack_110 + (uint8)val11) = in_x0[val8];
      val11 = val6;
      if ((val6 & 0x3f) == 0) {
        val13 = 0;
        val5 = 0;
        val12 = 1;
        Var2 = CONCAT12((char)((uint8)xStack_f0 >> 0x20),(int2)xStack_f0) & 0xff00ff;
        Var3 = CONCAT12((char)((uint8)xStack_e0 >> 0x20),(int2)xStack_e0) & 0xff00ff;
        val9 = 5;
        xStack_c8 = CONCAT17((char)((uint8)xStack_f0 >> 0x38),
                             CONCAT16((char)((uint8)xStack_f0 >> 0x30),
                                      CONCAT15((char)((uint8)xStack_f0 >> 0x28),
                                               CONCAT14((char)(Var2 >> 0x10),
                                                        CONCAT13((char)((uint8)xStack_f0 >> 0x18),
                                                                 CONCAT12((char)((uint8)xStack_f0 >>
                                                                                0x10),
                                                                          CONCAT11((char)((uint8)
                                                  xStack_f0 >> 8),(char)Var2)))))));
        xStack_c8 = CONCAT17((char)((uint8)xStack_e0 >> 0x38),
                             CONCAT16((char)((uint8)xStack_e0 >> 0x30),
                                      CONCAT15((char)((uint8)xStack_e0 >> 0x28),
                                               CONCAT14((char)(Var3 >> 0x10),
                                                        CONCAT13((char)((uint8)xStack_e0 >> 0x18),
                                                                 CONCAT12((char)((uint8)xStack_e0 >>
                                                                                0x10),
                                                                          CONCAT11((char)((uint8)
                                                  xStack_e0 >> 8),(char)Var3)))))));
        val11 = val14;
        val3 = val17;
        val6 = val15;
        val4 = val16;
        do {
          val2 = val4;
          val4 = val6;
          val1 = val3;
          val6 = (uint4)(val5 >> 4) & 0xfffffff;
          if (val6 == 2) {
            val6 = val2 ^ val1 ^ val4;
            val7 = val9 & 0xf;
          }
          else if (val6 == 1) {
            val6 = val4 & val1 | val2 & (val1 ^ 0xffffffff);
            val7 = val12 & 0xf;
          }
          else if ((val5 >> 4 & 0xfffffff) == 0) {
            val6 = val1 & (val4 ^ 0xffffffff) | val4 & val2;
            val7 = val5;
          }
          else {
            val6 = (val4 | val1 ^ 0xffffffff) ^ val2;
            val7 = val13 & 0xf;
          }
          val10 = val5 * 4;
          val11 = val6 + val11 + *(int4 *)(val10 + 0x84d68) +
                   *(int4 *)((int8)&xStack_c0 + (val7 & 0xffffffff) * 4);
          val5 = val5 + 1;
          val6 = 0x20U - *(int4 *)(val10 + 0x84e68) & 0x1f;
          val13 = val13 + 7;
          val12 = val12 + 5;
          val6 = (val11 >> val6 | val11 << 0x20 - val6) + val4;
          val9 = val9 + 3;
          val11 = val1;
          val3 = val2;
        } while (val5 != 0x40);
        val17 = val2 + val17;
        val11 = 0;
        val14 = val1 + val14;
        val15 = val6 + val15;
        val16 = val4 + val16;
      }
      val8 = (uint8)((int4)val8 + 1);
    } while (val8 < uStack_128);
    xStack_110 = CONCAT44(val15,val14);
    xStack_110 = CONCAT44(val17,val16);
  }
  in_x0 = _Z11md5FinalizeP10MD5Context(&uStack_128);
  in_x1[1] = xStack_c8;
  *in_x1 = xStack_d0;

  __stack_chk_fail();
}