uint64_t sub_20E64(void)

{
  uint64_t *in_x0;
  
  *in_x0 = 0xba638;
  in_x0[1] = 0;
  in_x0[2] = unk_bfb30 + 0x10;
  sub_202FC();
}