uint8_t * sub_1E484(void)

{
  uint8_t val;
  int8 *in_x0;
  uint8_t *in_x1;
  uint8_t *in_x2;
  uint8_t *pxVar2;
  
  if (in_x1 < in_x2) {
    do {
      val = (**(code **)(*in_x0 + 0x10))();
      pxVar2 = in_x1 + 1;
      *in_x1 = val;
      in_x1 = pxVar2;
    } while (pxVar2 != in_x2);
  }
  return in_x2;
}